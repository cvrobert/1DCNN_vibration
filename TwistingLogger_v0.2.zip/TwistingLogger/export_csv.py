#!/usr/bin/env python3
"""Export TwistingLogger SQLite samples to one CSV file per group definition."""

from __future__ import annotations

import argparse
import csv
import json
import re
import sqlite3
import zlib
from pathlib import Path
from typing import Any


ARRAY_EXPRESSION = re.compile(
    r"^(?P<prefix>.*)\[(?P<indices>\d+(?:,\d+)*)\]\{(?P<count>\d+)\}$"
)


def decode_json(blob: bytes) -> Any:
    return json.loads(zlib.decompress(blob).decode("utf-8"))


def safe_name(value: str) -> str:
    return "".join(character if character.isalnum() or character in "-_" else "_" for character in value)


def columns_for_tag(tag: str) -> list[str]:
    """Expand pycomm3 array-read expressions into deterministic CSV columns."""
    match = ARRAY_EXPRESSION.fullmatch(tag)
    if match is None:
        return [tag]
    count = int(match.group("count"))
    indices = [int(value) for value in match.group("indices").split(",")]
    if len(indices) == 1:
        start = indices[0]
        return [f'{match.group("prefix")}[{start + offset}]' for offset in range(count)]
    return [f"{tag}#{offset}" for offset in range(count)]


def flatten_sequence(value: Any) -> list[Any]:
    if isinstance(value, (list, tuple)):
        flattened: list[Any] = []
        for item in value:
            flattened.extend(flatten_sequence(item))
        return flattened
    return [value]


def csv_values(value: Any, width: int) -> list[Any]:
    if width == 1:
        if isinstance(value, (list, tuple, dict)):
            return [json.dumps(value, separators=(",", ":"))]
        return [value]
    flattened = flatten_sequence(value)
    if len(flattened) < width:
        flattened.extend([None] * (width - len(flattened)))
    return flattened[:width]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("database", type=Path)
    parser.add_argument("--output-dir", type=Path, default=Path("exports"))
    parser.add_argument("--group", help="Export only this group name")
    args = parser.parse_args()

    args.output_dir.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(f"file:{args.database.resolve()}?mode=ro", uri=True)
    definitions = connection.execute(
        """
        SELECT id, group_name, interval_ms, tags_json
        FROM group_definitions
        WHERE (? IS NULL OR group_name = ?)
        ORDER BY id
        """,
        (args.group, args.group),
    ).fetchall()
    if not definitions:
        raise SystemExit("No matching group definitions found")

    for definition_id, group_name, interval_ms, tags_json in definitions:
        tags = json.loads(tags_json)
        expanded_columns = [columns_for_tag(tag) for tag in tags]
        output = args.output_dir / (
            f"{args.database.stem}_{safe_name(group_name)}_{definition_id}.csv"
        )
        with output.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.writer(handle)
            writer.writerow(
                [
                    "timestamp_utc",
                    "timestamp_local",
                    "sequence",
                    "quality",
                    "read_duration_ms",
                    *(column for columns in expanded_columns for column in columns),
                    "errors_json",
                ]
            )
            rows = connection.execute(
                """
                SELECT timestamp_utc, timestamp_local, sequence, quality,
                       read_duration_ms, values_zlib, errors_zlib
                FROM samples
                WHERE definition_id = ?
                ORDER BY id
                """,
                (definition_id,),
            )
            count = 0
            for row in rows:
                values = decode_json(row[5])
                errors = decode_json(row[6])
                expanded_values: list[Any] = []
                for index, columns in enumerate(expanded_columns):
                    value = values[index] if index < len(values) else None
                    expanded_values.extend(csv_values(value, len(columns)))
                writer.writerow(
                    [
                        *row[:5],
                        *expanded_values,
                        json.dumps(errors, separators=(",", ":")),
                    ]
                )
                count += 1
        print(f"Exported {count} rows ({interval_ms} ms group) to {output}")
    connection.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
