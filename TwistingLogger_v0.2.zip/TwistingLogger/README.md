# TwistingLogger

TwistingLogger is an unattended Raspberry Pi data logger for an Allen-Bradley
CompactLogix 5069-L340ERM at `192.168.20.20`. It supports multiple sampling
groups, daily SQLite database rotation, CSV export, automatic reconnection,
tag-by-tag commissioning validation, and an offline mock mode.

The supplied TW2 configuration was built from the September 16, 2026 controller
tag listing. Test tags, HMI pushbuttons, motion-axis objects, raw module-defined
I/O assemblies, internal timers, and redundant display-only values are omitted.

- `fast_dynamics`: 100 ms live motor currents, payoff overload levels, and speeds
- `process`: 1 second production values, alarms, payoff events, and machine state
- `configuration`: 10 second recipe, limit, threshold, and setup values

The three groups contain exactly 150 configured read expressions. Array reads
expand these to 293 individual CSV signal columns without issuing hundreds of
separate array-element requests.

## First installation

Copy this package to the Raspberry Pi, then run:

```bash
cd TwistingLogger
chmod +x install.sh
sudo ./install.sh
```

The installer copies the application to `/opt/twistinglogger`, creates or
updates its Python virtual environment, and installs a systemd service. It does
not start the service automatically, allowing the configuration to be reviewed
first.

## Updating an existing v0.1 installation offline

The v0.2 installer can use the already-installed Python environment and replace
the active configuration without internet access:

```bash
cd TwistingLogger
chmod +x install.sh
sudo ./install.sh --offline --replace-config
```

The prior configuration is preserved as a timestamped
`/opt/twistinglogger/config.toml.backup-*` file. The service remains stopped and
the replacement configuration remains in mock mode.

## Offline commissioning

The initial configuration has `mock_mode = true`. Run a 15-second foreground
test:

```bash
/opt/twistinglogger/venv/bin/python /opt/twistinglogger/logger.py \
  --config /opt/twistinglogger/config.toml --duration 15
```

Check status and database files. A 15 second run should produce about 151 fast
samples, 16 process samples, and 2 configuration samples:

```bash
cat /opt/twistinglogger/status.json
ls -lh /opt/twistinglogger/data
```

Export the newest database to CSV:

```bash
/opt/twistinglogger/venv/bin/python /opt/twistinglogger/export_csv.py \
  /opt/twistinglogger/data/YYYY-MM-DD.sqlite3 \
  --output-dir /opt/twistinglogger/exports
```

## Service controls

```bash
sudo systemctl enable --now twistinglogger
systemctl status twistinglogger
journalctl -u twistinglogger -f
sudo systemctl restart twistinglogger
sudo systemctl stop twistinglogger
```

## PLC commissioning

1. Connect the Pi and PLC to the same controls network.
2. Confirm `ping -c 3 192.168.20.20` succeeds.
3. Stop the service and validate every configured expression with read-only
   requests:

```bash
sudo systemctl stop twistinglogger
/opt/twistinglogger/venv/bin/python /opt/twistinglogger/validate_tags.py \
  --config /opt/twistinglogger/config.toml
```

4. Resolve every reported failure before live logging. Common causes are an
   exact tag-name mismatch, a UDT member-name mismatch, or External Access set
   to None.
5. Change `mock_mode = true` to `mock_mode = false`.
6. Run a short foreground test before enabling the service.

```bash
sudo systemctl stop twistinglogger
/opt/twistinglogger/venv/bin/python /opt/twistinglogger/logger.py \
  --config /opt/twistinglogger/config.toml --duration 15
```

If the reads are valid, enable and start the service.

## Storage notes

- A new database is created at local midnight.
- No automatic deletion is enabled.
- `minimum_free_gb` causes a warning in the status file and journal; it does
  not delete data.
- An abrupt shutdown should be avoided. SQLite WAL mode is enabled to improve
  resilience.
- For final Pi 5 deployment, an SSD is preferred over continuous microSD
  database writes.

## Timekeeping

Every row contains UTC and local Pi timestamps. For an offline installation,
the Pi 5 RTC should have a backup battery or the PLC clock should eventually be
included in the configured data and treated as the authoritative timestamp.
