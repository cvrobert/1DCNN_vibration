#!/usr/bin/env bash
set -euo pipefail

if [[ "${EUID}" -ne 0 ]]; then
  echo "Run this installer with: sudo ./install.sh [--offline] [--replace-config]" >&2
  exit 1
fi

offline=false
replace_config=false
for argument in "$@"; do
  case "${argument}" in
    --offline) offline=true ;;
    --replace-config) replace_config=true ;;
    *)
      echo "Unknown option: ${argument}" >&2
      exit 1
      ;;
  esac
done

install_user="${SUDO_USER:-root}"
source_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
install_dir="/opt/twistinglogger"

if [[ "${offline}" == false ]]; then
  apt-get update
  apt-get install -y python3-venv python3-pip sqlite3
fi

mkdir -p "${install_dir}" "${install_dir}/data" "${install_dir}/exports"
systemctl stop twistinglogger.service 2>/dev/null || true
install -m 0644 "${source_dir}/logger.py" "${install_dir}/logger.py"
install -m 0644 "${source_dir}/export_csv.py" "${install_dir}/export_csv.py"
install -m 0644 "${source_dir}/validate_tags.py" "${install_dir}/validate_tags.py"
install -m 0644 "${source_dir}/requirements.txt" "${install_dir}/requirements.txt"
install -m 0644 "${source_dir}/README.md" "${install_dir}/README.md"
install -m 0644 "${source_dir}/VERSION" "${install_dir}/VERSION"

if [[ ! -f "${install_dir}/config.toml" || "${replace_config}" == true ]]; then
  if [[ -f "${install_dir}/config.toml" ]]; then
    backup_stamp="$(date +%Y%m%d-%H%M%S)"
    cp -a "${install_dir}/config.toml" "${install_dir}/config.toml.backup-${backup_stamp}"
    echo "Existing config backed up as config.toml.backup-${backup_stamp}"
  fi
  install -m 0644 "${source_dir}/config.toml" "${install_dir}/config.toml"
else
  install -m 0644 "${source_dir}/config.toml" "${install_dir}/config.toml.new"
  echo "Existing config preserved; new example saved as config.toml.new"
fi

if [[ ! -x "${install_dir}/venv/bin/python" ]]; then
  python3 -m venv "${install_dir}/venv"
fi
if [[ "${offline}" == true ]]; then
  if ! "${install_dir}/venv/bin/python" -c "import pycomm3"; then
    echo "Offline update needs an existing virtual environment with pycomm3 installed." >&2
    exit 1
  fi
else
  "${install_dir}/venv/bin/pip" install --upgrade pip
  "${install_dir}/venv/bin/pip" install -r "${install_dir}/requirements.txt"
fi

sed "s/^User=.*/User=${install_user}/; s/^Group=.*/Group=${install_user}/" \
  "${source_dir}/twistinglogger.service" > /etc/systemd/system/twistinglogger.service

chown -R "${install_user}:${install_user}" "${install_dir}"
systemctl daemon-reload

echo
echo "TwistingLogger installed in ${install_dir}"
echo "Configuration: ${install_dir}/config.toml"
echo "Run the offline test shown in ${install_dir}/README.md before starting the service."
