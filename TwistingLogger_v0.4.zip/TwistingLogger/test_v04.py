import csv
import io
import json
import sqlite3
import subprocess
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch
from types import SimpleNamespace

from discover_tags import expand, covered, write_config, main as discover
from logger import load_config, json_safe
from export_zip import export_archive
from trial_report import summarize


class Tests(unittest.TestCase):
    def test_nested_expansion(self):
        info = dict(dim=1, dimensions=[2,0,0], data_type={
            'attributes':['Current','Flags','Axes'], 'internal_tags':{
                'Current':dict(data_type='REAL'),
                'Flags':dict(data_type='DWORD',data_type_name='DWORD',array=1),
                'Axes':dict(data_type='INT',array=2)}})
        excluded=[]; leaves=dict(expand('Drive',info,excluded))
        self.assertEqual(len(leaves),70)
        self.assertEqual(leaves['Drive[1].Flags[31]'],'BOOL')
        self.assertEqual(leaves['Drive[0].Axes[1]'],'INT')
        self.assertEqual(excluded,[])

    def test_scope_string_access_unknown(self):
        excluded=[]
        self.assertEqual(list(expand('Program:P.S',dict(data_type={'string':82}),excluded)),[('Program:P.S','STRING')])
        self.assertEqual(list(expand('Secret',dict(data_type='REAL',external_access='None'),excluded)),[])
        self.assertEqual(list(expand('Unknown',dict(data_type='MAGIC'),excluded)),[])
        self.assertEqual(len(excluded),2)
        self.assertEqual(covered(['A[2]{3}','B']),{'A[2]','A[3]','A[4]','B'})
        self.assertIsNone(json_safe(float('nan')))

    def test_discovery_candidate_and_failures(self):
        class Fake:
            def __init__(self,*a,**kw):
                self.tags={n:dict(tag_name=n,data_type='REAL') for n in ['Base','M31INV11:I.OutputFreq','Program:P.X','Broken']}
            def __enter__(self): return self
            def __exit__(self,*a): pass
            def read(self,*tags):
                return [SimpleNamespace(value=1.0,type='REAL',error='Denied' if t=='Broken' else None) for t in tags]
        with tempfile.TemporaryDirectory() as d:
            p=Path(d); config=p/'base.toml'
            cfg={'application':dict(mock_mode=True,data_dir=str(p/'data'),status_file=str(p/'status.json')),'plc':dict(address='192.168.20.10')}
            write_config(cfg,[dict(name='fast_dynamics',interval_ms=100,tags=['Base'])],config)
            with patch('pycomm3.LogixDriver',Fake),patch.object(sys,'argv',['discover_tags','--config',str(config),'--output',str(p/'out'),'--reference',str(p/'none')]):
                self.assertEqual(discover(),0)
            candidate=load_config(p/'out/candidate.toml')
            groups={g.name:g for g in candidate['parsed_groups']}
            self.assertIn('M31INV11:I.OutputFreq',groups['fast_dynamics'].tags)
            self.assertEqual(groups['all_other_tags'].tags,('Program:P.X',))
            report=json.loads((p/'out/report.json').read_text())
            self.assertEqual(report['exclusions'],1)
            self.assertFalse(candidate['application']['mock_mode'])

    def test_mock_database_and_large_zip_path(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)
            cfg={'application':dict(mock_mode=True,data_dir=str(p/'data'),status_file=str(p/'status.json'),minimum_free_gb=0,database_commit_interval_ms=100),'plc':dict(address='unused')}
            write_config(cfg,[dict(name='fast_dynamics',interval_ms=100,tags=['A','B[0]{2}'])],p/'config.toml')
            subprocess.run([sys.executable,'logger.py','--config',str(p/'config.toml'),'--duration','1.5'],check=True,capture_output=True)
            db=next((p/'data').glob('*.sqlite3'))
            report=summarize(p/'config.toml',p/'data',p/'status.json')
            self.assertTrue(report['passed'])
            with sqlite3.connect(db) as connection:
                connection.execute("UPDATE samples SET quality='bad' WHERE id=1")
            self.assertFalse(summarize(p/'config.toml',p/'data',p/'status.json')['passed'])
            archive=export_archive(db,p/'exports',True)
            with zipfile.ZipFile(archive) as z:
                name=next(n for n in z.namelist() if n.endswith('.csv'))
                rows=list(csv.reader(io.StringIO(z.read(name).decode())))
                self.assertGreater(len(rows),5)
                self.assertIn('B[1]',rows[0])
            # Existing ZIP replaces rather than preserving an earlier half-day.
            archive.write_bytes(b'old partial')
            export_archive(db,p/'exports',True)
            self.assertTrue(zipfile.is_zipfile(archive))
            cfg['application']['minimum_free_gb']=1e12
            write_config(cfg,[dict(name='fast_dynamics',interval_ms=100,tags=['A'])],p/'config.toml')
            r=subprocess.run([sys.executable,'logger.py','--config',str(p/'config.toml'),'--duration','1'],capture_output=True)
            self.assertEqual(r.returncode,1)
            self.assertIn('reserve',json.loads((p/'status.json').read_text())['last_error'])


if __name__=='__main__': unittest.main()
