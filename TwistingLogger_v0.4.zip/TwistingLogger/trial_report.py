#!/usr/bin/env python3
"""Summarize actual sample cadence/quality from a bounded live trial."""
import argparse
import hashlib
import json
import sqlite3
import statistics
from datetime import datetime
from pathlib import Path
from logger import load_config


def summarize(config, directory, status_path):
    cfg = load_config(config)
    samples = {}
    for path in directory.glob("*.sqlite3"):
        with sqlite3.connect(f"file:{path.resolve()}?mode=ro", uri=True) as db:
            for name, stamp, duration, quality in db.execute("SELECT g.group_name,s.timestamp_utc,s.read_duration_ms,s.quality FROM samples s JOIN group_definitions g ON g.id=s.definition_id ORDER BY s.id"):
                samples.setdefault(name, []).append((datetime.fromisoformat(stamp).timestamp(), duration, quality))
    status = json.loads(status_path.read_text())
    groups = []
    ready = not status.get("last_error") and status.get("dropped_samples", 0) == 0
    for group in cfg["parsed_groups"]:
        rows = sorted(samples.get(group.name, []))
        gaps = [1000*(b[0]-a[0]) for a,b in zip(rows, rows[1:])]
        durations = sorted(r[1] for r in rows)
        p95 = durations[min(len(durations)-1, int(.95*len(durations)))] if durations else None
        bad = sum(r[2] != "good" for r in rows)
        # A reasonable commissioning gate, not proof of zero production impact.
        passed = len(rows) >= 3 and not bad and p95 < group.interval_ms * .8 and max(gaps, default=0) < group.interval_ms * 2
        ready = ready and passed
        groups.append(dict(name=group.name, samples=len(rows), bad_samples=bad,
                           target_ms=group.interval_ms, read_p95_ms=p95,
                           median_gap_ms=statistics.median(gaps) if gaps else None,
                           max_gap_ms=max(gaps) if gaps else None, passed=passed))
    total_bytes = sum(p.stat().st_size for p in directory.glob("*.sqlite3*"))
    all_rows = [r for rows in samples.values() for r in rows]
    span = max((r[0] for r in all_rows), default=0)-min((r[0] for r in all_rows), default=0)
    report = dict(candidate_sha256=hashlib.sha256(config.read_bytes()).hexdigest(),
                  address=cfg["plc"]["address"], passed=bool(ready), groups=groups,
                  last_error=status.get("last_error"), dropped_samples=status.get("dropped_samples"),
                  database_bytes=total_bytes,
                  rough_database_gib_per_day=round(total_bytes/span*86400/1024**3,3) if span else None,
                  note="Short-trial storage estimate excludes daily ZIPs and varies with machine activity. Compare PLC scan/communication health onsite; these checks only measure logger performance.")
    return report


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--config",type=Path,required=True)
    ap.add_argument("--trial-dir",type=Path,required=True)
    args=ap.parse_args()
    report=summarize(args.config,args.trial_dir/"data",args.trial_dir/"status.json")
    (args.trial_dir/"trial_report.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps(report,indent=2))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
