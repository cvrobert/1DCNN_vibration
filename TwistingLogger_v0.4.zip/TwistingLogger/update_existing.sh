#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
[[ $EUID == 0 ]] || { echo 'Use sudo bash update_existing.sh REVIEW_FOLDER [--accept-exclusions]'; exit 1; }
review="${1:?Specify the review folder produced by prepare_existing.sh}"
accept="${2:-}"
py=/opt/twistinglogger/venv/bin/python
"$py" - "$review" "$accept" <<'PY'
import hashlib,json,sys,tomllib
from pathlib import Path
p=Path(sys.argv[1]); c=p/'discovery/candidate.toml'
r=json.loads((p/'discovery/report.json').read_text()); t=json.loads((p/'trial/trial_report.json').read_text())
digest=hashlib.sha256(c.read_bytes()).hexdigest()
assert digest == r['candidate_sha256'] == t['candidate_sha256'], 'Candidate changed: repeat validation/trial'
assert not r['baseline_failures'] and t['passed'], 'Validation or trial failed; do not activate'
assert not r['exclusions'] or sys.argv[2]=='--accept-exclusions', 'Review exclusions.csv first; explicitly accept documented omissions with --accept-exclusions'
installed=Path('/opt/twistinglogger/config.toml')
assert installed.read_bytes()==(p/'installed-config.toml').read_bytes(), 'Installed config changed since trial'
a=tomllib.loads(installed.read_text()); b=tomllib.loads(c.read_text())
assert a['plc']['address']==b['plc']['address'], 'Candidate targets a different PLC'
assert not b['application']['mock_mode'], 'Candidate is not live'
assert a['application']['data_dir']==b['application']['data_dir'], 'Data directory changed'
print('Candidate and trial match. Proceeding with backed-up update.')
PY
backup="/opt/twistinglogger/rollback-$(date +%Y%m%d-%H%M%S).tar"
"$py" - "$backup" <<'PY'
import sys,tarfile
from pathlib import Path
root=Path('/opt/twistinglogger')
paths=[p for p in root.iterdir() if p.is_file() and p.suffix in ('.py','.sh','.toml','.md','.txt')]
paths += [root/'VERSION']
paths += list(Path('/etc/systemd/system').glob('twistinglogger*.service'))
paths += list(Path('/etc/systemd/system').glob('twistinglogger*.timer'))
with tarfile.open(sys.argv[1],'w') as out:
 for p in paths:
  if p.exists(): out.add(p,arcname=str(p).lstrip('/'))
PY
chmod 0600 "$backup"
was_active=false
systemctl is-active --quiet twistinglogger.service && was_active=true
rollback() {
  echo "Update failed; restoring $backup"
  systemctl stop twistinglogger.service || true
  tar -xf "$backup" -C /
  systemctl daemon-reload
  if "$was_active"; then systemctl start twistinglogger.service; fi
}
trap rollback ERR
bash ./install.sh --offline
install -m 0644 "$review/discovery/candidate.toml" /opt/twistinglogger/config.toml
systemctl enable --now twistinglogger.service
sleep 2
systemctl is-active --quiet twistinglogger.service
trap - ERR
echo "Update started. Rollback archive: $backup"
echo 'Check status.json after one minute; verify live timestamps, quality, and read durations.'
