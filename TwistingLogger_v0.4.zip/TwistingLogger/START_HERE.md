# TwistingLogger 0.4 — TW2 first, then TW1

This package is staged software, not a Raspberry Pi OS image. No PLC writes,
downloads, mode changes, or drive parameter changes are performed by its Python
tools. Reads still consume PLC communication resources. Observe controller scan
and communication health during the trial. No physical PLC was available for
the package's offline tests.

## What it collects

Keeps existing configured groups and rates. Live discovery retrieves controller
AND program-scoped symbols and expands public structures/arrays into scalar
addresses. Every candidate is read once. Readable payoff drive I/O members,
motor monitor members, dancer positions and selected payoff run/brake/speed
arrays join fast_dynamics (existing rate, normally 100 ms). Remaining readable
scalar values start at 30 seconds. Existing 1-second and 10-second groups remain.
Some promoted values also remain in their original groups for continuity.

This means all discoverable/readable public scalar tags, NOT every parameter
inside every drive or every hidden PLC member. The report lists known missing
roots, unavailable types, and failed reads. A successful read does not establish
that a value is meaningful or actively updated. Strings are stored as text;
the trend viewer plots numerical/Boolean columns. Integer status words are
recorded as words as well as individually exposed Boolean members; arbitrary
integer bits are not independently duplicated.

The attached TW2 reference contains root names from the Oct 20, 2026 L5K export
and mapped drive members. Live metadata determines types/member addresses.
Compare the reference against TW1; differences are reported, not assumed away.
Program/AOI private internals and fields not exposed by the driver are not
guaranteed. Enumeration failure produces no candidate. Unknown types are reported.

Payoff TPTO02_MTR_PO[i].f_Spd_me is OutputFreq / 100: Hz, despite its RPM
description. It is electrical output frequency, not measured mechanical RPM.
Current f_Ampere is OutputCurrent / 100: A. Raw fields retain raw units.

## TW2: stage from Windows PowerShell

Download and extract TwistingLogger_v0.4.zip into Downloads. Run this in WINDOWS
PowerShell, not in the Pi SSH session (adjust the folder if saved elsewhere):

```powershell
scp -r "$env:USERPROFILE\Downloads\TwistingLogger_v0.4\TwistingLogger" twistinglogger@192.168.20.141:~/TwistingLogger_v0.4
ssh twistinglogger@192.168.20.141
```

The following commands run ON THE PI:

```bash
cd ~/TwistingLogger_v0.4
sudo bash prepare_existing.sh
```

This pauses the old logger while enumerating and reading tags and running a
180-second trial. Enumeration may take several minutes for large arrays. There
will be a recording gap in the normal historian; trial samples are separately
retained under review-YYYYMMDD-HHMMSS/trial/data. EXIT restores the prior running
state, including after a normal command failure/Ctrl+C. Power loss/SIGKILL cannot
execute a shell trap; after reconnect, check systemctl is-active twistinglogger.
The new package does not change installed code/config during preparation.

Find your actual review folder name in the terminal. Do not activate yet: send
discovery/report.json, discovery/exclusions.csv, trial/trial_report.json,
installed-version.txt, timers.txt and disk.txt for review. If preparation failed,
send discovery.log/trial.log. These files are inside the timestamped review folder.

For example, after exiting SSH, copy reports to Windows (replace timestamp):

```powershell
scp -r twistinglogger@192.168.20.141:~/TwistingLogger_v0.4/review-20261020-120000 "$env:USERPROFILE\Downloads\TW2-review"
```

This copies the trial database too. You can attach just the small reports above.

The trial gate requires >=3 samples per group, zero bad/dropped samples, read
p95 below 80% of interval, and no intersample gap >=2 intervals. Passing is a
logger performance check, not proof of zero impact on PLC execution. A failed
gate needs tuning; do not hide it by simply bypassing the check. Storage estimate
is rough and excludes exports. Commission while the machine runs and stops to
check changing signal behavior. 30-second logging will miss shorter transitions.

## TW2: activate only after reviewing results

On the Pi, substitute the real review folder:

```bash
cd ~/TwistingLogger_v0.4
sudo bash update_existing.sh review-20261020-120000
```

If documented exclusions are acceptable, use the explicit form:

```bash
sudo bash update_existing.sh review-20261020-120000 --accept-exclusions
```

This checks the candidate hash against the trial, preserves the installed
address/data directory, creates a rollback archive, installs offline using the
existing Python environment, and starts the service. No history, Samba accounts,
network configuration, or export files are deleted. The hyphenated export timer
is installed; review timers.txt for older custom/underscore timers to avoid
duplicate exports. Existing customized scripts/units are backed up; review them
before activation if the installed version differs from 0.3.

After one minute:

```bash
systemctl is-active twistinglogger.service
cat /opt/twistinglogger/status.json
systemctl list-timers --all --no-pager
```

Check timestamps advance, all groups are live/good, no dropped samples, and slow
group read duration fits its 30-second interval. Old CSVs remain compatible. New
groups/changed definitions produce additional CSV files; select their tags in
the viewer. Use trial data or a short early export to confirm new numerical tags.

## Roll back

Use the exact rollback filename printed during update:

```bash
sudo systemctl stop twistinglogger.service
sudo tar -xf /opt/twistinglogger/rollback-20261020-120000.tar -C /
sudo systemctl daemon-reload
sudo systemctl start twistinglogger.service
```

No historical database deletion is needed. Samples from both configurations
remain separate group definitions in the same daily database.

## Early export, including an explicit date example

```bash
/opt/twistinglogger/venv/bin/python /opt/twistinglogger/export_zip.py --day 2026-10-20 --force
```

Date format is YYYY-MM-DD. Nightly exports now use --force so an early partial
ZIP is replaced with the later full-day export. ZIP entries support >2 GiB CSVs.

## Capacity and low-space behavior

Discovery raises the free-space reserve to at least 10 GiB. Below that reserve,
logging stops and records an error, preserving existing history. systemd retries,
but startup checks disk space before opening a PLC connection. No automatic
deletion/retention is enabled. Archive old files deliberately and measure storage
growth after a full day; a 1 TB/1.5 TB card does not determine retention without
that measurement. Check actual expanded filesystem capacity using df -h.

## TW1: new 1 TB card, after TW2 succeeds

1. Keep the existing TW1 card untouched as rollback. Fully shut down the Pi
   before removing a card.
2. Preferred exact-copy route: make a powered-off image of the OLD TW1 card and
   restore it to the new TW1 card. Confirm source image fits the destination and
   expand the filesystem afterward if needed. This preserves the correct TW1
   network, Samba credentials, Python packages, logging/export services and data.
   Do not use the TW2 image unchanged: its .20 address/configuration is different.
3. Alternatively flash Raspberry Pi OS 64-bit, configure user twistinglogger,
   SSH, timezone America/New_York, and approved Ethernet address 192.168.10.141.
   With temporary internet, copy this package, run sudo bash install.sh, set
   /opt/twistinglogger/config.toml PLC address to 192.168.10.10, and run
   sudo bash /opt/twistinglogger/setup_sharing.sh to create loggerreader access.
   The sharing script's final printed .20 example should be read as .10 for TW1.
4. Boot only ONE device with 192.168.10.141. Repeat prepare_existing.sh on TW1
   against its installed config, review its own report/trial, then activate its
   own candidate with update_existing.sh. Fresh install has no active old logger
   for preparation to resume; activation enables it.
5. Verify PLC identity/address, live readings, timestamps, exports/share access,
   and reboot recovery before declaring the swap complete. Windows share:
   \\192.168.10.141\TwistingLogger. TW2 remains \\192.168.20.141\TwistingLogger.

The delivered ZIP is not a bootable image. We will walk through the chosen
card-preparation route after the TW2 reports have been reviewed.
