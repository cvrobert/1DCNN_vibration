from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json
import math
import numpy as np
import pandas as pd

from config import (
    MODELS_DIR, PROCESSED_DIR, VIBRATION_COLUMNS, SPEED_COLUMN,
    SEQUENCE_SECONDS, SEQUENCE_STEP_SECONDS, MIN_WINDOW_COMPLETENESS,
    BASELINE_EXCLUSION_HOURS, CNN_EPOCHS, CNN_BATCH_SIZE, CNN_LEARNING_RATE,
    CNN_LATENT_DIM, CNN_THRESHOLD_QUANTILE, CNN_MIN_TRAIN_SEQUENCES,
    RANDOM_SEED,
)
from src.failure_library import load_failures

try:
    import torch
    from torch import nn
    from torch.utils.data import DataLoader, TensorDataset
except ImportError:  # graceful message rather than breaking all V2 functionality
    torch = None
    nn = None
    DataLoader = TensorDataset = None

CHANNELS = [SPEED_COLUMN, *VIBRATION_COLUMNS]


def require_torch() -> None:
    if torch is None:
        raise ImportError(
            "The V3 1D CNN requires PyTorch. Activate the virtual environment and run "
            "'python -m pip install -r requirements.txt'."
        )


def _excluded_mask(times: pd.Series, hours: float = BASELINE_EXCLUSION_HOURS) -> np.ndarray:
    failures = load_failures()
    mask = np.zeros(len(times), dtype=bool)
    if failures.empty:
        return mask
    t = pd.to_datetime(times)
    for ft in pd.to_datetime(failures["failure_time"], errors="coerce").dropna():
        mask |= ((t >= ft - pd.Timedelta(hours=hours)) & (t <= ft)).to_numpy()
    return mask


def build_sequences(runs: pd.DataFrame, exclude_pre_failure: bool = False) -> tuple[np.ndarray, pd.DataFrame]:
    """Create fixed-length [N, channels, time] tensors from steady-running 1 Hz data."""
    rows: list[dict] = []
    arrays: list[np.ndarray] = []
    steady = runs[runs["steady_running"]].copy()
    needed = ["Timestamp", "run_id", *CHANNELS]
    steady = steady.dropna(subset=needed)

    for run_id, run in steady.groupby("run_id"):
        run = run.sort_values("Timestamp").reset_index(drop=True)
        if len(run) < SEQUENCE_SECONDS:
            continue
        start = run["Timestamp"].iloc[0]
        last = run["Timestamp"].iloc[-1]
        while start + pd.Timedelta(seconds=SEQUENCE_SECONDS - 1) <= last:
            end = start + pd.Timedelta(seconds=SEQUENCE_SECONDS - 1)
            block = run[(run["Timestamp"] >= start) & (run["Timestamp"] <= end)]
            if len(block) / SEQUENCE_SECONDS < MIN_WINDOW_COMPLETENESS:
                start += pd.Timedelta(seconds=SEQUENCE_STEP_SECONDS); continue
            if len(block) != SEQUENCE_SECONDS:
                block = (block.set_index("Timestamp")[CHANNELS]
                         .reindex(pd.date_range(start, end, freq="1s"))
                         .interpolate(limit=5, limit_direction="both"))
                if block.isna().any().any():
                    start += pd.Timedelta(seconds=SEQUENCE_STEP_SECONDS); continue
                values = block.to_numpy(float)
            else:
                values = block[CHANNELS].to_numpy(float)
            center = start + pd.Timedelta(seconds=SEQUENCE_SECONDS / 2)
            arrays.append(values.T.astype(np.float32))
            rows.append({"run_id": int(run_id), "window_start": start, "window_end": end,
                         "window_center": center, "speed_mean": float(values[:, 0].mean())})
            start += pd.Timedelta(seconds=SEQUENCE_STEP_SECONDS)

    if not arrays:
        return np.empty((0, len(CHANNELS), SEQUENCE_SECONDS), dtype=np.float32), pd.DataFrame(rows)
    x = np.stack(arrays)
    meta = pd.DataFrame(rows)
    if exclude_pre_failure:
        keep = ~_excluded_mask(meta["window_center"])
        x, meta = x[keep], meta.loc[keep].reset_index(drop=True)
    return x, meta


class ConvAutoencoder(nn.Module):
    def __init__(self, channels: int, latent_dim: int = CNN_LATENT_DIM):
        super().__init__()
        self.encoder_conv = nn.Sequential(
            nn.Conv1d(channels, 32, 7, stride=2, padding=3), nn.ReLU(),
            nn.Conv1d(32, 64, 5, stride=2, padding=2), nn.ReLU(),
            nn.Conv1d(64, 96, 5, stride=2, padding=2), nn.ReLU(),
            nn.AdaptiveAvgPool1d(1),
        )
        self.to_latent = nn.Linear(96, latent_dim)
        self.from_latent = nn.Linear(latent_dim, 96 * math.ceil(SEQUENCE_SECONDS / 8))
        self.decoder = nn.Sequential(
            nn.ConvTranspose1d(96, 64, 4, stride=2, padding=1), nn.ReLU(),
            nn.ConvTranspose1d(64, 32, 4, stride=2, padding=1), nn.ReLU(),
            nn.ConvTranspose1d(32, channels, 4, stride=2, padding=1),
        )

    def encode(self, x):
        h = self.encoder_conv(x).squeeze(-1)
        return self.to_latent(h)

    def forward(self, x):
        z = self.encode(x)
        length = math.ceil(SEQUENCE_SECONDS / 8)
        h = self.from_latent(z).view(x.shape[0], 96, length)
        y = self.decoder(h)
        return y[..., :x.shape[-1]], z


@dataclass
class SequenceAssets:
    mean: np.ndarray
    scale: np.ndarray
    threshold: float
    score_reference: np.ndarray


def _normalize(x: np.ndarray, mean: np.ndarray, scale: np.ndarray) -> np.ndarray:
    return (x - mean[None, :, None]) / scale[None, :, None]


def train_cnn(runs: pd.DataFrame) -> pd.DataFrame:
    require_torch()
    torch.manual_seed(RANDOM_SEED); np.random.seed(RANDOM_SEED)
    x, meta = build_sequences(runs, exclude_pre_failure=True)
    if len(x) < CNN_MIN_TRAIN_SEQUENCES:
        raise ValueError(f"Only {len(x)} verified-healthy sequences were available; at least {CNN_MIN_TRAIN_SEQUENCES} are required.")

    mean = np.median(x, axis=(0, 2)).astype(np.float32)
    q25 = np.percentile(x, 25, axis=(0, 2)); q75 = np.percentile(x, 75, axis=(0, 2))
    scale = np.maximum((q75 - q25) / 1.349, 1e-6).astype(np.float32)
    xn = _normalize(x, mean, scale).astype(np.float32)

    model = ConvAutoencoder(len(CHANNELS))
    loader = DataLoader(TensorDataset(torch.from_numpy(xn)), batch_size=CNN_BATCH_SIZE, shuffle=True)
    optimizer = torch.optim.Adam(model.parameters(), lr=CNN_LEARNING_RATE)
    loss_fn = nn.SmoothL1Loss()
    history = []
    model.train()
    for epoch in range(CNN_EPOCHS):
        losses = []
        for (batch,) in loader:
            optimizer.zero_grad(); reconstructed, _ = model(batch)
            loss = loss_fn(reconstructed, batch); loss.backward(); optimizer.step()
            losses.append(float(loss.detach()))
        history.append(float(np.mean(losses)))
        print(f"CNN epoch {epoch+1:02d}/{CNN_EPOCHS}: loss={history[-1]:.6f}")

    model.eval()
    with torch.no_grad():
        tx = torch.from_numpy(xn)
        recon, emb = model(tx)
        errors = ((recon - tx) ** 2).mean(dim=(1, 2)).numpy()
        embeddings = emb.numpy()
    threshold = float(np.quantile(errors, CNN_THRESHOLD_QUANTILE))
    reference = np.sort(errors)

    MODELS_DIR.mkdir(parents=True, exist_ok=True)
    torch.save({"state_dict": model.state_dict(), "mean": mean, "scale": scale,
                "threshold": threshold, "score_reference": reference,
                "channels": CHANNELS, "sequence_seconds": SEQUENCE_SECONDS,
                "latent_dim": CNN_LATENT_DIM, "version": "3.0"}, MODELS_DIR / "cnn_autoencoder.pt")
    pd.DataFrame({"epoch": np.arange(1, len(history)+1), "loss": history}).to_csv(PROCESSED_DIR / "cnn_training_history.csv", index=False)
    meta["cnn_reconstruction_error"] = errors
    meta["cnn_anomaly_percentile"] = np.searchsorted(reference, errors, side="right") / len(reference)
    for i in range(embeddings.shape[1]): meta[f"embedding_{i}"] = embeddings[:, i]
    meta.to_csv(PROCESSED_DIR / "cnn_healthy_embeddings.csv", index=False)
    return meta


def score_cnn(runs: pd.DataFrame) -> pd.DataFrame:
    require_torch()
    path = MODELS_DIR / "cnn_autoencoder.pt"
    if not path.exists(): raise FileNotFoundError("Train the V3 CNN before scoring current data.")
    saved = torch.load(path, map_location="cpu", weights_only=False)
    x, meta = build_sequences(runs, exclude_pre_failure=False)
    if len(x) == 0: return meta
    model = ConvAutoencoder(len(saved["channels"]), saved.get("latent_dim", CNN_LATENT_DIM))
    model.load_state_dict(saved["state_dict"]); model.eval()
    xn = _normalize(x, saved["mean"], saved["scale"]).astype(np.float32)
    with torch.no_grad():
        tx = torch.from_numpy(xn); recon, emb = model(tx)
        errors = ((recon - tx) ** 2).mean(dim=(1, 2)).numpy(); embeddings = emb.numpy()
    ref = np.asarray(saved["score_reference"])
    meta["cnn_reconstruction_error"] = errors
    meta["cnn_anomaly_percentile"] = np.searchsorted(ref, errors, side="right") / len(ref)
    meta["cnn_is_anomaly_raw"] = errors >= float(saved["threshold"])
    for i in range(embeddings.shape[1]): meta[f"embedding_{i}"] = embeddings[:, i]
    return meta


def align_cnn_scores(feature_scores: pd.DataFrame, cnn_scores: pd.DataFrame) -> pd.DataFrame:
    """Align CNN output to engineered-feature windows by nearest center timestamp."""
    out = feature_scores.sort_values("window_center").copy()
    if cnn_scores.empty:
        out["cnn_anomaly_percentile"] = np.nan; out["cnn_reconstruction_error"] = np.nan
        out["cnn_is_anomaly_raw"] = False
        return out
    c = cnn_scores.sort_values("window_center")[["window_center", "cnn_anomaly_percentile", "cnn_reconstruction_error", "cnn_is_anomaly_raw"]]
    return pd.merge_asof(out, c, on="window_center", direction="nearest", tolerance=pd.Timedelta(seconds=SEQUENCE_STEP_SECONDS/2))
