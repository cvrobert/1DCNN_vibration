# Strander Predictive Maintenance V3 — Hybrid Research/Engineering Edition

V3 combines two independent views of machine condition:

1. **Explainable statistical baseline** — speed-adjusted engineered features, operating-regime clustering, and Isolation Forest anomaly scoring.
2. **1D convolutional neural network** — a convolutional autoencoder trained directly on 300-second multichannel sequences containing speed plus eight vibration channels.

The CNN is intentionally trained first as a **healthy-sequence autoencoder**, not a supervised failure classifier. This lets it learn useful temporal structure immediately from abundant healthy data without pretending that fourteen failures are enough for a reliable deep classifier. As confirmed failures accumulate, the saved latent embeddings provide the foundation for supervised classification, metric learning, or failure-prototype matching without changing the import, preprocessing, dashboard, or decision architecture.

## Decision guardrails

A high historical resemblance is not a failure probability. V3 only issues an actionable historical-failure warning when:

- current behavior is abnormal versus verified healthy operation;
- the abnormality persists across consecutive windows;
- the matching historical phase contains predictive abnormal evidence; and
- resemblance exceeds the configured actionable threshold.

The statistical and CNN percentiles are fused at configurable weights (default 55% statistical and 45% CNN). Both are shown independently in the dashboard.

## Recommended run order

```text
1) Validate historian import and failure timestamps
2) Train healthy statistical baseline
3) Train 1D CNN healthy-sequence model
4) Build phase-aware failure fingerprints
5) Analyze current data and open dashboard
```

## Installation

Windows PowerShell:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python main.py
```

PyTorch is the largest dependency and may take several minutes to install. The program retains the V2 statistical path if the CNN has not yet been trained, but full V3 hybrid scoring requires PyTorch and menu option 3.

## Data folders

- `data/historical/` — AVEVA CSV/XLSX history used for model training
- `data/current/` — the current period to analyze
- `data/failures.csv` — confirmed failure timestamps and metadata

Large historian exports are not included in the distribution ZIP.

## Timestamp quality-of-life handling

The importer explicitly handles common AVEVA and Excel timestamp forms, including:

- US month/day with 12-hour AM/PM
- 24-hour timestamps
- ISO timestamps
- fractional seconds
- timezone-bearing strings
- Excel serial date values
- mixed formats within one export

It also reports parse success and validates every failure timestamp against the available historian range.

## Model artifacts

- `models/phase1_assets.joblib` — explainable statistical baseline
- `models/cnn_autoencoder.pt` — trained 1D CNN, robust channel normalization, threshold, and healthy score reference
- `processed/cnn_healthy_embeddings.csv` — learned latent representations for future failure-learning work
- `processed/cnn_training_history.csv` — training loss by epoch

## Important interpretation

The CNN percentile means: **how unusual the raw temporal sequence is compared with the verified-healthy sequences used to train the CNN**. It does not mean probability of failure.

The statistical percentile means: **how unusual the speed-adjusted engineered features are compared with the verified-healthy feature distribution**.

The hybrid score is a decision-support evidence score, not a calibrated probability.
