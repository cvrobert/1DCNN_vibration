from pathlib import Path
import pandas as pd

from config import (
    HISTORICAL_DATA_DIR, CURRENT_DATA_DIR, PROCESSED_DIR, OUTPUTS_DIR,
    SPEED_COLUMN, VIBRATION_COLUMNS,
)
from src.utils import ensure_project_folders, print_banner
from src.import_data import import_folder, long_to_wide
from src.preprocess import clean_and_resample, identify_runs
from src.features import build_windows
from src.phase1 import train_phase1, score_phase1
from src.failure_library import (
    build_failure_fingerprints, load_failures, validate_failure_time_coverage,
)
from src.phase3 import compare_current_to_failures
from src.sequence_model import train_cnn, score_cnn, align_cnn_scores
from src.decision_engine import evaluate_machine
from src.visualize import save_anomaly_plot, create_sensor_status_table, create_text_report
from src.dashboard import generate_dashboard


def prepare_folder(folder: Path) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    long_df = import_folder(folder)
    if long_df.empty:
        raise ValueError(f"No usable historian files were found in {folder.resolve()}")
    wide = long_to_wide(long_df, SPEED_COLUMN, VIBRATION_COLUMNS)
    clean = clean_and_resample(wide)
    runs = identify_runs(clean)
    windows = build_windows(runs)
    if windows.empty:
        raise ValueError("No valid steady-running windows were produced. Check speed threshold, data gaps, and run duration.")
    return windows, wide, runs


def validate_import() -> None:
    print_banner("VALIDATE HISTORIAN IMPORT AND TIMESTAMPS")
    long_df = import_folder(HISTORICAL_DATA_DIR)
    if long_df.empty:
        print("No usable files found. Place AVEVA exports in data/historical.")
        return
    wide = long_to_wide(long_df, SPEED_COLUMN, VIBRATION_COLUMNS)
    start, end = wide["Timestamp"].min(), wide["Timestamp"].max()
    print(f"\nHistorian range: {start} to {end}")
    print("\nUsable rows by tag:")
    print(long_df["ModelColumn"].value_counts().to_string())
    print("\nMissing values after pivot:")
    print(wide.isna().sum().to_string())

    coverage = validate_failure_time_coverage(start, end)
    if not coverage.empty:
        print("\nFailure timestamp coverage:")
        print(coverage[["failure_id", "failure_time", "coverage_status"]].to_string(index=False))
        coverage.to_csv(PROCESSED_DIR / "failure_timestamp_validation.csv", index=False)
    sample = PROCESSED_DIR / "import_validation_sample.csv"
    wide.head(5000).to_csv(sample, index=False)
    print(f"\nSaved validation sample: {sample.resolve()}")


def train_normal_baseline() -> None:
    print_banner("PHASE 1 — TRAIN VERIFIED HEALTHY BASELINE")
    windows, wide, runs = prepare_folder(HISTORICAL_DATA_DIR)
    scored = train_phase1(windows)
    scored.to_csv(PROCESSED_DIR / "historical_window_scores.csv", index=False)
    scored.sort_values("anomaly_percentile", ascending=False).head(500).to_csv(
        OUTPUTS_DIR / "phase1_top_500_anomaly_windows.csv", index=False
    )
    save_anomaly_plot(scored, "phase1_historical_anomaly_plot.png", "Historical deviation from healthy baseline")
    excluded = int(scored["baseline_excluded_pre_failure"].sum())
    healthy = len(scored) - excluded
    print(f"Total feature windows: {len(scored):,}")
    print(f"Pre-failure windows excluded from healthy training: {excluded:,}")
    print(f"Verified healthy training candidates: {healthy:,}")
    print(f"Persistent anomaly windows across complete history: {int(scored['persistent_anomaly'].sum()):,}")



def train_sequence_model() -> None:
    print_banner("V3 — TRAIN 1D CNN HEALTHY-SEQUENCE MODEL")
    _, _, runs = prepare_folder(HISTORICAL_DATA_DIR)
    scored = train_cnn(runs)
    print(f"Verified-healthy sequences used: {len(scored):,}")
    print(f"Final CNN reconstruction threshold percentile: 99.5%")
    print("The CNN learns normal temporal behavior from raw speed and all eight vibration channels.")


def build_failure_patterns() -> None:
    print_banner("PHASE 2 — BUILD PHASE-AWARE FAILURE FINGERPRINTS")
    path = PROCESSED_DIR / "historical_window_scores.csv"
    if not path.exists():
        raise FileNotFoundError("Run Phase 1 first.")
    scored = pd.read_csv(path)
    for c in ("window_start", "window_end", "window_center"):
        scored[c] = pd.to_datetime(scored[c], errors="coerce")
    fingerprints = build_failure_fingerprints(scored)
    if fingerprints.empty:
        print("No usable failure fingerprints were produced.")
        return
    print(f"Built {len(fingerprints):,} phase fingerprints from {fingerprints['failure_id'].nunique():,} failures.")
    print(f"Fingerprints with actual predictive abnormality: {int(fingerprints['predictive_evidence'].sum()):,}")
    print("\nImportant: fingerprints without predictive evidence remain available for context, but cannot trigger warnings.")
    print(fingerprints[["failure_id", "phase", "window_count", "anomaly_fraction", "predictive_evidence"]].to_string(index=False))


def analyze_current_data(open_dashboard: bool = True) -> None:
    print_banner("PHASE 3 — HEALTH-FIRST CURRENT ANALYSIS")
    windows, _, runs = prepare_folder(CURRENT_DATA_DIR)
    scored = score_phase1(windows)
    try:
        cnn_scored = score_cnn(runs)
        cnn_scored.to_csv(OUTPUTS_DIR / "current_cnn_scores.csv", index=False)
        scored = align_cnn_scores(scored, cnn_scored)
    except (FileNotFoundError, ImportError) as exc:
        print(f"CNN note: {exc}")
        scored["cnn_anomaly_percentile"] = float("nan")
        scored["cnn_reconstruction_error"] = float("nan")
        scored["cnn_is_anomaly_raw"] = False
    scored.to_csv(OUTPUTS_DIR / "current_scored_windows.csv", index=False)
    save_anomaly_plot(scored, "current_anomaly_plot.png", "Current deviation from healthy baseline")
    sensor_table = create_sensor_status_table(scored)

    fp_path = PROCESSED_DIR / "failure_fingerprints.csv"
    comparison = pd.DataFrame()
    if fp_path.exists():
        fingerprints = pd.read_csv(fp_path)
        if "failure_time" in fingerprints:
            fingerprints["failure_time"] = pd.to_datetime(fingerprints["failure_time"], errors="coerce")
        comparison = compare_current_to_failures(scored, fingerprints)

    assessment = evaluate_machine(scored, comparison)
    pd.DataFrame([assessment]).to_csv(OUTPUTS_DIR / "current_assessment.csv", index=False)
    create_text_report(scored, comparison, assessment)

    print(f"\nCondition: {assessment['condition']}")
    print(f"Health score: {assessment['health_score']}/100")
    print(f"Trend: {assessment['trend']}")
    print(f"Persistent anomaly active: {assessment['active_persistent_anomaly']}")
    print(f"Failure warning: {assessment['failure_warning']}")
    print(f"Recommendation: {assessment['action']}")
    print("\nMost elevated sensors:")
    print(sensor_table.head(8).to_string(index=False))
    if not comparison.empty:
        cols = ["failure_id", "failure_type", "phase", "resemblance", "predictive_evidence", "top_matching_sensors"]
        print("\nClosest historical patterns (resemblance is not probability):")
        print(comparison[cols].head(5).to_string(index=False))
    if open_dashboard:
        generate_dashboard(Path(__file__).resolve().parent, open_browser=True)


def show_menu() -> None:
    ensure_project_folders()
    while True:
        print_banner("STRANDER PREDICTIVE MAINTENANCE V3 — HYBRID")
        print("1) Validate historian import and failure timestamps")
        print("2) Train healthy baseline")
        print("3) Train 1D CNN healthy-sequence model")
        print("4) Build phase-aware failure fingerprints")
        print("5) Analyze current data and open dashboard")
        print("6) Open existing dashboard")
        print("7) Show project folders")
        print("8) Exit")
        choice = input("\nSelection: ").strip()
        try:
            if choice == "1": validate_import()
            elif choice == "2": train_normal_baseline()
            elif choice == "3": train_sequence_model()
            elif choice == "4": build_failure_patterns()
            elif choice == "5": analyze_current_data(True)
            elif choice == "6": generate_dashboard(Path(__file__).resolve().parent, True)
            elif choice == "7":
                print(f"Historical: {HISTORICAL_DATA_DIR.resolve()}")
                print(f"Current: {CURRENT_DATA_DIR.resolve()}")
                print(f"Processed: {PROCESSED_DIR.resolve()}")
                print(f"Outputs: {OUTPUTS_DIR.resolve()}")
            elif choice == "8": break
            else: print("Enter a number from 1 through 8.")
        except Exception as exc:
            print(f"\nERROR: {type(exc).__name__}: {exc}")
        input("\nPress Enter to return to the menu...")


if __name__ == "__main__":
    show_menu()
