# V3 additions

- Added a real 1D CNN convolutional autoencoder operating on raw 1 Hz multichannel sequences.
- Uses speed plus all eight vibration channels.
- Excludes configured pre-failure periods from healthy CNN training.
- Uses robust median/IQR channel normalization to reduce sensitivity to outliers and sensor scale differences.
- Saves latent embeddings so later supervised or metric-learning stages can grow without redesigning the pipeline.
- Fuses statistical and CNN anomaly evidence while retaining separate dashboard traces.
- Keeps historical resemblance subordinate to independent anomaly and persistence checks.
- Preserves robust mixed-format timestamp parsing and failure-range validation.
