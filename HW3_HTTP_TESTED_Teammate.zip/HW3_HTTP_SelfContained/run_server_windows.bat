@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %ERRORLEVEL%==0 (
  py -3 http_server.py %*
) else (
  python http_server.py %*
)
