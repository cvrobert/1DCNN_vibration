#!/usr/bin/env python3
"""ECE/CSC 571 HW3 - self-contained HTTP file server.
Uses only the Python standard library.
"""

from __future__ import annotations

import argparse
import socket
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
ALLOWED_FILES = {"100B", "10KB", "1MB", "10MB"}


def best_local_ip() -> str:
    """Best-effort LAN IP detection without requiring Internet access."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # UDP connect chooses a local interface; no packet needs to be sent.
        s.connect(("192.0.2.1", 9))
        ip = s.getsockname()[0]
        if ip and not ip.startswith("127."):
            return ip
    except OSError:
        pass
    finally:
        s.close()

    try:
        ip = socket.gethostbyname(socket.gethostname())
        if ip and not ip.startswith("127."):
            return ip
    except OSError:
        pass
    return "<server LAN IP>"


class HW3HTTPServer(ThreadingHTTPServer):
    """Threading HTTP server with Nagle disabled on accepted sockets.

    This avoids a delayed-ACK/Nagle interaction that can add ~40 ms to tiny
    HTTP responses and distort the 100 B / 10 KB measurements.
    """

    def get_request(self):
        request, client_address = super().get_request()
        request.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        return request, client_address


class HW3Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "ECE571-HW3"
    sys_version = ""

    def log_message(self, format: str, *args) -> None:
        # Suppress one console line per request; 11,110 requests would be noisy.
        return

    def _send_text(self, code: int, text: str) -> None:
        body = text.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:
        path = unquote(urlparse(self.path).path).lstrip("/")
        if path not in ALLOWED_FILES:
            self._send_text(404, "Use /100B, /10KB, /1MB, or /10MB\n")
            return

        file_path = DATA_DIR / path
        if not file_path.is_file():
            self._send_text(404, f"Missing server file: {path}\n")
            return

        size = file_path.stat().st_size
        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Content-Length", str(size))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()

        with file_path.open("rb") as f:
            while True:
                chunk = f.read(256 * 1024)
                if not chunk:
                    break
                self.wfile.write(chunk)


def main() -> None:
    parser = argparse.ArgumentParser(description="ECE/CSC 571 HW3 HTTP server")
    parser.add_argument("--host", default="0.0.0.0", help="Bind address (default: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=8000, help="TCP port (default: 8000)")
    args = parser.parse_args()

    missing = [name for name in sorted(ALLOWED_FILES) if not (DATA_DIR / name).is_file()]
    if missing:
        raise SystemExit(f"Missing file(s) in {DATA_DIR}: {', '.join(missing)}")

    print("ECE/CSC 571 HW3 - HTTP SERVER")
    print(f"Serving files from: {DATA_DIR}")
    for name in ("100B", "10KB", "1MB", "10MB"):
        print(f"  {name:>4}: {(DATA_DIR / name).stat().st_size:,} bytes")
    print()
    print(f"Listening on port {args.port}")
    print(f"Client should use server IP: {best_local_ip()}")
    print("Press Ctrl+C to stop.\n")

    server = HW3HTTPServer((args.host, args.port), HW3Handler)
    server.daemon_threads = True
    try:
        server.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:
        print("\nServer stopped.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
