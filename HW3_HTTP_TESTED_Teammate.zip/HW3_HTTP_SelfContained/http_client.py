#!/usr/bin/env python3
"""ECE/CSC 571 HW3 - self-contained HTTP benchmark client.

Measures each HTTP transfer programmatically, records raw measurements to CSV,
calculates throughput in kilobits/second, and measures exact sender->receiver
HTTP application-layer bytes (status line + response headers + file body).
Uses only the Python standard library.
"""

from __future__ import annotations

import argparse
import csv
import socket
import statistics
import time
from datetime import datetime
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
RESULTS_DIR = BASE_DIR / "results"

FULL_EXPERIMENTS = [
    ("100B", 10_000),
    ("10KB", 1_000),
    ("1MB", 100),
    ("10MB", 10),
]

DEMO_EXPERIMENTS = [
    ("100B", 3),
    ("10KB", 3),
    ("1MB", 3),
    ("10MB", 3),
]


class HTTP11Connection:
    def __init__(self, host: str, port: int, timeout: float):
        self.host = host
        self.port = port
        self.timeout = timeout
        self.sock: socket.socket | None = None
        self.reader = None

    def connect(self) -> None:
        self.close()
        self.sock = socket.create_connection((self.host, self.port), timeout=self.timeout)
        self.sock.settimeout(self.timeout)
        # Small request/response benchmark: avoid Nagle delaying tiny writes.
        self.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        self.reader = self.sock.makefile("rb")

    def close(self) -> None:
        if self.reader is not None:
            try:
                self.reader.close()
            except OSError:
                pass
        self.reader = None
        if self.sock is not None:
            try:
                self.sock.close()
            except OSError:
                pass
        self.sock = None

    def _ensure_connected(self) -> None:
        if self.sock is None or self.reader is None:
            self.connect()

    def get(self, filename: str) -> dict:
        self._ensure_connected()
        assert self.sock is not None
        assert self.reader is not None

        request = (
            f"GET /{filename} HTTP/1.1\r\n"
            f"Host: {self.host}:{self.port}\r\n"
            "Accept: */*\r\n"
            "Connection: keep-alive\r\n"
            "\r\n"
        ).encode("ascii")

        start_ns = time.perf_counter_ns()
        self.sock.sendall(request)

        # Read and count the raw HTTP response status line + header bytes exactly.
        status_line = self.reader.readline()
        if not status_line:
            raise ConnectionError("Server closed the connection before sending a response")
        raw_header_bytes = len(status_line)
        try:
            parts = status_line.decode("iso-8859-1").rstrip("\r\n").split(" ", 2)
            status_code = int(parts[1])
        except (ValueError, IndexError) as exc:
            raise RuntimeError(f"Invalid HTTP status line: {status_line!r}") from exc

        headers: dict[str, str] = {}
        while True:
            line = self.reader.readline()
            if not line:
                raise ConnectionError("Server closed connection while sending HTTP headers")
            raw_header_bytes += len(line)
            if line in (b"\r\n", b"\n"):
                break
            name, sep, value = line.decode("iso-8859-1").partition(":")
            if sep:
                headers[name.strip().lower()] = value.strip()

        if status_code != 200:
            raise RuntimeError(f"HTTP request for {filename} failed with status {status_code}")
        if "content-length" not in headers:
            raise RuntimeError("Server response did not include Content-Length")

        expected_body_bytes = int(headers["content-length"])
        remaining = expected_body_bytes
        body_bytes = 0
        while remaining:
            chunk = self.reader.read(min(256 * 1024, remaining))
            if not chunk:
                raise ConnectionError(
                    f"Connection ended early for {filename}: received {body_bytes:,} of "
                    f"{expected_body_bytes:,} body bytes"
                )
            n = len(chunk)
            body_bytes += n
            remaining -= n

        end_ns = time.perf_counter_ns()
        elapsed_s = (end_ns - start_ns) / 1_000_000_000.0
        throughput_kbps = (body_bytes * 8.0) / elapsed_s / 1000.0
        app_layer_bytes = raw_header_bytes + body_bytes
        overhead_ratio = app_layer_bytes / body_bytes

        return {
            "payload_bytes": body_bytes,
            "elapsed_s": elapsed_s,
            "throughput_kbps": throughput_kbps,
            "response_header_bytes": raw_header_bytes,
            "app_layer_bytes": app_layer_bytes,
            "overhead_ratio": overhead_ratio,
        }


def main() -> None:
    parser = argparse.ArgumentParser(description="ECE/CSC 571 HW3 HTTP benchmark client")
    parser.add_argument("server", nargs="?", help="HTTP server IPv4 address or hostname")
    parser.add_argument("--port", type=int, default=8000, help="Server TCP port (default: 8000)")
    parser.add_argument("--timeout", type=float, default=30.0, help="Socket timeout seconds (default: 30)")
    parser.add_argument(
        "--demo",
        action="store_true",
        help="Run only 3 transfers per file to verify/demo the setup; NOT for final homework data",
    )
    parser.add_argument(
        "--new-connection",
        action="store_true",
        help="Open a new TCP connection for every HTTP transfer. Default reuses one HTTP/1.1 connection per file experiment.",
    )
    args = parser.parse_args()

    server = args.server or input("Enter the HTTP server IP address: ").strip()
    if not server:
        raise SystemExit("A server IP address or hostname is required.")

    experiments = DEMO_EXPERIMENTS if args.demo else FULL_EXPERIMENTS
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    raw_path = RESULTS_DIR / f"http_raw_{stamp}.csv"
    summary_path = RESULTS_DIR / f"http_summary_{stamp}.csv"

    print("\nECE/CSC 571 HW3 - HTTP CLIENT")
    print(f"Server: {server}:{args.port}")
    print(f"Mode: {'DEMO (3 transfers/file)' if args.demo else 'FULL HOMEWORK (11,110 total transfers)'}")
    print(f"TCP behavior: {'new connection per transfer' if args.new_connection else 'persistent HTTP/1.1 connection per file experiment'}")
    print(f"Raw output: {raw_path}")
    print()

    raw_fields = [
        "timestamp",
        "file_name",
        "transfer_number",
        "payload_bytes",
        "elapsed_seconds",
        "throughput_kbps",
        "response_header_bytes",
        "application_layer_bytes_sender_to_receiver",
        "application_layer_bytes_divided_by_file_size",
    ]

    all_summaries = []
    with raw_path.open("w", newline="", encoding="utf-8") as raw_file:
        writer = csv.DictWriter(raw_file, fieldnames=raw_fields)
        writer.writeheader()

        for filename, count in experiments:
            print(f"{filename}: running {count:,} transfers...")
            conn = HTTP11Connection(server, args.port, args.timeout)
            throughputs = []
            total_payload = 0
            total_app_layer = 0
            header_sizes = []

            try:
                if not args.new_connection:
                    conn.connect()

                for i in range(1, count + 1):
                    if args.new_connection:
                        conn.connect()
                    try:
                        r = conn.get(filename)
                    except (OSError, ConnectionError):
                        # One automatic reconnect/retry handles an idle/stale LAN connection
                        # without silently discarding the requested transfer.
                        conn.connect()
                        r = conn.get(filename)
                    finally:
                        if args.new_connection:
                            conn.close()

                    throughputs.append(r["throughput_kbps"])
                    total_payload += r["payload_bytes"]
                    total_app_layer += r["app_layer_bytes"]
                    header_sizes.append(r["response_header_bytes"])

                    writer.writerow({
                        "timestamp": datetime.now().isoformat(timespec="milliseconds"),
                        "file_name": filename,
                        "transfer_number": i,
                        "payload_bytes": r["payload_bytes"],
                        "elapsed_seconds": f"{r['elapsed_s']:.9f}",
                        "throughput_kbps": f"{r['throughput_kbps']:.6f}",
                        "response_header_bytes": r["response_header_bytes"],
                        "application_layer_bytes_sender_to_receiver": r["app_layer_bytes"],
                        "application_layer_bytes_divided_by_file_size": f"{r['overhead_ratio']:.9f}",
                    })

                    # Lightweight progress, especially useful for the 10,000-run test.
                    if count >= 1000 and (i % max(1, count // 10) == 0):
                        print(f"  {i:,}/{count:,} complete")
            finally:
                conn.close()

            avg = statistics.fmean(throughputs)
            std_sample = statistics.stdev(throughputs) if len(throughputs) > 1 else 0.0
            std_population = statistics.pstdev(throughputs) if len(throughputs) > 1 else 0.0
            ratio = total_app_layer / total_payload
            payload_one = total_payload // count

            summary = {
                "file_name": filename,
                "transfers": count,
                "file_size_bytes": payload_one,
                "average_throughput_kbps": avg,
                "sample_std_dev_throughput_kbps": std_sample,
                "population_std_dev_throughput_kbps": std_population,
                "average_response_header_bytes": statistics.fmean(header_sizes),
                "total_payload_bytes": total_payload,
                "total_application_layer_bytes_sender_to_receiver": total_app_layer,
                "application_layer_data_divided_by_file_size": ratio,
            }
            all_summaries.append(summary)
            print(
                f"  Average = {avg:,.3f} kbps | Sample SD = {std_sample:,.3f} kbps | "
                f"HTTP data/file ratio = {ratio:.9f}\n"
            )

    summary_fields = list(all_summaries[0].keys())
    with summary_path.open("w", newline="", encoding="utf-8") as summary_file:
        writer = csv.DictWriter(summary_file, fieldnames=summary_fields)
        writer.writeheader()
        for s in all_summaries:
            writer.writerow({
                k: (f"{v:.9f}" if isinstance(v, float) else v)
                for k, v in s.items()
            })

    print("=" * 76)
    print("VALUES FOR THE HTTP ROW OF Results File.xlsx")
    print("Use the Average and SAMPLE Std. Dev. throughput values below.")
    print("The last column shown for each file is the requested sender->receiver app-layer ratio.\n")
    print(f"{'File':<8}{'Average kbps':>18}{'Std Dev kbps':>18}{'App-layer ratio':>20}")
    for s in all_summaries:
        print(
            f"{s['file_name']:<8}"
            f"{s['average_throughput_kbps']:>18,.3f}"
            f"{s['sample_std_dev_throughput_kbps']:>18,.3f}"
            f"{s['application_layer_data_divided_by_file_size']:>20.9f}"
        )
    print("=" * 76)
    print(f"\nRaw measurements saved to: {raw_path}")
    print(f"Summary saved to:          {summary_path}")


if __name__ == "__main__":
    main()
