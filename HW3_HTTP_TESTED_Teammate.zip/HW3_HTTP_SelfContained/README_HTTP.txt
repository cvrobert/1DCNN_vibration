ECE/CSC 571 HW3 - HTTP TEST
===========================

This folder has everything needed for the HTTP part of HW3. No extra Python
packages are needed. Just copy the whole folder to the Raspberry Pi and the
laptop. The four test files are already in the data folder.

Recommended setup for our test:

    Raspberry Pi = HTTP server
    Windows laptop = HTTP client / results computer

Both devices need to be connected to the same local network.


BEFORE STARTING
---------------
1. Copy this entire HW3_HTTP_SelfContained folder to BOTH the Pi and laptop.
   Do not move the Python files out of the folder because they use the included
   data and results folders.

2. Make sure Python 3 is available.

   On the Pi, open Terminal and run:
       python3 --version

   On Windows, open PowerShell and run:
       py -3 --version

   If both commands show a Python 3 version, the setup is ready.

3. Put the Pi and laptop on the same Wi-Fi/LAN. Avoid a guest Wi-Fi network if
   possible because some guest networks block devices from talking to each
   other.


STEP 1 - START THE SERVER ON THE RASPBERRY PI
----------------------------------------------
Open Terminal on the Pi and change into this folder. For example, if the folder
is on the Desktop:

    cd ~/Desktop/HW3_HTTP_SelfContained

Then run:

    python3 http_server.py

Leave this terminal open for the entire test.

The server will show that it is listening on port 8000 and should print the Pi's
LAN IP address. It will look similar to:

    192.168.1.50

Write that address down. The laptop needs it in the next step.

If the address shown does not look right, open a second Pi terminal and run:

    hostname -I

Use the address that matches the local network. It will normally start with
192.168.x.x or 10.x.x.x.


STEP 2 - DO A SHORT TEST FROM THE WINDOWS LAPTOP
-------------------------------------------------
Do NOT start with the full 11,110-transfer run. First make sure the laptop can
reach the Pi.

Open PowerShell in the HW3_HTTP_SelfContained folder on the laptop.

One easy way to do this is:
- Open the folder in File Explorer.
- Click the address bar at the top.
- Type powershell and press Enter.

First try pinging the Pi:

    ping PI_IP

Example:

    ping 192.168.1.50

Then run the short HTTP test:

    py -3 http_client.py PI_IP --demo

Example:

    py -3 http_client.py 192.168.1.50 --demo

Demo mode only transfers each file 3 times. It is just there to make sure the
connection, files, timing, and result output are working.

DO NOT use the demo numbers in the final spreadsheet.

If Windows asks whether Python is allowed through the firewall, allow it on the
private/local network being used for the test.


STEP 3 - RUN THE ACTUAL HTTP EXPERIMENT
---------------------------------------
Once demo mode works, run:

    py -3 http_client.py PI_IP

Example:

    py -3 http_client.py 192.168.1.50

The program will automatically run the counts required for HW3:

    100B   = 10,000 transfers
    10KB   =  1,000 transfers
    1MB    =    100 transfers
    10MB   =     10 transfers

    Total  = 11,110 transfers

Do not close the Pi server terminal or disconnect either device while this is
running.

The client times every transfer separately and calculates throughput in kbps.
At the end it prints a four-row summary with:

- Average throughput
- Standard deviation of throughput
- HTTP application-layer data / file-size ratio

Those are the values needed for the HTTP section of Results File.xlsx.


WHERE THE RESULTS ARE SAVED
---------------------------
The laptop will create two CSV files inside the results folder:

    results/http_raw_YYYYMMDD_HHMMSS.csv
    results/http_summary_YYYYMMDD_HHMMSS.csv

The raw file has one row for every transfer. A complete run should have 11,110
measurements.

The summary file has one row for each of the four file sizes. Use the SAMPLE
standard deviation column when filling in our HTTP results so that it matches
what the program prints at the end.

Keep both CSV files with the project in case we need to show how the spreadsheet
numbers were calculated.


WHAT THE PROGRAM IS MEASURING
-----------------------------
For each request, the client starts timing immediately before it sends the HTTP
GET request and stops after the complete file has been received.

Throughput is calculated as:

    (file size in bytes x 8) / transfer time / 1000

This gives kilobits per second (kbps).

For the HTTP overhead part, the client counts the bytes sent from the server to
the client:

    HTTP response status/headers + file data

It does not count the GET request from the laptop to the Pi because that travels
in the opposite direction.

The ratio reported is:

    total HTTP response bytes / file bytes

The smaller files should have a noticeably larger ratio because the HTTP header
is large compared with the file itself. The ratio for the large files should be
very close to 1.


CONNECTION METHOD USED
----------------------
The normal command uses HTTP/1.1 keep-alive and reuses a TCP connection during
each file-size test. Each GET/file transfer is still timed separately.

Use the normal command for our results unless the group decides that every HTTP
request should create a brand-new TCP connection.

If we specifically decide to test a new TCP connection for every transfer, use:

    py -3 http_client.py PI_IP --new-connection

Do not mix the two methods in the same final results.


IF SOMETHING DOES NOT WORK
--------------------------
Connection refused:
- Make sure http_server.py is still running on the Pi.
- Recheck the Pi IP address.
- Make sure the client is using port 8000 (the default).

Timeout / cannot ping Pi:
- Make sure both devices are on the same network.
- Recheck the IP with "hostname -I" on the Pi.
- Avoid guest Wi-Fi/client-isolation networks.
- Check Windows firewall settings.

Wrong folder / file not found:
- Keep http_server.py, http_client.py, data, and results together in the same
  HW3_HTTP_SelfContained folder.

To stop the server:
    Ctrl+C


FILES IN THIS FOLDER
--------------------
http_server.py          HTTP server used on the Pi
http_client.py          HTTP test client used on the laptop
data/                   Four files supplied for HW3
results/                CSV results are written here
run_server_pi.sh        Optional Pi/Linux server launcher
run_client_pi.sh        Optional Pi/Linux client launcher
run_server_windows.bat  Optional Windows server launcher
run_client_windows.bat  Optional Windows client launcher

The Python scripts are the main files. The .sh and .bat files are just shortcuts
if we decide to swap which device is the server/client later.
