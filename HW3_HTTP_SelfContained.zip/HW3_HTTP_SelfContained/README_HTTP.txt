ECE/CSC 571 - HW3 HTTP SECTION
==============================

PURPOSE
-------
This folder is self-contained. It uses ONLY the Python standard library, so no
pip packages, Apache, IIS, Flask, Requests, or Internet connection are needed.
It works with a Windows/macOS/Linux laptop and a Raspberry Pi running Raspberry
Pi OS as long as Python 3 is installed.

The same folder can be copied to BOTH computers. Pick either computer as the
HTTP server and the other as the HTTP client.

FILES
-----
http_server.py     HTTP/1.1 server; serves the four assignment files
http_client.py     Benchmark client; performs/times transfers and writes CSVs
data/100B          Assignment data file (100 bytes)
data/10KB          Assignment data file (10,240 bytes)
data/1MB           Assignment data file (1,048,576 bytes)
data/10MB          Assignment data file (10,320,162 bytes)
results/           Client creates raw and summary CSV files here

ASSIGNMENT COUNTS
-----------------
100B  : 10,000 transfers
10KB  :  1,000 transfers
1MB   :    100 transfers
10MB  :     10 transfers
Total : 11,110 transfers

NETWORK SETUP
-------------
1. Put the laptop and Raspberry Pi on the same LAN/Wi-Fi network.
2. Copy this entire folder to both devices.
3. Make sure Python 3 is installed:
      Windows:       py -3 --version
      Raspberry Pi:  python3 --version

SERVER
------
On the computer chosen as the server, open a terminal/PowerShell in this folder.

Raspberry Pi / Linux / macOS:
    python3 http_server.py

Windows:
    py -3 http_server.py

The server listens on TCP port 8000 by default and prints its best detected LAN
IP address. Keep this terminal open during the experiment.

If the detected IP is not correct:
  Raspberry Pi/Linux: hostname -I
  Windows:            ipconfig

If Windows Firewall asks whether Python may communicate on private networks,
allow it on the private/local network used for the demo.

QUICK TEST / DEMO
-----------------
On the CLIENT computer, first run the short demo mode. Replace SERVER_IP with
the server's actual LAN address (example: 192.168.1.50).

Raspberry Pi / Linux / macOS:
    python3 http_client.py SERVER_IP --demo

Windows:
    py -3 http_client.py SERVER_IP --demo

Demo mode transfers each file 3 times. It verifies connectivity and shows the
same calculations as the full experiment, but DEMO RESULTS MUST NOT be used as
the final homework data.

FULL HOMEWORK RUN
-----------------
Raspberry Pi / Linux / macOS:
    python3 http_client.py SERVER_IP

Windows:
    py -3 http_client.py SERVER_IP

If no SERVER_IP is supplied, the client asks for it interactively.

The default methodology uses an HTTP/1.1 persistent TCP connection for each file
experiment. Each individual GET request is still timed separately. This avoids
making repeated TCP connection setup the dominant cost, especially for the
100-byte file, and is appropriate for comparing application protocols that
normally remain connected during repeated transfers.

If your instructor/team specifically wants a brand-new TCP connection for every
HTTP transfer, run instead:
    python3 http_client.py SERVER_IP --new-connection
or on Windows:
    py -3 http_client.py SERVER_IP --new-connection

Do NOT mix methodologies within one results table. Record which method the group
used so the experiment is reproducible.

WHAT THE CLIENT MEASURES
------------------------
For EACH transfer, timing starts immediately before the HTTP GET request is sent
and stops when the complete response body has been received.

Throughput (kilobits/second) =
    (file_size_bytes * 8) / elapsed_seconds / 1000

The client records every individual transfer in results/http_raw_*.csv.

HTTP OVERHEAD / APPLICATION-LAYER RATIO
---------------------------------------
The assignment asks for total application-layer data sent FROM SENDER TO RECEIVER
(including header content) divided by file size, while excluding receiver->sender
traffic such as ACKs.

This client counts the exact received HTTP response bytes:
    HTTP status line
  + HTTP response header lines
  + terminating blank line
  + file body

It deliberately does NOT count the client's HTTP GET request because that travels
receiver->sender rather than sender->receiver.

For all repetitions of a file:
    ratio = total_received_HTTP_response_bytes / total_file_payload_bytes

OUTPUT
------
The client creates two timestamped files in results/:

1. http_raw_YYYYMMDD_HHMMSS.csv
   One row for every transfer (11,110 rows in a full run), including time,
   throughput, exact response-header bytes, and application-layer ratio.

2. http_summary_YYYYMMDD_HHMMSS.csv
   One row per file containing averages, standard deviations, and the final
   application-layer ratio.

The client also prints the exact four-file summary needed for the HTTP row in
Results File.xlsx.

RESULTS FILE.xlsx MAPPING
-------------------------
The HTTP row requests, for each file:
  - Average throughput in kilobits per second
  - Standard deviation of throughput
and then one sender->receiver application-layer-data/file-size ratio per file.

This package reports both SAMPLE and POPULATION standard deviation in the summary
CSV because the assignment does not explicitly state which definition to use.
The console/table defaults to SAMPLE standard deviation (statistics.stdev), which
is the conventional estimate for repeated experimental measurements. The team
should use the same standard-deviation convention for all protocols.

IMPORTANT NOTES FOR THE DEMO / REPORT
-------------------------------------
- Both devices must be on the same local network, as required by the assignment.
- Use the supplied files exactly as provided. The 10MB file is actually
  10,320,162 bytes; the code measures the received payload rather than assuming
  that "10MB" has a particular byte count.
- Run the final protocol experiments under comparable network conditions.
- Do not run the HTTP server and client on the same machine for the final data if
  the group's other protocols use separate physical devices; keep the setup
  comparable.
- The server suppresses per-request console logging so 11,110 requests do not
  flood the terminal or interfere unnecessarily with timing.

TROUBLESHOOTING
---------------
"Connection refused":
  - Confirm http_server.py is still running.
  - Confirm the IP address and port 8000.
  - Check firewall settings.

"Timed out":
  - Verify both devices are on the same LAN and can ping each other.
  - Some guest Wi-Fi networks block device-to-device traffic (client isolation).

Test basic reachability from the client:
  ping SERVER_IP

Stop the server with Ctrl+C.
