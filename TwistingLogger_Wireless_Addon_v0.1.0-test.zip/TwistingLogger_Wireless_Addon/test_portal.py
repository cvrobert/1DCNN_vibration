import tempfile
import unittest
from pathlib import Path

from wireless_portal import parse_range, password_hash, safe_export_path, verify_password


class PortalTests(unittest.TestCase):
    def test_password(self):
        salt = bytes(range(16))
        digest = password_hash("correct horse battery", salt)
        self.assertTrue(verify_password("correct horse battery", salt.hex(), digest))
        self.assertFalse(verify_password("wrong", salt.hex(), digest))

    def test_safe_exports_only(self):
        with tempfile.TemporaryDirectory() as temp:
            directory = Path(temp)
            good = directory / "TwistingLogger-2026-11-03.zip"
            good.write_bytes(b"zip")
            self.assertEqual(safe_export_path(directory, good.name), good)
            self.assertIsNone(safe_export_path(directory, "../secret.zip"))
            self.assertIsNone(safe_export_path(directory, "data.sqlite3"))

    def test_ranges(self):
        self.assertIsNone(parse_range(None, 100))
        self.assertEqual(parse_range("bytes=10-19", 100), (10, 19))
        self.assertEqual(parse_range("bytes=90-", 100), (90, 99))
        self.assertEqual(parse_range("bytes=-10", 100), (90, 99))
        with self.assertRaises(ValueError):
            parse_range("bytes=100-110", 100)


if __name__ == "__main__":
    unittest.main()
