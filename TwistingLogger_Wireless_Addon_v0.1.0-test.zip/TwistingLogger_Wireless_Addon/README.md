# TwistingLogger Wireless Access Add-on — Test Build 0.1

This add-on leaves the existing TwistingLogger logger, tag configuration, database, export timer, and SMB share unchanged.

It adds:

- An isolated 2.4 GHz Wi-Fi hotspot.
- A read-only browser page for downloading daily ZIP exports.
- Password-protected, time-limited routing from one authenticated laptop to the machine network.
- A default-deny firewall between Wi-Fi and the machine Ethernet network.

## Before installation

The Pi must be connected to the machine network through `eth0`. Run:

```bash
command -v nft
ip -4 address show eth0
systemctl is-active twistinglogger.service
```

All three commands must succeed. If `nft` is missing, temporarily provide internet access and run:

```bash
sudo apt update
sudo apt install -y nftables
```

## Install

Copy and extract this ZIP on the Pi, enter its directory, and run:

```bash
sudo bash install.sh
```

The installer asks for:

- Hotspot name. Defaults to `TwistingLogger-TW1` or `TwistingLogger-TW2` based on Ethernet subnet.
- A hotspot password.
- A separate engineering administrator password.
- Engineering-access duration, defaulting to 60 minutes.

Do not reuse a PLC, Windows, domain, or company password.

## Historian download test

1. Disconnect the test laptop from other Wi-Fi networks.
2. Join the Pi hotspot.
3. Browse to `http://10.42.0.1`.
4. Download a daily ZIP.
5. Confirm the ZIP opens normally.

The download page requires the hotspot password but not the engineering administrator password.

## Studio 5000 test

1. On the download page, open **Engineering access**.
2. Sign in with the dedicated administrator password.
3. Select **Enable engineering access**.
4. In Windows PowerShell, test the PLC connection:

TW1:

```powershell
Test-NetConnection 192.168.10.10 -Port 44818
```

TW2:

```powershell
Test-NetConnection 192.168.20.10 -Port 44818
```

5. In FactoryTalk Linx or RSLinx, use an **Ethernet Devices** driver and enter the PLC IP explicitly. EtherNet/IP broadcast browsing is not expected to cross the routed hotspot.
6. Start with a read-only Studio 5000 test: browse, upload, go online, and monitor logic.
7. Select **End engineering access** when finished. Access also expires automatically.

Use a wired connection for controller firmware changes and major program downloads.

## Diagnostics

```bash
sudo bash diagnostics.sh
```

The expected output includes two active wireless services, active historian services, `10.42.0.1` on `wlan0`, and the isolation firewall rules.

## Change the administrator password

```bash
sudo bash set_admin_password.sh
```

## Remove the add-on

```bash
sudo bash uninstall.sh
```

Removal turns off Wi-Fi and removes only the wireless add-on. It does not remove historian data or change the logger.

## Test limitations

- The Pi 5's internal antenna may have limited range through a metal cabinet.
- This test build uses HTTP inside the WPA-protected hotspot. Use a unique administrator password that is not used anywhere else.
- The engineering gateway uses routed/NAT access. Explicit device addresses should work; broadcast discovery may not.
- Confirm the installation with company OT/cybersecurity policy before making it a permanent maintenance access method.
