#!/usr/bin/env bash
set -euo pipefail

config="/etc/twistinglogger-wireless/firewall.nft"
case "${1:-}" in
  apply)
    nft delete table inet twistinglogger_wireless >/dev/null 2>&1 || true
    nft -f "${config}"
    ;;
  clear)
    nft delete table inet twistinglogger_wireless >/dev/null 2>&1 || true
    ;;
  status)
    nft list table inet twistinglogger_wireless
    ;;
  *)
    echo "Usage: $0 {apply|clear|status}" >&2
    exit 2
    ;;
esac
