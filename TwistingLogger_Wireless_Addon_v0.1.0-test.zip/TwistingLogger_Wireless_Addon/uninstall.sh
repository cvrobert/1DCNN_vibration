#!/usr/bin/env bash
set -euo pipefail

if [[ "${EUID}" -ne 0 ]]; then
  echo "Run with: sudo bash uninstall.sh" >&2
  exit 1
fi

systemctl disable --now twistinglogger-wireless-portal.service >/dev/null 2>&1 || true
systemctl disable --now twistinglogger-wireless-firewall.service >/dev/null 2>&1 || true
if command -v nmcli >/dev/null 2>&1; then
  nmcli connection down twistinglogger-hotspot >/dev/null 2>&1 || true
  nmcli connection delete twistinglogger-hotspot >/dev/null 2>&1 || true
  nmcli radio wifi off >/dev/null 2>&1 || true
fi
if command -v nft >/dev/null 2>&1; then
  nft delete table inet twistinglogger_wireless >/dev/null 2>&1 || true
fi
rm -f /etc/systemd/system/twistinglogger-wireless-portal.service
rm -f /etc/systemd/system/twistinglogger-wireless-firewall.service
rm -f /usr/local/sbin/twistinglogger-wireless-firewall
rm -rf /opt/twistinglogger-wireless /etc/twistinglogger-wireless
systemctl daemon-reload

echo "Wireless add-on removed. TwistingLogger files and services were not changed."
