#!/usr/bin/env python3
"""Read-only TwistingLogger downloads and time-limited engineering access."""

from __future__ import annotations

import argparse
import hashlib
import hmac
import html
import ipaddress
import json
import mimetypes
import os
import secrets
import shutil
import subprocess
import threading
import time
from http import HTTPStatus
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, unquote, urlparse


SESSIONS: dict[str, dict[str, object]] = {}
FAILED_LOGINS: dict[str, list[float]] = {}
LOCK = threading.Lock()
SESSION_SECONDS = 30 * 60
MAX_LOGIN_FAILURES = 5
LOGIN_WINDOW_SECONDS = 5 * 60


def password_hash(password: str, salt: bytes) -> str:
    return hashlib.scrypt(
        password.encode("utf-8"), salt=salt, n=2**14, r=8, p=1, dklen=32
    ).hex()


def verify_password(password: str, salt_hex: str, expected_hex: str) -> bool:
    try:
        actual = password_hash(password, bytes.fromhex(salt_hex))
        return hmac.compare_digest(actual, expected_hex)
    except (ValueError, TypeError):
        return False


def safe_export_path(export_dir: Path, requested_name: str) -> Path | None:
    name = Path(unquote(requested_name)).name
    if name != unquote(requested_name) or not name.lower().endswith(".zip"):
        return None
    candidate = export_dir / name
    try:
        candidate.resolve().relative_to(export_dir.resolve())
    except (ValueError, OSError):
        return None
    return candidate if candidate.is_file() else None


def parse_range(header: str | None, size: int) -> tuple[int, int] | None:
    if not header:
        return None
    if not header.startswith("bytes=") or "," in header:
        raise ValueError("unsupported range")
    first, last = header[6:].split("-", 1)
    if not first:
        length = int(last)
        if length <= 0:
            raise ValueError("invalid suffix")
        return max(0, size - length), size - 1
    start = int(first)
    end = int(last) if last else size - 1
    if start < 0 or start >= size or end < start:
        raise ValueError("invalid range")
    return start, min(end, size - 1)


def nft_command(statement: str) -> None:
    nft = shutil.which("nft")
    if not nft:
        raise RuntimeError("nft command is unavailable")
    result = subprocess.run(
        [nft, "-f", "-"], input=statement + "\n", text=True,
        capture_output=True, timeout=10, check=False,
    )
    if result.returncode:
        raise RuntimeError(result.stderr.strip() or "nft command failed")


class PortalServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, address: tuple[str, int], config: dict[str, object]):
        super().__init__(address, PortalHandler)
        self.config = config
        self.export_dir = Path(str(config["export_dir"]))
        self.hotspot_network = ipaddress.ip_network(str(config["hotspot_subnet"]))
        self.line_network = ipaddress.ip_network(str(config["line_subnet"]))
        self.access_seconds = int(config.get("access_minutes", 60)) * 60


class PortalHandler(BaseHTTPRequestHandler):
    server: PortalServer
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt: str, *args: object) -> None:
        print(f"{self.client_address[0]} - {fmt % args}", flush=True)

    def security_headers(self) -> None:
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'self'; style-src 'unsafe-inline'; form-action 'self'; base-uri 'none'",
        )
        self.send_header("Cache-Control", "no-store")

    def send_html(self, body: str, status: int = 200, cookie: str | None = None) -> None:
        data = body.encode("utf-8")
        self.send_response(status)
        self.security_headers()
        if cookie:
            self.send_header("Set-Cookie", cookie)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def redirect(self, path: str, cookie: str | None = None) -> None:
        self.send_response(303)
        self.security_headers()
        if cookie:
            self.send_header("Set-Cookie", cookie)
        self.send_header("Location", path)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def page(self, title: str, content: str) -> str:
        ssid = html.escape(str(self.server.config.get("ssid", "TwistingLogger")))
        return f"""<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{html.escape(title)}</title><style>
body{{font-family:Arial,sans-serif;max-width:900px;margin:28px auto;padding:0 18px;background:#f5f7fa;color:#172033}}
.card{{background:white;border:1px solid #d7dde7;border-radius:10px;padding:20px;margin:14px 0}}
h1{{margin-bottom:4px}} table{{width:100%;border-collapse:collapse}}td,th{{padding:10px;border-bottom:1px solid #e4e8ef;text-align:left}}
button,.button{{background:#155eef;color:white;border:0;border-radius:6px;padding:10px 14px;text-decoration:none;cursor:pointer}}
.danger{{background:#b42318}}input{{padding:10px;width:min(360px,90%);margin:7px 0}}.muted{{color:#596579}}.good{{color:#067647;font-weight:bold}}
</style></head><body><h1>{ssid}</h1>{content}</body></html>"""

    def session(self) -> dict[str, object] | None:
        raw = self.headers.get("Cookie", "")
        cookie = SimpleCookie()
        try:
            cookie.load(raw)
        except Exception:
            return None
        morsel = cookie.get("tl_session")
        if not morsel:
            return None
        now = time.time()
        with LOCK:
            session = SESSIONS.get(morsel.value)
            if not session or float(session["expires"]) < now:
                SESSIONS.pop(morsel.value, None)
                return None
            if session["ip"] != self.client_address[0]:
                return None
            return session

    def form(self) -> dict[str, str]:
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            length = 0
        if length > 16_384:
            raise ValueError("form too large")
        values = parse_qs(self.rfile.read(length).decode("utf-8"), keep_blank_values=True)
        return {key: value[0] for key, value in values.items()}

    def require_csrf(self, form: dict[str, str], session: dict[str, object]) -> bool:
        return hmac.compare_digest(form.get("csrf", ""), str(session.get("csrf", "")))

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        if path == "/":
            self.show_index()
        elif path == "/admin":
            self.show_admin()
        elif path.startswith("/download/"):
            self.download(path[len("/download/"):])
        elif path == "/health":
            self.send_html("OK")
        else:
            self.send_error(404)

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        try:
            form = self.form()
        except (ValueError, UnicodeError):
            self.send_error(400)
            return
        if path == "/admin/login":
            self.login(form)
        elif path in {"/admin/enable", "/admin/disable", "/admin/logout"}:
            session = self.session()
            if not session:
                self.redirect("/admin")
                return
            if not self.require_csrf(form, session):
                self.send_error(403)
                return
            if path == "/admin/enable":
                self.enable_access()
            elif path == "/admin/disable":
                self.disable_access()
            else:
                self.logout()
        else:
            self.send_error(404)

    def show_index(self) -> None:
        rows = []
        try:
            files = sorted(
                (p for p in self.server.export_dir.iterdir() if p.is_file() and p.suffix.lower() == ".zip"),
                key=lambda p: p.stat().st_mtime, reverse=True,
            )
        except OSError as exc:
            self.send_html(self.page("Downloads", f"<div class=card>Unable to read exports: {html.escape(str(exc))}</div>"), 500)
            return
        for path in files:
            stat = path.stat()
            size = stat.st_size / (1024 * 1024)
            rows.append(
                f"<tr><td>{html.escape(path.name)}</td><td>{size:.1f} MB</td>"
                f"<td><a class=button href='/download/{quote(path.name)}'>Download</a></td></tr>"
            )
        table = "<p>No daily ZIP exports are available yet.</p>" if not rows else (
            "<table><tr><th>Historian export</th><th>Size</th><th></th></tr>" + "".join(rows) + "</table>"
        )
        content = (
            "<div class=card><h2>Historian files</h2><p class=muted>Read-only daily exports from this twisting line.</p>"
            + table + "</div><div class=card><h2>Engineering access</h2>"
            "<p>Administrators can temporarily enable access to the PLC network for this laptop.</p>"
            "<a class=button href='/admin'>Open engineering access</a></div>"
        )
        self.send_html(self.page("Historian Downloads", content))

    def show_admin(self, message: str = "") -> None:
        session = self.session()
        if not session:
            content = (
                "<div class=card><h2>Administrator login</h2>"
                "<p class=muted>Use the dedicated wireless-access administrator password.</p>"
                f"<p>{html.escape(message)}</p><form method=post action='/admin/login'>"
                "<label>Password</label><br><input type=password name=password autocomplete=current-password required><br>"
                "<button type=submit>Sign in</button></form></div><p><a href='/'>Back to downloads</a></p>"
            )
        else:
            csrf = html.escape(str(session["csrf"]), quote=True)
            client = html.escape(self.client_address[0])
            minutes = int(self.server.config.get("access_minutes", 60))
            line = html.escape(str(self.server.line_network))
            content = (
                "<div class=card><h2>Engineering access</h2>"
                f"<p>Laptop address: <strong>{client}</strong></p><p>Machine network: <strong>{line}</strong></p>"
                f"<p>Enable access for {minutes} minutes. Re-enabling restarts the timer.</p>"
                f"<form method=post action='/admin/enable'><input type=hidden name=csrf value='{csrf}'>"
                "<button type=submit>Enable engineering access</button></form><br>"
                f"<form method=post action='/admin/disable'><input type=hidden name=csrf value='{csrf}'>"
                "<button class=danger type=submit>End engineering access</button></form></div>"
                f"<form method=post action='/admin/logout'><input type=hidden name=csrf value='{csrf}'>"
                "<button type=submit>Sign out</button></form><p><a href='/'>Back to downloads</a></p>"
            )
        self.send_html(self.page("Engineering Access", content))

    def login(self, form: dict[str, str]) -> None:
        client = self.client_address[0]
        now = time.time()
        with LOCK:
            failures = [t for t in FAILED_LOGINS.get(client, []) if now - t < LOGIN_WINDOW_SECONDS]
            FAILED_LOGINS[client] = failures
        if len(failures) >= MAX_LOGIN_FAILURES:
            self.send_html(self.page("Login", "<div class=card>Too many attempts. Wait five minutes.</div>"), 429)
            return
        ok = verify_password(
            form.get("password", ""),
            str(self.server.config["admin_salt"]),
            str(self.server.config["admin_hash"]),
        )
        if not ok:
            with LOCK:
                FAILED_LOGINS.setdefault(client, []).append(now)
            self.show_admin("Incorrect administrator password.")
            return
        token = secrets.token_urlsafe(32)
        with LOCK:
            FAILED_LOGINS.pop(client, None)
            SESSIONS[token] = {
                "ip": client, "expires": now + SESSION_SECONDS, "csrf": secrets.token_urlsafe(24)
            }
        self.redirect(
            "/admin",
            f"tl_session={token}; Path=/; HttpOnly; SameSite=Strict; Max-Age={SESSION_SECONDS}",
        )

    def enable_access(self) -> None:
        client = ipaddress.ip_address(self.client_address[0])
        if client not in self.server.hotspot_network:
            self.send_html(self.page("Access denied", "<div class=card>Client is not on the logger hotspot.</div>"), 403)
            return
        try:
            # Re-enabling replaces any existing timed element so the timer restarts.
            try:
                nft_command(
                    "delete element inet twistinglogger_wireless engineering_clients "
                    f"{{ {client} }}"
                )
            except RuntimeError:
                pass
            nft_command(
                "add element inet twistinglogger_wireless engineering_clients "
                f"{{ {client} timeout {self.server.access_seconds}s }}"
            )
        except RuntimeError as exc:
            self.send_html(self.page("Access error", f"<div class=card>{html.escape(str(exc))}</div>"), 500)
            return
        content = (
            "<div class=card><h2 class=good>Engineering access enabled</h2>"
            f"<p>This laptop can reach {html.escape(str(self.server.line_network))} for "
            f"{self.server.access_seconds // 60} minutes.</p>"
            "<p>In FactoryTalk Linx or RSLinx, use an Ethernet Devices driver and enter the PLC IP explicitly.</p>"
            "<a class=button href='/admin'>Return</a></div>"
        )
        self.send_html(self.page("Access enabled", content))

    def disable_access(self) -> None:
        client = self.client_address[0]
        try:
            nft_command(
                "delete element inet twistinglogger_wireless engineering_clients " f"{{ {client} }}"
            )
        except RuntimeError:
            pass
        self.send_html(self.page("Access ended", "<div class=card><h2>Engineering access ended</h2><a class=button href='/admin'>Return</a></div>"))

    def logout(self) -> None:
        raw = self.headers.get("Cookie", "")
        cookie = SimpleCookie()
        cookie.load(raw)
        morsel = cookie.get("tl_session")
        if morsel:
            with LOCK:
                SESSIONS.pop(morsel.value, None)
        self.redirect("/", "tl_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0")

    def download(self, requested_name: str) -> None:
        path = safe_export_path(self.server.export_dir, requested_name)
        if path is None:
            self.send_error(404)
            return
        size = path.stat().st_size
        try:
            byte_range = parse_range(self.headers.get("Range"), size)
        except (ValueError, TypeError):
            self.send_response(416)
            self.security_headers()
            self.send_header("Content-Range", f"bytes */{size}")
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        start, end = byte_range if byte_range else (0, size - 1)
        length = end - start + 1
        self.send_response(206 if byte_range else 200)
        self.security_headers()
        self.send_header("Content-Type", mimetypes.guess_type(path.name)[0] or "application/zip")
        self.send_header("Content-Disposition", f"attachment; filename*=UTF-8''{quote(path.name)}")
        self.send_header("Accept-Ranges", "bytes")
        if byte_range:
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.send_header("Content-Length", str(length))
        self.end_headers()
        try:
            with path.open("rb") as source:
                source.seek(start)
                remaining = length
                while remaining:
                    chunk = source.read(min(1024 * 1024, remaining))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    remaining -= len(chunk)
        except (BrokenPipeError, ConnectionResetError):
            pass


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="/etc/twistinglogger-wireless/config.json")
    args = parser.parse_args()
    config = json.loads(Path(args.config).read_text(encoding="utf-8"))
    export_dir = Path(str(config["export_dir"]))
    if not export_dir.is_dir():
        raise SystemExit(f"Export directory does not exist: {export_dir}")
    # Fail closed whenever the portal restarts.
    nft_command("flush set inet twistinglogger_wireless engineering_clients")
    server = PortalServer((str(config.get("listen_address", "10.42.0.1")), int(config.get("port", 80))), config)
    print(f"TwistingLogger wireless portal listening on {server.server_address}", flush=True)
    server.serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
