#!/usr/bin/env bash
set -euo pipefail

if [[ "${EUID}" -ne 0 ]]; then
  echo "Run with: sudo bash set_admin_password.sh" >&2
  exit 1
fi

while true; do
  read -r -s -p "New engineering administrator password (minimum 12 characters): " password
  echo
  read -r -s -p "Confirm password: " confirmation
  echo
  if [[ "${password}" == "${confirmation}" && ${#password} -ge 12 ]]; then break; fi
  echo "Passwords did not match or were shorter than 12 characters."
done

ADMIN_PASSWORD="${password}" python3 - <<'PY'
import hashlib, json, os, secrets
path = "/etc/twistinglogger-wireless/config.json"
with open(path, encoding="utf-8") as handle:
    config = json.load(handle)
salt = secrets.token_bytes(16)
digest = hashlib.scrypt(os.environ.pop("ADMIN_PASSWORD").encode(), salt=salt, n=2**14, r=8, p=1, dklen=32)
config["admin_salt"] = salt.hex()
config["admin_hash"] = digest.hex()
with open(path, "w", encoding="utf-8") as handle:
    json.dump(config, handle, indent=2)
    handle.write("\n")
PY
chmod 0600 /etc/twistinglogger-wireless/config.json
unset password confirmation
systemctl restart twistinglogger-wireless-portal.service
echo "Administrator password updated. Existing sessions and engineering access were cleared."
