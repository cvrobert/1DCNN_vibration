#!/usr/bin/env bash
set -u

echo "Wireless services:"
systemctl is-active twistinglogger-wireless-firewall.service twistinglogger-wireless-portal.service 2>&1
echo
echo "Historian services:"
systemctl is-active twistinglogger.service twistinglogger-export.timer 2>&1
echo
echo "Hotspot connection:"
nmcli -f NAME,TYPE,DEVICE,STATE connection show --active 2>&1
echo
echo "Wireless address:"
ip -4 address show wlan0 2>&1
echo
echo "Firewall:"
/usr/local/sbin/twistinglogger-wireless-firewall status 2>&1
echo
echo "Portal health:"
python3 - <<'PY'
import urllib.request
try:
    with urllib.request.urlopen("http://10.42.0.1/health", timeout=5) as response:
        print(response.status, response.read().decode())
except Exception as exc:
    print("FAILED:", exc)
PY
