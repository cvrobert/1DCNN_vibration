#!/usr/bin/env bash
set -euo pipefail

if [[ "${EUID}" -ne 0 ]]; then
  echo "Run with: sudo bash install.sh" >&2
  exit 1
fi

for command in nmcli nft python3 systemctl ip; do
  if ! command -v "${command}" >/dev/null 2>&1; then
    echo "Missing required command: ${command}" >&2
    if [[ "${command}" == "nft" ]]; then
      echo "Install it while internet is available with: sudo apt install nftables" >&2
    fi
    exit 1
  fi
done

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export_dir="/opt/twistinglogger/exports"
eth_interface="eth0"
wifi_interface="wlan0"
hotspot_address="10.42.0.1/24"
hotspot_network="10.42.0.0/24"
connection_name="twistinglogger-hotspot"

cleanup_failed_install() {
  local exit_code=$?
  echo "Installation failed; removing the incomplete wireless add-on." >&2
  systemctl disable --now twistinglogger-wireless-portal.service >/dev/null 2>&1 || true
  systemctl disable --now twistinglogger-wireless-firewall.service >/dev/null 2>&1 || true
  nmcli connection down "${connection_name}" >/dev/null 2>&1 || true
  nmcli connection delete "${connection_name}" >/dev/null 2>&1 || true
  nft delete table inet twistinglogger_wireless >/dev/null 2>&1 || true
  rm -f /etc/systemd/system/twistinglogger-wireless-portal.service
  rm -f /etc/systemd/system/twistinglogger-wireless-firewall.service
  rm -f /usr/local/sbin/twistinglogger-wireless-firewall
  rm -rf /opt/twistinglogger-wireless /etc/twistinglogger-wireless
  systemctl daemon-reload >/dev/null 2>&1 || true
  exit "${exit_code}"
}
trap cleanup_failed_install ERR

if [[ ! -d "${export_dir}" ]]; then
  echo "Historian export folder was not found: ${export_dir}" >&2
  exit 1
fi
if ! systemctl is-active --quiet twistinglogger.service; then
  echo "TwistingLogger is not active. Resolve the logger service before adding wireless access." >&2
  exit 1
fi
if [[ ! -d "/sys/class/net/${eth_interface}" || ! -d "/sys/class/net/${wifi_interface}" ]]; then
  echo "Expected ${eth_interface} and ${wifi_interface} network interfaces were not found." >&2
  exit 1
fi

line_cidr="$(ip -4 route show dev "${eth_interface}" proto kernel scope link | awk 'NR==1 {print $1}')"
if [[ -z "${line_cidr}" ]]; then
  echo "No machine-network IPv4 route is active on ${eth_interface}. Connect Ethernet first." >&2
  exit 1
fi

line_network="$(python3 - "${line_cidr}" <<'PY'
import ipaddress, sys
print(ipaddress.ip_network(sys.argv[1], strict=False))
PY
)"

case "${line_network}" in
  192.168.10.0/24) default_ssid="TwistingLogger-TW1" ;;
  192.168.20.0/24) default_ssid="TwistingLogger-TW2" ;;
  *) default_ssid="TwistingLogger" ;;
esac

echo "Detected machine network: ${line_network}"
read -r -p "Hotspot name [${default_ssid}]: " ssid
ssid="${ssid:-${default_ssid}}"

while true; do
  read -r -s -p "Hotspot password (8-63 characters): " wifi_password
  echo
  if (( ${#wifi_password} >= 8 && ${#wifi_password} <= 63 )); then break; fi
  echo "Password must be 8-63 characters."
done

while true; do
  read -r -s -p "Engineering administrator password (minimum 12 characters): " admin_password
  echo
  read -r -s -p "Confirm administrator password: " admin_confirm
  echo
  if [[ "${admin_password}" == "${admin_confirm}" && ${#admin_password} -ge 12 ]]; then break; fi
  echo "Passwords did not match or were shorter than 12 characters."
done

read -r -p "Engineering-access duration in minutes [60]: " access_minutes
access_minutes="${access_minutes:-60}"
if ! [[ "${access_minutes}" =~ ^[0-9]+$ ]] || (( access_minutes < 5 || access_minutes > 480 )); then
  echo "Duration must be between 5 and 480 minutes." >&2
  exit 1
fi

install -d -m 0755 /opt/twistinglogger-wireless
install -d -m 0700 /etc/twistinglogger-wireless
install -m 0755 "${script_dir}/wireless_portal.py" /opt/twistinglogger-wireless/wireless_portal.py
install -m 0755 "${script_dir}/wireless_firewall.sh" /usr/local/sbin/twistinglogger-wireless-firewall

ADMIN_PASSWORD="${admin_password}" python3 - "${ssid}" "${line_network}" "${hotspot_network}" "${access_minutes}" <<'PY'
import hashlib, json, os, secrets, sys
password = os.environ.pop("ADMIN_PASSWORD")
salt = secrets.token_bytes(16)
digest = hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1, dklen=32)
config = {
    "ssid": sys.argv[1],
    "line_subnet": sys.argv[2],
    "hotspot_subnet": sys.argv[3],
    "access_minutes": int(sys.argv[4]),
    "listen_address": "10.42.0.1",
    "port": 80,
    "export_dir": "/opt/twistinglogger/exports",
    "admin_salt": salt.hex(),
    "admin_hash": digest.hex(),
}
with open("/etc/twistinglogger-wireless/config.json", "w", encoding="utf-8") as handle:
    json.dump(config, handle, indent=2)
    handle.write("\n")
PY
chmod 0600 /etc/twistinglogger-wireless/config.json

cat > /etc/twistinglogger-wireless/wireless.env <<EOF
ETH_INTERFACE=${eth_interface}
WIFI_INTERFACE=${wifi_interface}
LINE_SUBNET=${line_network}
HOTSPOT_SUBNET=${hotspot_network}
EOF
chmod 0644 /etc/twistinglogger-wireless/wireless.env

cat > /etc/twistinglogger-wireless/firewall.nft <<EOF
table inet twistinglogger_wireless {
    set engineering_clients {
        type ipv4_addr
        flags timeout
        timeout ${access_minutes}m
    }

    chain input_guard {
        type filter hook input priority -10; policy accept;
        iifname "${wifi_interface}" ct state established,related accept
        iifname "${wifi_interface}" udp dport { 53, 67 } accept
        iifname "${wifi_interface}" tcp dport { 53, 80 } accept
        iifname "${wifi_interface}" icmp type echo-request accept
        iifname "${wifi_interface}" drop
    }

    chain forward_guard {
        type filter hook forward priority -10; policy accept;
        iifname "${wifi_interface}" oifname "${eth_interface}" ip daddr ${line_network} ip saddr @engineering_clients accept
        iifname "${wifi_interface}" oifname "${eth_interface}" drop
        iifname "${eth_interface}" oifname "${wifi_interface}" ct state established,related accept
        iifname "${eth_interface}" oifname "${wifi_interface}" drop
    }
}
EOF
chmod 0600 /etc/twistinglogger-wireless/firewall.nft

install -m 0644 "${script_dir}/twistinglogger-wireless-firewall.service" /etc/systemd/system/
install -m 0644 "${script_dir}/twistinglogger-wireless-portal.service" /etc/systemd/system/

if nmcli -t -f NAME connection show | grep -Fxq "${connection_name}"; then
  nmcli connection down "${connection_name}" >/dev/null 2>&1 || true
  nmcli connection delete "${connection_name}" >/dev/null
fi
nmcli connection add type wifi ifname "${wifi_interface}" con-name "${connection_name}" ssid "${ssid}"
nmcli connection modify "${connection_name}" \
  802-11-wireless.mode ap \
  802-11-wireless.band bg \
  wifi-sec.key-mgmt wpa-psk \
  wifi-sec.psk "${wifi_password}" \
  ipv4.method shared \
  ipv4.addresses "${hotspot_address}" \
  ipv4.never-default yes \
  ipv6.method disabled \
  connection.autoconnect yes \
  connection.autoconnect-priority 100

unset wifi_password admin_password admin_confirm
systemctl daemon-reload
systemctl enable --now twistinglogger-wireless-firewall.service
systemctl enable --now twistinglogger-wireless-portal.service
nmcli radio wifi on
nmcli connection up "${connection_name}"

python3 - <<'PY'
import urllib.request
with urllib.request.urlopen("http://10.42.0.1/health", timeout=5) as response:
    if response.status != 200:
        raise SystemExit("Portal health check failed")
PY
systemctl is-active --quiet twistinglogger.service

trap - ERR

echo
echo "Wireless add-on installed."
echo "Hotspot: ${ssid}"
echo "Historian page: http://10.42.0.1"
echo "Machine network remains blocked until engineering access is enabled from the admin page."
echo "The TwistingLogger historian service and configuration were not modified."
