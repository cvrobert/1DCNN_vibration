# Migrating from the original project

1. Keep a backup of your existing project.
2. Copy your historical historian exports into `data/historical`.
3. Copy your newest export into `data/current`.
4. The supplied `data/failures.csv` already contains the failure records from the uploaded project.
5. Create a fresh virtual environment and install `requirements.txt`.
6. Run menu options **1, 2, 3, and 4** in order.

Do not copy the old `models/phase1_assets.joblib` into Version 2. Version 2 must retrain because its baseline exclusion, regime thresholds, and feature scales changed.

With a small dataset, Version 2 may report that it used an adaptive six-hour exclusion rather than the preferred 72-hour exclusion. Add the full month of verified healthy history and retrain to obtain the preferred baseline.
