from pathlib import Path
from src.dashboard import generate_dashboard

if __name__ == "__main__":
    generate_dashboard(Path(__file__).resolve().parent, open_browser=True)
