from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
DATA_DIR = PROJECT_ROOT / "data"
HISTORICAL_DATA_DIR = DATA_DIR / "historical"
CURRENT_DATA_DIR = DATA_DIR / "current"
FAILURE_FILE = DATA_DIR / "failures.csv"
PROCESSED_DIR = PROJECT_ROOT / "processed"
MODELS_DIR = PROJECT_ROOT / "models"
OUTPUTS_DIR = PROJECT_ROOT / "outputs"

TAG_MAP = {
    "A31A31DYNLeftCh0Overall": "LowerMotor",
    "A31A31DYNLeftCh1Overall": "UpperGearbox",
    "A31A31DYNLeftCh2Overall": "LowerGearbox",
    "A31A31DYNLeftCh3Overall": "MotorSideBearing",
    "A31A31DYNRightCh0Overall": "MotorSideBase",
    "A31A31DYNRightCh1Overall": "NonMotorBearing",
    "A31A31DYNRightCh2Overall": "NonMotorBase",
    "A31A31DYNRightCh3Overall": "UpperMotor",
    "A31Cps_ActSpd": "ActualSpeed",
}

VIBRATION_COLUMNS = [
    "LowerMotor", "UpperGearbox", "LowerGearbox", "MotorSideBearing",
    "MotorSideBase", "NonMotorBearing", "NonMotorBase", "UpperMotor",
]
SENSOR_DISPLAY_NAMES = {
    "LowerMotor": "Lower motor", "UpperGearbox": "Upper gearbox",
    "LowerGearbox": "Lower gearbox", "MotorSideBearing": "Motor-side bearing",
    "MotorSideBase": "Motor-side base", "NonMotorBearing": "Non-motor bearing",
    "NonMotorBase": "Non-motor base", "UpperMotor": "Upper motor",
}
SPEED_COLUMN = "ActualSpeed"

RUNNING_SPEED_THRESHOLD = 5.0
STARTUP_EXCLUSION_SECONDS = 120
SHUTDOWN_EXCLUSION_SECONDS = 120
WINDOW_SECONDS = 300
WINDOW_STEP_SECONDS = 60
MIN_WINDOW_COMPLETENESS = 0.90
MAX_INTERNAL_GAP_SECONDS = 5

N_OPERATING_REGIMES = 3
ISOLATION_CONTAMINATION = 0.005  # retained for compatibility; thresholds are calibrated from healthy data
ANOMALY_THRESHOLD_QUANTILE = 0.995
MIN_CONSECUTIVE_ANOMALOUS_WINDOWS = 3
RANDOM_SEED = 42

# Failure handling. Historical windows in this interval are never used to teach "healthy" behavior.
BASELINE_EXCLUSION_HOURS = 72
LOOKBACK_HOURS = 72
EARLY_PHASE_START_HOURS = 24
CRITICAL_PHASE_HOURS = 6
RECENT_FAILURE_HOURS = CRITICAL_PHASE_HOURS
MIN_FAILURE_WINDOWS = 3
MIN_PRECURSOR_ANOMALY_FRACTION = 0.05

# Decision logic. Failure resemblance can support a warning only after abnormality is established.
ACTIONABLE_RESEMBLANCE_THRESHOLD = 0.70
ELEVATED_HEALTH_THRESHOLD = 80
ANOMALOUS_HEALTH_THRESHOLD = 55

# Timestamp parsing. AVEVA exports encountered so far are US month/day order.
TIMESTAMP_DAYFIRST = False
