from pathlib import Path
import pandas as pd

from config import (
    HISTORICAL_DATA_DIR, CURRENT_DATA_DIR, PROCESSED_DIR, OUTPUTS_DIR,
    SPEED_COLUMN, VIBRATION_COLUMNS,
)
from src.utils import ensure_project_folders, print_banner
from src.import_data import import_folder, long_to_wide
from src.preprocess import clean_and_resample, identify_runs
from src.features import build_windows
from src.phase1 import train_phase1, score_phase1
from src.failure_library import (
    build_failure_fingerprints, load_failures, validate_failure_time_coverage,
)
from src.phase3 import compare_current_to_failures
from src.decision_engine import evaluate_machine
from src.visualize import save_anomaly_plot, create_sensor_status_table, create_text_report
from src.dashboard import generate_dashboard


def prepare_folder(folder: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    long_df = import_folder(folder)
    if long_df.empty:
        raise ValueError(f"No usable historian files were found in {folder.resolve()}")
    wide = long_to_wide(long_df, SPEED_COLUMN, VIBRATION_COLUMNS)
    clean = clean_and_resample(wide)
    runs = identify_runs(clean)
    windows = build_windows(runs)
    if windows.empty:
        raise ValueError("No valid steady-running windows were produced. Check speed threshold, data gaps, and run duration.")
    return windows, wide


def validate_import() -> None:
    print_banner("VALIDATE HISTORIAN IMPORT AND TIMESTAMPS")
    long_df = import_folder(HISTORICAL_DATA_DIR)
    if long_df.empty:
        print("No usable files found. Place AVEVA exports in data/historical.")
        return
    wide = long_to_wide(long_df, SPEED_COLUMN, VIBRATION_COLUMNS)
    start, end = wide["Timestamp"].min(), wide["Timestamp"].max()
    print(f"\nHistorian range: {start} to {end}")
    print("\nUsable rows by tag:")
    print(long_df["ModelColumn"].value_counts().to_string())
    print("\nMissing values after pivot:")
    print(wide.isna().sum().to_string())

    coverage = validate_failure_time_coverage(start, end)
    if not coverage.empty:
        print("\nFailure timestamp coverage:")
        print(coverage[["failure_id", "failure_time", "coverage_status"]].to_string(index=False))
        coverage.to_csv(PROCESSED_DIR / "failure_timestamp_validation.csv", index=False)
    sample = PROCESSED_DIR / "import_validation_sample.csv"
    wide.head(5000).to_csv(sample, index=False)
    print(f"\nSaved validation sample: {sample.resolve()}")


def train_normal_baseline() -> None:
    print_banner("PHASE 1 — TRAIN VERIFIED HEALTHY BASELINE")
    windows, wide = prepare_folder(HISTORICAL_DATA_DIR)
    scored = train_phase1(windows)
    scored.to_csv(PROCESSED_DIR / "historical_window_scores.csv", index=False)
    scored.sort_values("anomaly_percentile", ascending=False).head(500).to_csv(
        OUTPUTS_DIR / "phase1_top_500_anomaly_windows.csv", index=False
    )
    save_anomaly_plot(scored, "phase1_historical_anomaly_plot.png", "Historical deviation from healthy baseline")
    excluded = int(scored["baseline_excluded_pre_failure"].sum())
    healthy = len(scored) - excluded
    print(f"Total feature windows: {len(scored):,}")
    print(f"Pre-failure windows excluded from healthy training: {excluded:,}")
    print(f"Verified healthy training candidates: {healthy:,}")
    print(f"Persistent anomaly windows across complete history: {int(scored['persistent_anomaly'].sum()):,}")


def build_failure_patterns() -> None:
    print_banner("PHASE 2 — BUILD PHASE-AWARE FAILURE FINGERPRINTS")
    path = PROCESSED_DIR / "historical_window_scores.csv"
    if not path.exists():
        raise FileNotFoundError("Run Phase 1 first.")
    scored = pd.read_csv(path)
    for c in ("window_start", "window_end", "window_center"):
        scored[c] = pd.to_datetime(scored[c], errors="coerce")
    fingerprints = build_failure_fingerprints(scored)
    if fingerprints.empty:
        print("No usable failure fingerprints were produced.")
        return
    print(f"Built {len(fingerprints):,} phase fingerprints from {fingerprints['failure_id'].nunique():,} failures.")
    print(f"Fingerprints with actual predictive abnormality: {int(fingerprints['predictive_evidence'].sum()):,}")
    print("\nImportant: fingerprints without predictive evidence remain available for context, but cannot trigger warnings.")
    print(fingerprints[["failure_id", "phase", "window_count", "anomaly_fraction", "predictive_evidence"]].to_string(index=False))


def analyze_current_data(open_dashboard: bool = True) -> None:
    print_banner("PHASE 3 — HEALTH-FIRST CURRENT ANALYSIS")
    windows, _ = prepare_folder(CURRENT_DATA_DIR)
    scored = score_phase1(windows)
    scored.to_csv(OUTPUTS_DIR / "current_scored_windows.csv", index=False)
    save_anomaly_plot(scored, "current_anomaly_plot.png", "Current deviation from healthy baseline")
    sensor_table = create_sensor_status_table(scored)

    fp_path = PROCESSED_DIR / "failure_fingerprints.csv"
    comparison = pd.DataFrame()
    if fp_path.exists():
        fingerprints = pd.read_csv(fp_path)
        if "failure_time" in fingerprints:
            fingerprints["failure_time"] = pd.to_datetime(fingerprints["failure_time"], errors="coerce")
        comparison = compare_current_to_failures(scored, fingerprints)

    assessment = evaluate_machine(scored, comparison)
    pd.DataFrame([assessment]).to_csv(OUTPUTS_DIR / "current_assessment.csv", index=False)
    create_text_report(scored, comparison, assessment)

    print(f"\nCondition: {assessment['condition']}")
    print(f"Health score: {assessment['health_score']}/100")
    print(f"Trend: {assessment['trend']}")
    print(f"Persistent anomaly active: {assessment['active_persistent_anomaly']}")
    print(f"Failure warning: {assessment['failure_warning']}")
    print(f"Recommendation: {assessment['action']}")
    print("\nMost elevated sensors:")
    print(sensor_table.head(8).to_string(index=False))
    if not comparison.empty:
        cols = ["failure_id", "failure_type", "phase", "resemblance", "predictive_evidence", "top_matching_sensors"]
        print("\nClosest historical patterns (resemblance is not probability):")
        print(comparison[cols].head(5).to_string(index=False))
    if open_dashboard:
        generate_dashboard(Path(__file__).resolve().parent, open_browser=True)


def show_menu() -> None:
    ensure_project_folders()
    while True:
        print_banner("STRANDER PREDICTIVE MAINTENANCE V2")
        print("1) Validate historian import and failure timestamps")
        print("2) Train healthy baseline")
        print("3) Build phase-aware failure fingerprints")
        print("4) Analyze current data and open dashboard")
        print("5) Open existing dashboard")
        print("6) Show project folders")
        print("7) Exit")
        choice = input("\nSelection: ").strip()
        try:
            if choice == "1": validate_import()
            elif choice == "2": train_normal_baseline()
            elif choice == "3": build_failure_patterns()
            elif choice == "4": analyze_current_data(True)
            elif choice == "5": generate_dashboard(Path(__file__).resolve().parent, True)
            elif choice == "6":
                print(f"Historical: {HISTORICAL_DATA_DIR.resolve()}")
                print(f"Current: {CURRENT_DATA_DIR.resolve()}")
                print(f"Processed: {PROCESSED_DIR.resolve()}")
                print(f"Outputs: {OUTPUTS_DIR.resolve()}")
            elif choice == "7": break
            else: print("Enter a number from 1 through 7.")
        except Exception as exc:
            print(f"\nERROR: {type(exc).__name__}: {exc}")
        input("\nPress Enter to return to the menu...")


if __name__ == "__main__":
    show_menu()
