from __future__ import annotations

from pathlib import Path
import html
import webbrowser
import pandas as pd
import plotly.graph_objects as go
from plotly.offline import plot

from config import OUTPUTS_DIR, SENSOR_DISPLAY_NAMES


def _div(fig):
    return plot(fig, include_plotlyjs=False, output_type="div", config={"displaylogo": False, "responsive": True})


def _read_csv(path, dates=()):
    if not path.exists(): return pd.DataFrame()
    df = pd.read_csv(path)
    for c in dates:
        if c in df: df[c] = pd.to_datetime(df[c], errors="coerce")
    return df


def generate_dashboard(project_root: Path | str = ".", open_browser: bool = True) -> Path:
    root = Path(project_root).resolve(); outputs = root / "outputs"
    scores = _read_csv(outputs / "current_scored_windows.csv", ("window_center", "window_start", "window_end"))
    sensors = _read_csv(outputs / "current_sensor_status.csv")
    matches = _read_csv(outputs / "current_failure_resemblance.csv", ("failure_time",))
    summary_path = outputs / "current_assessment.csv"
    assessment = _read_csv(summary_path)
    if scores.empty: raise FileNotFoundError("Run current analysis before creating the dashboard.")
    a = assessment.iloc[0].to_dict() if not assessment.empty else {}

    anomaly = go.Figure()
    anomaly.add_trace(go.Scatter(x=scores["window_center"], y=scores["anomaly_percentile"]*100,
                                 mode="lines", name="Unusualness percentile"))
    anomaly.add_hline(y=99.5, line_dash="dash", annotation_text="Raw anomaly threshold")
    anomaly.update_layout(title="Current deviation from verified healthy operation", yaxis_title="Percentile", xaxis_title="Time")

    sensor_fig = go.Figure(go.Bar(x=[SENSOR_DISPLAY_NAMES.get(x,x) for x in sensors.get("sensor",[])],
                                  y=sensors.get("normalized_deviation",[])))
    sensor_fig.update_layout(title="Recent speed-adjusted sensor deviation", yaxis_title="Robust standard deviations", xaxis_title="Sensor")

    match_fig = go.Figure()
    if not matches.empty:
        labels = matches.head(10).apply(lambda r: f"{r['failure_id']} · {r['phase']}", axis=1)
        match_fig.add_trace(go.Bar(x=labels, y=matches.head(10)["resemblance"]*100,
                                   text=matches.head(10)["predictive_evidence"].map({True:"Predictive evidence", False:"Normal-looking precursor"})))
    match_fig.update_layout(title="Historical pattern resemblance (not probability)", yaxis_title="Pattern resemblance %", xaxis_title="Historical case and phase")

    condition = html.escape(str(a.get("condition", "Unknown")))
    action = html.escape(str(a.get("action", "")))
    health = int(float(a.get("health_score", 0)))
    warning = str(a.get("failure_warning", False)).lower() == "true"
    top_match = "No historical comparison"
    if not matches.empty:
        r = matches.iloc[0]
        top_match = f"{html.escape(str(r['failure_type']))} {html.escape(str(r['failure_id']))}, {html.escape(str(r['phase']))}: {float(r['resemblance']):.1%} resemblance"
        if not bool(r.get("predictive_evidence", False)):
            top_match += " — historical phase did not contain reliable abnormal evidence"

    sensor_rows = "".join(
        f"<tr><td>{html.escape(SENSOR_DISPLAY_NAMES.get(str(r.sensor),str(r.sensor)))}</td><td>{r.actual_rms:.4f}</td><td>{r.expected_rms:.4f}</td><td>{r.normalized_deviation:+.2f}</td><td>{r.deviation_percent:+.1f}%</td></tr>"
        for r in sensors.itertuples()
    )
    match_rows = "".join(
        f"<tr><td>{html.escape(str(r.failure_id))}</td><td>{html.escape(str(r.failure_type))}</td><td>{html.escape(str(r.phase))}</td><td>{r.resemblance:.1%}</td><td>{'Yes' if bool(r.predictive_evidence) else 'No'}</td><td>{html.escape(str(r.top_matching_sensors))}</td></tr>"
        for r in matches.head(12).itertuples()
    ) or "<tr><td colspan='6'>No failure fingerprints available.</td></tr>"

    css = """body{font-family:Segoe UI,Arial;background:#f4f7fb;color:#172033;margin:0}.page{max-width:1500px;margin:auto;padding:24px}.grid{display:grid;grid-template-columns:repeat(12,1fr);gap:16px}.card{background:white;border:1px solid #dbe3ef;border-radius:14px;padding:18px}.metric{grid-column:span 3}.half{grid-column:span 6}.full{grid-column:span 12}.value{font-size:28px;font-weight:750}.muted{color:#64748b}.warning{background:#fff1f2;border-color:#fecdd3}.normal{background:#f0fdf4;border-color:#bbf7d0}table{width:100%;border-collapse:collapse}th,td{padding:9px;border-bottom:1px solid #e5e7eb;text-align:left}th{font-size:12px;color:#64748b}.bar{height:12px;background:#e2e8f0;border-radius:99px;overflow:hidden}.fill{height:100%;background:#334155}@media(max-width:900px){.metric,.half{grid-column:span 12}}"""
    doc = f"""<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width'><script src='https://cdn.plot.ly/plotly-2.35.2.min.js'></script><style>{css}</style><title>Strander PM V2</title></head><body><div class='page'><h1>TDC Strander Predictive Maintenance V2</h1><p class='muted'>Healthy-baseline-first engineering decision support</p><div class='grid'>
    <section class='card metric {'warning' if warning else 'normal'}'><div class='muted'>Current condition</div><div class='value'>{condition}</div></section>
    <section class='card metric'><div class='muted'>Machine health</div><div class='value'>{health}/100</div><div class='bar'><div class='fill' style='width:{health}%'></div></div></section>
    <section class='card metric'><div class='muted'>Persistent anomaly active</div><div class='value'>{'YES' if bool(a.get('active_persistent_anomaly',False)) else 'No'}</div></section>
    <section class='card metric'><div class='muted'>Trend</div><div class='value'>{html.escape(str(a.get('trend','unknown')).title())}</div></section>
    <section class='card full'><h2>Engineering recommendation</h2><p>{action}</p><p><strong>Closest historical pattern:</strong> {top_match}</p><p class='muted'><strong>Guardrail:</strong> resemblance is not probability and cannot create a warning unless the current signal is independently persistent and abnormal.</p></section>
    <section class='card full'>{_div(anomaly)}</section><section class='card half'>{_div(sensor_fig)}</section><section class='card half'>{_div(match_fig)}</section>
    <section class='card full'><h2>Sensor explanation</h2><table><thead><tr><th>Sensor</th><th>Actual RMS</th><th>Expected RMS</th><th>Normalized deviation</th><th>Deviation</th></tr></thead><tbody>{sensor_rows}</tbody></table></section>
    <section class='card full'><h2>Failure fingerprint library comparison</h2><table><thead><tr><th>ID</th><th>Type</th><th>Phase</th><th>Resemblance</th><th>Predictive evidence</th><th>Top matching sensors</th></tr></thead><tbody>{match_rows}</tbody></table></section>
    </div></div></body></html>"""
    path = outputs / "strander_dashboard_v2.html"; path.write_text(doc, encoding="utf-8")
    # Compatibility filename.
    (outputs / "strander_dashboard.html").write_text(doc, encoding="utf-8")
    if open_browser: webbrowser.open(path.as_uri())
    print(f"Dashboard created: {path}")
    return path
