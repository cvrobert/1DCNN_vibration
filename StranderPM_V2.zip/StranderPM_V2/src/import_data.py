from pathlib import Path
import pandas as pd

from config import TAG_MAP
from src.time_utils import parse_timestamps, timestamp_diagnostics

TIMESTAMP_CANDIDATES = ["DateTime", "Datetime", "Timestamp", "TimeStamp", "Time", "Date"]
TAG_CANDIDATES = ["TagName", "Tag Name", "Tag", "Name"]
VALUE_CANDIDATES = ["Value", "AnalogValue", "ProcessValue", "Val"]


def _find_column(columns, candidates):
    normalized = {str(c).strip().lower(): c for c in columns}
    return next((normalized[c.lower()] for c in candidates if c.lower() in normalized), None)


def list_data_files(folder: Path):
    folder = Path(folder)
    files = []
    for pattern in ("*.xlsx", "*.xls", "*.csv"):
        files.extend(folder.glob(pattern))
    return sorted(set(files))


def read_export_file(file_path: Path) -> pd.DataFrame:
    file_path = Path(file_path)
    if file_path.suffix.lower() in (".xlsx", ".xls"):
        raw = pd.read_excel(file_path)
    elif file_path.suffix.lower() == ".csv":
        raw = pd.read_csv(file_path, low_memory=False)
    else:
        raise ValueError(f"Unsupported file type: {file_path.suffix}")
    if raw.empty:
        raise ValueError("File is empty.")

    timestamp_col = _find_column(raw.columns, TIMESTAMP_CANDIDATES)
    tag_col = _find_column(raw.columns, TAG_CANDIDATES)
    value_col = _find_column(raw.columns, VALUE_CANDIDATES)
    if timestamp_col is None and len(raw.columns) >= 1: timestamp_col = raw.columns[0]
    if tag_col is None and len(raw.columns) >= 2: tag_col = raw.columns[1]
    if value_col is None and len(raw.columns) >= 3: value_col = raw.columns[2]
    if None in (timestamp_col, tag_col, value_col):
        raise ValueError("Could not identify timestamp, tag, and value columns.")

    subset = raw[[timestamp_col, tag_col, value_col]].copy()
    subset.columns = ["Timestamp", "TagName", "Value"]
    original_timestamps = subset["Timestamp"].copy()
    subset["Timestamp"] = parse_timestamps(subset["Timestamp"], source=file_path.name)
    diag = timestamp_diagnostics(original_timestamps, subset["Timestamp"])
    if diag["success_rate"] < 0.95:
        print(f"WARNING {file_path.name}: parsed {diag['valid']:,}/{diag['total']:,} timestamps "
              f"({diag['success_rate']:.1%}).")

    subset["TagName"] = subset["TagName"].astype(str).str.strip()
    subset["Value"] = pd.to_numeric(subset["Value"], errors="coerce")
    subset = subset.dropna(subset=["Timestamp", "TagName", "Value"])
    subset = subset[subset["TagName"].isin(TAG_MAP)].copy()
    if subset.empty:
        raise ValueError("No configured strander tags were found. Check config.py and export columns.")
    subset["ModelColumn"] = subset["TagName"].map(TAG_MAP)
    subset["SourceFile"] = file_path.name
    return subset


def import_folder(folder: Path) -> pd.DataFrame:
    files = list_data_files(folder)
    if not files: return pd.DataFrame()
    pieces = []
    for file_path in files:
        try:
            part = read_export_file(file_path)
            pieces.append(part)
            print(f"Imported {file_path.name}: {len(part):,} usable rows")
        except Exception as exc:
            print(f"FAILED {file_path.name}: {exc}")
    if not pieces: return pd.DataFrame()
    return pd.concat(pieces, ignore_index=True).sort_values(["Timestamp", "ModelColumn"])


def long_to_wide(long_df: pd.DataFrame, speed_column: str, vibration_columns: list[str]) -> pd.DataFrame:
    if long_df.empty: return pd.DataFrame()
    clean = (long_df.sort_values(["Timestamp", "ModelColumn", "SourceFile"])
             .drop_duplicates(["Timestamp", "ModelColumn"], keep="last"))
    wide = clean.pivot(index="Timestamp", columns="ModelColumn", values="Value").sort_index()
    wide.columns.name = None
    wide = wide.reset_index()
    for column in [speed_column, *vibration_columns]:
        if column not in wide.columns: wide[column] = pd.NA
    return wide[["Timestamp", speed_column, *vibration_columns]]
