from __future__ import annotations

import numpy as np
import pandas as pd

from config import (
    FAILURE_FILE, LOOKBACK_HOURS, EARLY_PHASE_START_HOURS, CRITICAL_PHASE_HOURS,
    BASELINE_EXCLUSION_HOURS, MIN_FAILURE_WINDOWS, MIN_PRECURSOR_ANOMALY_FRACTION,
    PROCESSED_DIR, VIBRATION_COLUMNS,
)
from src.time_utils import parse_timestamps

REQUIRED_FAILURE_COLUMNS = [
    "failure_id", "failure_time", "failure_type", "affected_area",
    "description", "time_accuracy",
]
OPTIONAL_FAILURE_COLUMNS = [
    "root_cause", "maintenance_action", "product", "operator_notes",
    "vibration_relevant", "confidence",
]


def load_failures() -> pd.DataFrame:
    if not FAILURE_FILE.exists():
        return pd.DataFrame(columns=REQUIRED_FAILURE_COLUMNS + OPTIONAL_FAILURE_COLUMNS)
    df = pd.read_csv(FAILURE_FILE, low_memory=False)
    for col in REQUIRED_FAILURE_COLUMNS + OPTIONAL_FAILURE_COLUMNS:
        if col not in df.columns:
            df[col] = ""
    df["failure_time"] = parse_timestamps(df["failure_time"], source="failures.csv")
    df = df.dropna(subset=["failure_time", "failure_id"]).copy()
    df["failure_id"] = df["failure_id"].astype(str).str.strip()
    return df.sort_values("failure_time").reset_index(drop=True)


def failure_overlap_mask(windows: pd.DataFrame, hours: float = BASELINE_EXCLUSION_HOURS) -> pd.Series:
    mask = pd.Series(False, index=windows.index)
    if windows.empty or "window_center" not in windows:
        return mask
    for t in load_failures()["failure_time"]:
        mask |= windows["window_center"].between(t - pd.Timedelta(hours=hours), t, inclusive="left")
    return mask


def validate_failure_time_coverage(data_start, data_end) -> pd.DataFrame:
    failures = load_failures()
    if failures.empty:
        return failures.assign(coverage_status=pd.Series(dtype=str))
    result = failures.copy()
    result["coverage_status"] = np.select(
        [result["failure_time"] < data_start, result["failure_time"] > data_end],
        ["before historian range", "after historian range"], default="inside historian range"
    )
    return result


def label_failure_phases(scored_windows: pd.DataFrame) -> pd.DataFrame:
    labeled = scored_windows.copy()
    labeled["failure_id"] = pd.NA
    labeled["failure_type"] = pd.NA
    labeled["failure_phase"] = "healthy_candidate"
    labeled["hours_to_failure"] = np.nan

    # Process chronologically. When failure lookbacks overlap, assign each window to
    # the nearest upcoming failure, which prevents duplicate training examples.
    assignments = []
    for _, failure in load_failures().iterrows():
        delta_h = (failure["failure_time"] - labeled["window_center"]).dt.total_seconds() / 3600
        valid = (delta_h > 0) & (delta_h <= LOOKBACK_HOURS)
        for idx in labeled.index[valid]:
            assignments.append((idx, float(delta_h.loc[idx]), failure))
    assignments.sort(key=lambda x: x[1], reverse=True)
    for idx, hours, failure in assignments:
        current = labeled.at[idx, "hours_to_failure"]
        if pd.isna(current) or hours < current:
            labeled.at[idx, "failure_id"] = failure["failure_id"]
            labeled.at[idx, "failure_type"] = failure["failure_type"]
            labeled.at[idx, "hours_to_failure"] = hours
            if hours <= CRITICAL_PHASE_HOURS:
                phase = "critical_0_6h"
            elif hours <= EARLY_PHASE_START_HOURS:
                phase = "early_6_24h"
            else:
                phase = "context_24_72h"
            labeled.at[idx, "failure_phase"] = phase
    return labeled


def _pattern_columns(scored: pd.DataFrame) -> list[str]:
    cols = ["anomaly_percentile", "health_deviation", "speed_mean", "speed_std"]
    for sensor in VIBRATION_COLUMNS:
        cols += [
            f"{sensor}_normalized_residual", f"{sensor}_speed_residual",
            f"{sensor}_slope", f"{sensor}_std", f"{sensor}_range",
        ]
    return [c for c in cols if c in scored.columns]


def build_failure_fingerprints(scored_windows: pd.DataFrame) -> pd.DataFrame:
    failures = load_failures()
    labeled = label_failure_phases(scored_windows)
    labeled.to_csv(PROCESSED_DIR / "historical_labeled_windows.csv", index=False)
    pattern_cols = _pattern_columns(labeled)
    rows = []

    for _, failure in failures.iterrows():
        fg = labeled[labeled["failure_id"] == failure["failure_id"]]
        for phase in ("context_24_72h", "early_6_24h", "critical_0_6h"):
            group = fg[fg["failure_phase"] == phase]
            if group.empty:
                continue
            anomaly_fraction = float(group.get("is_anomaly_raw", False).mean())
            persistent_fraction = float(group.get("persistent_anomaly", False).mean())
            predictive = (
                len(group) >= MIN_FAILURE_WINDOWS and
                (anomaly_fraction >= MIN_PRECURSOR_ANOMALY_FRACTION or persistent_fraction > 0)
            )
            row = {
                "failure_id": failure["failure_id"],
                "failure_type": failure["failure_type"],
                "affected_area": failure.get("affected_area", ""),
                "failure_time": failure["failure_time"],
                "phase": phase,
                "window_count": len(group),
                "anomaly_fraction": anomaly_fraction,
                "persistent_fraction": persistent_fraction,
                "predictive_evidence": bool(predictive),
                "root_cause": failure.get("root_cause", ""),
                "description": failure.get("description", ""),
            }
            for col in pattern_cols:
                row[f"{col}__median"] = group[col].median()
                row[f"{col}__p90"] = group[col].quantile(0.90)
                row[f"{col}__trend"] = group[col].tail(max(3, len(group)//3)).mean() - group[col].head(max(3, len(group)//3)).mean()
            rows.append(row)

    result = pd.DataFrame(rows)
    result.to_csv(PROCESSED_DIR / "failure_fingerprints.csv", index=False)
    return result
