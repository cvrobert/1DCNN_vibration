from pathlib import Path
import json
import pandas as pd

from config import (
    HISTORICAL_DATA_DIR,
    CURRENT_DATA_DIR,
    MODELS_DIR,
    OUTPUTS_DIR,
    PROCESSED_DIR,
    FAILURE_FILE,
)

def ensure_project_folders() -> None:
    for folder in [
        HISTORICAL_DATA_DIR,
        CURRENT_DATA_DIR,
        MODELS_DIR,
        OUTPUTS_DIR,
        PROCESSED_DIR,
    ]:
        folder.mkdir(parents=True, exist_ok=True)

    if not FAILURE_FILE.exists():
        pd.DataFrame(
            columns=[
                "failure_id",
                "failure_time",
                "failure_type",
                "affected_area",
                "description",
                "time_accuracy",
            ]
        ).to_csv(FAILURE_FILE, index=False)

def save_json(data: dict, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, default=str)

def print_banner(title: str) -> None:
    line = "=" * max(50, len(title) + 8)
    print(f"\n{line}\n   {title}\n{line}")
