import numpy as np
import pandas as pd

from config import (
    SPEED_COLUMN,
    VIBRATION_COLUMNS,
    WINDOW_SECONDS,
    WINDOW_STEP_SECONDS,
    MIN_WINDOW_COMPLETENESS,
    MAX_INTERNAL_GAP_SECONDS,
)

def linear_slope(values) -> float:
    values = np.asarray(values, dtype=float)
    valid = np.isfinite(values)

    if valid.sum() < 3:
        return np.nan

    x = np.arange(len(values), dtype=float)
    return np.polyfit(x[valid], values[valid], 1)[0]

def build_windows(data: pd.DataFrame) -> pd.DataFrame:
    rows = []
    steady = data[data["steady_running"]].copy()

    for run_id, run in steady.groupby("run_id"):
        run = run.sort_values("Timestamp").reset_index(drop=True)

        if len(run) < WINDOW_SECONDS:
            continue

        current = run["Timestamp"].iloc[0]
        last_time = run["Timestamp"].iloc[-1]

        while current + pd.Timedelta(seconds=WINDOW_SECONDS - 1) <= last_time:
            end = current + pd.Timedelta(seconds=WINDOW_SECONDS - 1)

            block = run[
                (run["Timestamp"] >= current)
                & (run["Timestamp"] <= end)
            ].copy()

            completeness = len(block) / WINDOW_SECONDS

            if completeness < MIN_WINDOW_COMPLETENESS:
                current += pd.Timedelta(seconds=WINDOW_STEP_SECONDS)
                continue

            gaps = block["Timestamp"].diff().dt.total_seconds()
            if gaps.max() > MAX_INTERNAL_GAP_SECONDS:
                current += pd.Timedelta(seconds=WINDOW_STEP_SECONDS)
                continue

            if block[[SPEED_COLUMN, *VIBRATION_COLUMNS]].isna().any().any():
                current += pd.Timedelta(seconds=WINDOW_STEP_SECONDS)
                continue

            row = {
                "run_id": int(run_id),
                "window_start": current,
                "window_end": end,
                "window_center": current + pd.Timedelta(seconds=WINDOW_SECONDS / 2),
                "speed_mean": block[SPEED_COLUMN].mean(),
                "speed_std": block[SPEED_COLUMN].std(),
                "speed_min": block[SPEED_COLUMN].min(),
                "speed_max": block[SPEED_COLUMN].max(),
                "speed_slope": linear_slope(block[SPEED_COLUMN]),
                "seconds_from_run_start": block["seconds_from_run_start"].median(),
            }

            means = {}

            for sensor in VIBRATION_COLUMNS:
                values = block[sensor].to_numpy(dtype=float)
                means[sensor] = values.mean()

                row[f"{sensor}_mean"] = values.mean()
                row[f"{sensor}_median"] = np.median(values)
                row[f"{sensor}_std"] = values.std()
                row[f"{sensor}_min"] = values.min()
                row[f"{sensor}_max"] = values.max()
                row[f"{sensor}_range"] = np.ptp(values)
                row[f"{sensor}_slope"] = linear_slope(values)
                row[f"{sensor}_delta"] = values[-30:].mean() - values[:30].mean()
                row[f"{sensor}_p90"] = np.percentile(values, 90)
                row[f"{sensor}_diff_std"] = np.diff(values).std()

            eps = 1e-9
            total = sum(means.values()) + eps

            for sensor, value in means.items():
                row[f"{sensor}_share"] = value / total

            row["ratio_motor_top_bottom"] = (
                means["UpperMotor"] / (means["LowerMotor"] + eps)
            )
            row["ratio_gearbox_top_bottom"] = (
                means["UpperGearbox"] / (means["LowerGearbox"] + eps)
            )
            row["ratio_motor_bearing_to_base"] = (
                means["MotorSideBearing"] / (means["MotorSideBase"] + eps)
            )
            row["ratio_nonmotor_bearing_to_base"] = (
                means["NonMotorBearing"] / (means["NonMotorBase"] + eps)
            )
            row["ratio_motor_to_nonmotor_bearing"] = (
                means["MotorSideBearing"] / (means["NonMotorBearing"] + eps)
            )

            row["motor_average"] = np.mean([
                means["UpperMotor"],
                means["LowerMotor"],
            ])
            row["gearbox_average"] = np.mean([
                means["UpperGearbox"],
                means["LowerGearbox"],
            ])
            row["bearing_average"] = np.mean([
                means["MotorSideBearing"],
                means["NonMotorBearing"],
            ])
            row["base_average"] = np.mean([
                means["MotorSideBase"],
                means["NonMotorBase"],
            ])
            row["bearing_minus_base"] = row["bearing_average"] - row["base_average"]
            row["gearbox_minus_motor"] = row["gearbox_average"] - row["motor_average"]

            rows.append(row)
            current += pd.Timedelta(seconds=WINDOW_STEP_SECONDS)

    return pd.DataFrame(rows)
