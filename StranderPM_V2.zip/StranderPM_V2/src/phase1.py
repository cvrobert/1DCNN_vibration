from __future__ import annotations

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor, IsolationForest
from sklearn.mixture import GaussianMixture
from sklearn.preprocessing import RobustScaler

from config import (
    MODELS_DIR, VIBRATION_COLUMNS, N_OPERATING_REGIMES,
    ANOMALY_THRESHOLD_QUANTILE, MIN_CONSECUTIVE_ANOMALOUS_WINDOWS, RANDOM_SEED,
)
from src.failure_library import failure_overlap_mask

SPEED_CONTEXT_COLUMNS = [
    "speed_mean", "speed_std", "speed_min", "speed_max", "speed_slope", "seconds_from_run_start",
]


def _regime_features(residuals):
    return ["speed_mean", "speed_std", *residuals, *[f"{s}_share" for s in VIBRATION_COLUMNS]]


def _anomaly_features(residuals):
    cols = SPEED_CONTEXT_COLUMNS.copy()
    for sensor in VIBRATION_COLUMNS:
        cols += [f"{sensor}_{x}" for x in ("mean", "std", "max", "range", "slope", "delta", "p90", "diff_std")]
    cols += residuals + [f"{s}_share" for s in VIBRATION_COLUMNS]
    cols += [
        "ratio_motor_top_bottom", "ratio_gearbox_top_bottom", "ratio_motor_bearing_to_base",
        "ratio_nonmotor_bearing_to_base", "ratio_motor_to_nonmotor_bearing",
        "motor_average", "gearbox_average", "bearing_average", "base_average",
        "bearing_minus_base", "gearbox_minus_motor",
    ]
    return cols


def _add_sensor_expectations(windows, models, residual_scales=None):
    out = windows.copy()
    scales = {} if residual_scales is None else residual_scales
    for sensor in VIBRATION_COLUMNS:
        target = f"{sensor}_mean"
        expected = models[sensor].predict(out[SPEED_CONTEXT_COLUMNS])
        residual = out[target] - expected
        out[f"{sensor}_expected"] = expected
        out[f"{sensor}_speed_residual"] = residual
        scale = scales.get(sensor)
        if scale is None:
            mad_scale = float(np.nanmedian(np.abs(residual - np.nanmedian(residual))) * 1.4826)
            engineering_floor = float(max(np.nanmedian(np.abs(out[target])) * 0.05, 1e-6))
            scale = max(mad_scale, engineering_floor)
            scales[sensor] = scale
        out[f"{sensor}_normalized_residual"] = residual / scale
    return out, scales


def train_phase1(windows: pd.DataFrame) -> pd.DataFrame:
    if windows.empty: raise ValueError("No feature windows available for training.")
    all_windows = windows.copy().sort_values("window_center").reset_index(drop=True)
    minimum_healthy = max(100, int(len(all_windows) * 0.10))
    effective_exclusion_hours = None
    excluded = None
    healthy = None
    # Prefer the full conservative exclusion. For small demonstration datasets,
    # step down only as far as the critical six-hour interval so the program can
    # run without quietly treating the final pre-trip period as healthy.
    for candidate_hours in (72, 24, 6):
        candidate_mask = failure_overlap_mask(all_windows, hours=candidate_hours)
        candidate_healthy = all_windows.loc[~candidate_mask].copy()
        if len(candidate_healthy) >= minimum_healthy:
            effective_exclusion_hours = candidate_hours
            excluded = candidate_mask
            healthy = candidate_healthy
            break
    if healthy is None:
        raise ValueError(
            "The available history is almost entirely inside known pre-failure periods. "
            "Add verified healthy historian exports; at least 100 usable windows outside the final six hours "
            "before failures are required."
        )
    if effective_exclusion_hours < 72:
        print(
            f"WARNING: limited history required an adaptive baseline exclusion of "
            f"{effective_exclusion_hours} hours instead of 72. Add more verified healthy data and retrain."
        )

    speed_models = {}
    for sensor in VIBRATION_COLUMNS:
        model = HistGradientBoostingRegressor(max_iter=250, learning_rate=0.05, max_leaf_nodes=20,
                                              l2_regularization=1.0, random_state=RANDOM_SEED)
        model.fit(healthy[SPEED_CONTEXT_COLUMNS], healthy[f"{sensor}_mean"])
        speed_models[sensor] = model

    healthy, residual_scales = _add_sensor_expectations(healthy, speed_models)
    all_windows, _ = _add_sensor_expectations(all_windows, speed_models, residual_scales)
    residuals = [f"{s}_speed_residual" for s in VIBRATION_COLUMNS]
    regime_features = _regime_features(residuals)
    regime_scaler = RobustScaler().fit(healthy[regime_features])
    xh = regime_scaler.transform(healthy[regime_features])
    n_regimes = min(N_OPERATING_REGIMES, max(1, len(healthy)//100))
    regime_model = GaussianMixture(n_components=n_regimes, covariance_type="diag", n_init=10,
                                   random_state=RANDOM_SEED).fit(xh)

    for df in (healthy, all_windows):
        x = regime_scaler.transform(df[regime_features])
        labels = regime_model.predict(x)
        df["detected_regime"] = [f"regime_{i}" for i in labels]
        df["regime_confidence"] = regime_model.predict_proba(x).max(axis=1)

    anomaly_features = _anomaly_features(residuals)
    anomaly_assets = {}
    all_windows["anomaly_score"] = np.nan
    all_windows["anomaly_percentile"] = np.nan
    all_windows["is_anomaly_raw"] = False

    for regime, hg in healthy.groupby("detected_regime"):
        if len(hg) < 20: continue
        scaler = RobustScaler().fit(hg[anomaly_features])
        x = scaler.transform(hg[anomaly_features])
        model = IsolationForest(n_estimators=350, contamination="auto", random_state=RANDOM_SEED, n_jobs=-1).fit(x)
        train_scores = -model.score_samples(x)
        threshold = float(np.quantile(train_scores, ANOMALY_THRESHOLD_QUANTILE))
        sorted_scores = np.sort(train_scores)
        anomaly_assets[regime] = {"scaler": scaler, "model": model, "threshold": threshold,
                                  "score_reference": sorted_scores}

        idx = all_windows.index[all_windows["detected_regime"] == regime]
        xa = scaler.transform(all_windows.loc[idx, anomaly_features])
        score = -model.score_samples(xa)
        pct = np.searchsorted(sorted_scores, score, side="right") / len(sorted_scores)
        all_windows.loc[idx, "anomaly_score"] = score
        all_windows.loc[idx, "anomaly_percentile"] = pct
        all_windows.loc[idx, "is_anomaly_raw"] = score >= threshold

    all_windows["baseline_excluded_pre_failure"] = excluded
    all_windows["health_deviation"] = np.clip((all_windows["anomaly_percentile"] - 0.50) / 0.50, 0, 1)
    all_windows = apply_persistence(all_windows)
    assets = {
        "version": "2.0", "speed_models": speed_models, "residual_scales": residual_scales,
        "regime_scaler": regime_scaler, "regime_model": regime_model,
        "regime_features": regime_features, "anomaly_features": anomaly_features,
        "anomaly_assets": anomaly_assets, "healthy_window_count": len(healthy),
        "excluded_window_count": int(excluded.sum()),
        "effective_exclusion_hours": effective_exclusion_hours,
        "baseline_quality": "preferred" if effective_exclusion_hours == 72 else "limited_history",
    }
    MODELS_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump(assets, MODELS_DIR / "phase1_assets.joblib")
    return all_windows


def score_phase1(windows: pd.DataFrame) -> pd.DataFrame:
    path = MODELS_DIR / "phase1_assets.joblib"
    if not path.exists(): raise FileNotFoundError("Phase 1 baseline has not been trained.")
    assets = joblib.load(path)
    out, _ = _add_sensor_expectations(windows, assets["speed_models"], assets["residual_scales"])
    xr = assets["regime_scaler"].transform(out[assets["regime_features"]])
    labels = assets["regime_model"].predict(xr)
    out["detected_regime"] = [f"regime_{i}" for i in labels]
    out["regime_confidence"] = assets["regime_model"].predict_proba(xr).max(axis=1)
    out["anomaly_score"] = np.nan; out["anomaly_percentile"] = np.nan; out["is_anomaly_raw"] = False
    for regime, group in out.groupby("detected_regime"):
        if regime not in assets["anomaly_assets"]: continue
        a = assets["anomaly_assets"][regime]
        x = a["scaler"].transform(group[assets["anomaly_features"]])
        scores = -a["model"].score_samples(x)
        pct = np.searchsorted(a["score_reference"], scores, side="right") / len(a["score_reference"])
        out.loc[group.index, "anomaly_score"] = scores
        out.loc[group.index, "anomaly_percentile"] = pct
        out.loc[group.index, "is_anomaly_raw"] = scores >= a["threshold"]
    out["health_deviation"] = np.clip((out["anomaly_percentile"] - 0.50) / 0.50, 0, 1)
    return apply_persistence(out)


def apply_persistence(windows: pd.DataFrame) -> pd.DataFrame:
    out = windows.sort_values("window_center").reset_index(drop=True)
    out["persistent_anomaly"] = False; out["anomaly_event_id"] = np.nan
    event = 0
    for run_id, group in out.groupby("run_id"):
        idx = group.index.to_list(); flags = out.loc[idx, "is_anomaly_raw"].fillna(False).to_numpy(bool)
        start = 0
        while start < len(flags):
            if not flags[start]: start += 1; continue
            end = start + 1
            while end < len(flags) and flags[end]: end += 1
            if end - start >= MIN_CONSECUTIVE_ANOMALOUS_WINDOWS:
                event += 1; event_idx = idx[start:end]
                out.loc[event_idx, "persistent_anomaly"] = True
                out.loc[event_idx, "anomaly_event_id"] = event
            start = end
    return out
