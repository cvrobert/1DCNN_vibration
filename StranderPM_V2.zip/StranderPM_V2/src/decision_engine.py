from __future__ import annotations

import numpy as np
import pandas as pd

from config import (
    ACTIONABLE_RESEMBLANCE_THRESHOLD, ELEVATED_HEALTH_THRESHOLD,
    ANOMALOUS_HEALTH_THRESHOLD, VIBRATION_COLUMNS,
)


def sensor_contributions(scored: pd.DataFrame, recent_windows: int = 12) -> pd.DataFrame:
    recent = scored.tail(recent_windows)
    rows = []
    for sensor in VIBRATION_COLUMNS:
        zcol = f"{sensor}_normalized_residual"
        mean_col = f"{sensor}_mean"
        expected_col = f"{sensor}_expected"
        z = float(recent[zcol].median()) if zcol in recent else np.nan
        actual = float(recent[mean_col].median()) if mean_col in recent else np.nan
        expected = float(recent[expected_col].median()) if expected_col in recent else np.nan
        deviation_pct = ((actual - expected) / max(abs(expected), 1e-9) * 100) if np.isfinite(actual) and np.isfinite(expected) else np.nan
        rows.append({"sensor": sensor, "actual_rms": actual, "expected_rms": expected,
                     "normalized_deviation": z, "deviation_percent": deviation_pct,
                     "contribution": abs(z) if np.isfinite(z) else 0.0})
    return pd.DataFrame(rows).sort_values("contribution", ascending=False).reset_index(drop=True)


def trend_direction(scored: pd.DataFrame, recent_windows: int = 60) -> tuple[str, float]:
    values = scored["anomaly_percentile"].tail(recent_windows).dropna().to_numpy(float)
    if len(values) < 5: return "insufficient data", 0.0
    x = np.arange(len(values))
    slope = float(np.polyfit(x, values, 1)[0])
    if slope > 0.002: return "worsening", slope
    if slope < -0.002: return "improving", slope
    return "stable", slope


def evaluate_machine(scored: pd.DataFrame, resemblance: pd.DataFrame | None = None) -> dict:
    if scored.empty:
        return {"condition": "No data", "health_score": 0, "action": "Load current historian data.",
                "failure_warning": False}
    recent = scored.tail(12)
    recent_pct = float(recent["anomaly_percentile"].median())
    persistent_count = int(scored["persistent_anomaly"].sum())
    active_persistent = bool(recent["persistent_anomaly"].any())
    raw_recent = int(recent["is_anomaly_raw"].sum())
    # Percentiles below 95 are ordinary healthy variation. The health score only
    # begins to fall near the calibrated anomaly boundary, avoiding an alarming
    # score for a merely different but still non-anomalous production condition.
    if recent_pct <= 0.95:
        health = 100
    elif recent_pct <= 0.995:
        health = int(round(100 - 20 * (recent_pct - 0.95) / 0.045))
    else:
        health = int(round(max(0, 80 - 80 * (recent_pct - 0.995) / 0.005)))
    trend, trend_slope = trend_direction(scored)

    top_similarity = None
    top_predictive = False
    if resemblance is not None and not resemblance.empty:
        top_similarity = float(resemblance.iloc[0]["resemblance"])
        top_predictive = bool(resemblance.iloc[0].get("predictive_evidence", False))
    actionable_match = bool(active_persistent and top_predictive and top_similarity is not None and
                            top_similarity >= ACTIONABLE_RESEMBLANCE_THRESHOLD)
    if actionable_match:
        condition = "Anomalous — resembles historical failure"
        action = "Inspect the highest-contributing sensors and affected component before continued operation."
    elif active_persistent:
        condition = "Anomalous — unknown pattern"
        action = "Inspect the machine. The abnormal pattern is persistent but does not reliably match a known precursor."
    elif raw_recent >= 3 and trend == "worsening":
        condition = "Elevated"
        action = "Continue operation with closer monitoring and review recent operating transitions."
    else:
        condition = "Normal"
        action = "Continue normal operation. No actionable failure warning is present."

    return {
        "condition": condition, "health_score": health, "action": action,
        "failure_warning": actionable_match, "active_persistent_anomaly": active_persistent,
        "persistent_anomaly_windows": persistent_count, "recent_raw_anomaly_windows": raw_recent,
        "recent_anomaly_percentile": recent_pct, "trend": trend, "trend_slope": trend_slope,
        "top_resemblance": top_similarity,
    }
