from pathlib import Path
import matplotlib.pyplot as plt
import pandas as pd

from config import OUTPUTS_DIR
from src.decision_engine import sensor_contributions


def save_anomaly_plot(scored_windows: pd.DataFrame, filename: str, title: str) -> Path:
    path = OUTPUTS_DIR / filename
    fig, ax = plt.subplots(figsize=(15, 5))
    ax.plot(scored_windows["window_center"], scored_windows["anomaly_percentile"] * 100,
            linewidth=0.9, label="Healthy-baseline percentile")
    ax.axhline(99.5, linestyle="--", linewidth=1, label="Raw anomaly threshold")
    abnormal = scored_windows[scored_windows["persistent_anomaly"]]
    if not abnormal.empty:
        ax.scatter(abnormal["window_center"], abnormal["anomaly_percentile"] * 100,
                   s=25, label="Persistent anomaly")
    ax.set(title=title, xlabel="Time", ylabel="Unusualness percentile vs healthy baseline")
    ax.set_ylim(0, 101); ax.legend(); fig.tight_layout(); fig.savefig(path, dpi=160); plt.close(fig)
    return path


def create_sensor_status_table(scored_windows: pd.DataFrame) -> pd.DataFrame:
    table = sensor_contributions(scored_windows)
    table.to_csv(OUTPUTS_DIR / "current_sensor_status.csv", index=False)
    return table


def create_text_report(scored_windows, comparison=None, assessment=None) -> Path:
    path = OUTPUTS_DIR / "current_summary_report.txt"
    a = assessment or {}
    lines = [
        "STRANDER PREDICTIVE MAINTENANCE — VERSION 2", "=" * 52, "",
        f"Analysis start: {scored_windows['window_start'].min()}",
        f"Analysis end: {scored_windows['window_end'].max()}",
        f"Windows analyzed: {len(scored_windows):,}", "",
        "ENGINEERING ASSESSMENT", "-" * 30,
        f"Condition: {a.get('condition', 'Unknown')}",
        f"Health score: {a.get('health_score', 'N/A')}/100",
        f"Trend: {a.get('trend', 'unknown')}",
        f"Persistent anomaly active: {a.get('active_persistent_anomaly', False)}",
        f"Persistent anomaly windows: {a.get('persistent_anomaly_windows', 0)}",
        f"Recommendation: {a.get('action', '')}", "",
        "Important: historical resemblance is pattern resemblance, not failure probability.",
        "It can support a warning only when current behavior is independently persistent and abnormal.", "",
    ]
    if comparison is not None and not comparison.empty:
        top = comparison.iloc[0]
        lines += ["CLOSEST HISTORICAL PATTERN", "-" * 30,
                  f"Failure: {top.get('failure_type', '')} ({top.get('failure_id', '')})",
                  f"Phase: {top.get('phase', '')}",
                  f"Pattern resemblance: {float(top.get('resemblance', 0)):.1%}",
                  f"Historical predictive evidence: {bool(top.get('predictive_evidence', False))}",
                  f"Top matching sensors: {top.get('top_matching_sensors', '')}",
                  f"Actionable now: {bool(a.get('failure_warning', False))}"]
    path.write_text("\n".join(lines), encoding="utf-8")
    return path
