import numpy as np
import pandas as pd

from config import (
    SPEED_COLUMN,
    VIBRATION_COLUMNS,
    RUNNING_SPEED_THRESHOLD,
    STARTUP_EXCLUSION_SECONDS,
    SHUTDOWN_EXCLUSION_SECONDS,
)

def clean_and_resample(wide_df: pd.DataFrame) -> pd.DataFrame:
    if wide_df.empty:
        return pd.DataFrame()

    data = (
        wide_df.drop_duplicates("Timestamp", keep="last")
        .sort_values("Timestamp")
        .set_index("Timestamp")
    )

    full_index = pd.date_range(
        data.index.min().floor("s"),
        data.index.max().ceil("s"),
        freq="1s",
    )

    data = data.reindex(full_index)
    data.index.name = "Timestamp"

    numeric_columns = [SPEED_COLUMN, *VIBRATION_COLUMNS]
    data[numeric_columns] = data[numeric_columns].apply(
        pd.to_numeric, errors="coerce"
    )

    # Fill only short gaps.
    data[numeric_columns] = data[numeric_columns].interpolate(
        method="time",
        limit=5,
        limit_direction="both",
    )

    return data.reset_index()

def identify_runs(data: pd.DataFrame) -> pd.DataFrame:
    if data.empty:
        return data

    data = data.copy()
    data["is_running_raw"] = data[SPEED_COLUMN] > RUNNING_SPEED_THRESHOLD

    state_change = data["is_running_raw"].ne(
        data["is_running_raw"].shift(fill_value=False)
    )
    data["state_group"] = state_change.cumsum()
    data["run_id"] = np.nan

    run_counter = 0
    for _, group in data.groupby("state_group"):
        if bool(group["is_running_raw"].iloc[0]):
            run_counter += 1
            data.loc[group.index, "run_id"] = run_counter

    data["seconds_from_run_start"] = np.nan
    data["seconds_to_run_end"] = np.nan

    for run_id, group in data.dropna(subset=["run_id"]).groupby("run_id"):
        idx = group.index
        start_time = group["Timestamp"].iloc[0]
        end_time = group["Timestamp"].iloc[-1]

        data.loc[idx, "seconds_from_run_start"] = (
            group["Timestamp"] - start_time
        ).dt.total_seconds().values

        data.loc[idx, "seconds_to_run_end"] = (
            end_time - group["Timestamp"]
        ).dt.total_seconds().values

    data["steady_running"] = (
        data["is_running_raw"]
        & (data["seconds_from_run_start"] >= STARTUP_EXCLUSION_SECONDS)
        & (data["seconds_to_run_end"] >= SHUTDOWN_EXCLUSION_SECONDS)
    )

    return data
