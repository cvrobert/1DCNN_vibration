"""Central timestamp parsing used by historian imports and failure records."""
from __future__ import annotations

import numbers
import numpy as np
import pandas as pd

from config import TIMESTAMP_DAYFIRST

KNOWN_FORMATS = (
    "%m/%d/%Y %I:%M:%S %p",
    "%m/%d/%Y %H:%M:%S",
    "%Y-%m-%d %H:%M:%S",
    "%Y-%m-%dT%H:%M:%S",
    "%m/%d/%y %I:%M:%S %p",
    "%m/%d/%y %H:%M:%S",
)


def parse_timestamps(values: pd.Series, *, source: str = "timestamps") -> pd.Series:
    """Parse mixed AVEVA/CSV/Excel timestamps without pandas inference warnings.

    The parser tries known formats first, then pandas' mixed parser. Numeric Excel
    serial dates are supported. Time-zone-aware values are converted to naive local
    wall-clock timestamps so they can be compared with plant failure records.
    """
    s = pd.Series(values, copy=False)
    result = pd.Series(pd.NaT, index=s.index, dtype="datetime64[ns]")

    numeric = pd.to_numeric(s, errors="coerce")
    excel_mask = numeric.notna() & numeric.between(20_000, 80_000)
    if excel_mask.any():
        result.loc[excel_mask] = pd.to_datetime(
            numeric.loc[excel_mask], unit="D", origin="1899-12-30", errors="coerce"
        )

    remaining = result.isna() & s.notna()
    text = s.loc[remaining].astype(str).str.strip()
    text = text.replace({"": np.nan, "NaT": np.nan, "nan": np.nan})

    for fmt in KNOWN_FORMATS:
        mask = result.loc[text.index].isna() & text.notna()
        if not mask.any():
            break
        parsed = pd.to_datetime(text.loc[mask], format=fmt, errors="coerce")
        result.loc[parsed.index] = result.loc[parsed.index].fillna(parsed)

    mask = result.loc[text.index].isna() & text.notna()
    if mask.any():
        # format='mixed' avoids the FutureWarning/inference warning and handles
        # fractional seconds and ISO offsets that are not in the explicit list.
        parsed = pd.to_datetime(
            text.loc[mask], format="mixed", dayfirst=TIMESTAMP_DAYFIRST,
            errors="coerce", utc=False,
        )
        # Mixed offsets can produce object dtype. Normalize one value at a time only
        # for the small unresolved subset.
        for idx, value in parsed.items():
            if pd.isna(value):
                continue
            ts = pd.Timestamp(value)
            if ts.tzinfo is not None:
                ts = ts.tz_localize(None)
            result.loc[idx] = ts

    return pd.to_datetime(result, errors="coerce")


def timestamp_diagnostics(original: pd.Series, parsed: pd.Series) -> dict:
    total = int(len(original))
    valid = int(parsed.notna().sum())
    return {
        "total": total,
        "valid": valid,
        "invalid": total - valid,
        "success_rate": (valid / total) if total else 0.0,
        "minimum": parsed.min() if valid else None,
        "maximum": parsed.max() if valid else None,
    }
