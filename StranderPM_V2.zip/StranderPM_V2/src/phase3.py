from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.preprocessing import RobustScaler

from config import OUTPUTS_DIR, VIBRATION_COLUMNS


def _signature_columns(fingerprints: pd.DataFrame) -> list[str]:
    return [c for c in fingerprints.columns if c.endswith("__median") or c.endswith("__p90") or c.endswith("__trend")]


def _current_signature(current: pd.DataFrame, columns: list[str]) -> pd.Series:
    recent = current.tail(max(12, min(len(current), 360)))
    result = {}
    for name in columns:
        source, agg = name.rsplit("__", 1)
        if source not in current:
            result[name] = np.nan; continue
        if agg == "median": result[name] = recent[source].median()
        elif agg == "p90": result[name] = recent[source].quantile(0.90)
        elif agg == "trend":
            n = max(3, len(recent)//3)
            result[name] = recent[source].tail(n).mean() - recent[source].head(n).mean()
    return pd.Series(result)


def compare_current_to_failures(current_scored: pd.DataFrame, fingerprints: pd.DataFrame) -> pd.DataFrame:
    if current_scored.empty or fingerprints.empty:
        return pd.DataFrame()
    cols = _signature_columns(fingerprints)
    if not cols: return pd.DataFrame()
    reference = fingerprints[cols].apply(pd.to_numeric, errors="coerce")
    medians = reference.median(numeric_only=True)
    reference = reference.fillna(medians).fillna(0.0)
    current = _current_signature(current_scored, cols).reindex(cols).fillna(medians).fillna(0.0)
    scaler = RobustScaler().fit(reference)
    ref_scaled = scaler.transform(reference)
    cur_scaled = scaler.transform(pd.DataFrame([current.to_dict()], columns=cols))
    raw = cosine_similarity(cur_scaled, ref_scaled).flatten()
    resemblance = np.clip((raw + 1) / 2, 0, 1)

    metadata = ["failure_id", "failure_type", "affected_area", "failure_time", "phase",
                "window_count", "anomaly_fraction", "persistent_fraction", "predictive_evidence"]
    result = fingerprints[[c for c in metadata if c in fingerprints]].copy()
    result["resemblance"] = resemblance
    # A pattern that was not abnormal before its historical event cannot be used as predictive evidence.
    result["actionable_candidate"] = result["predictive_evidence"].fillna(False).astype(bool)

    # Sensor contribution: compare normalized residual medians, which are directly explainable.
    contribution_rows = []
    for i, row in result.iterrows():
        contributions = []
        for sensor in VIBRATION_COLUMNS:
            col = f"{sensor}_normalized_residual__median"
            if col in fingerprints and f"{sensor}_normalized_residual" in current_scored:
                a = float(current_scored[f"{sensor}_normalized_residual"].tail(12).median())
                b = float(pd.to_numeric(pd.Series([fingerprints.loc[i, col]]), errors="coerce").iloc[0])
                if np.isfinite(a) and np.isfinite(b): contributions.append((sensor, 1 / (1 + abs(a-b))))
        contributions.sort(key=lambda x: x[1], reverse=True)
        contribution_rows.append(", ".join(x[0] for x in contributions[:3]))
    result["top_matching_sensors"] = contribution_rows
    result = result.sort_values(["actionable_candidate", "resemblance"], ascending=[False, False]).reset_index(drop=True)
    result.to_csv(OUTPUTS_DIR / "current_failure_resemblance.csv", index=False)
    # Compatibility output name.
    result.to_csv(OUTPUTS_DIR / "current_failure_similarity.csv", index=False)
    return result
