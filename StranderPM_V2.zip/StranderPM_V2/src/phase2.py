"""Phase 2 compatibility wrappers for the Version 2 failure library."""
from src.failure_library import load_failures, label_failure_phases, build_failure_fingerprints


def label_pre_failure_windows(scored_windows):
    return label_failure_phases(scored_windows)


def build_failure_signatures(labeled_or_scored_windows):
    # V2 rebuilds phase-aware fingerprints from the scored windows. The function
    # name is retained so older menu integrations continue to work.
    return build_failure_fingerprints(labeled_or_scored_windows)
