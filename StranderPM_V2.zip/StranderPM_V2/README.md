# Strander Predictive Maintenance V2

A health-first, explainable predictive-maintenance workflow for AVEVA Historian exports from the TDC 18-position strander.

## What changed in Version 2

- A single timestamp parser handles AVEVA US timestamps, ISO timestamps, fractional seconds, time-zone offsets, and Excel serial dates without pandas format-inference warnings.
- Failure timestamps are validated against the historian date range.
- The healthy baseline excludes the configured period before every known failure.
- Current data is compared with verified healthy operation **before** any historical failure comparison.
- Startup, shutdown, speed, and learned operating regimes are handled separately.
- Anomaly thresholds are calibrated from healthy data by operating regime.
- Failure records are split into context (24–72 h), early (6–24 h), and critical (0–6 h) phases.
- A historical phase must contain actual abnormal evidence before it can support a warning.
- Historical similarity is called **pattern resemblance**, never failure probability.
- A warning requires all three: current abnormality, persistence, and a reliable historical precursor match.
- Reports explain sensor contributions, trend direction, current health, and recommended action.

## Setup

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python main.py
```

Use Command Prompt and `.venv\Scripts\activate.bat` when PowerShell activation is blocked.

## Recommended workflow

1. Put verified historical exports in `data/historical`.
2. Enter failures in `data/failures.csv`.
3. Run menu option 1 to validate tags, dates, and failure timestamp coverage.
4. Run option 2 to train the healthy baseline. Pre-failure windows are excluded automatically.
5. Run option 3 to build phase-aware failure fingerprints.
6. Put the newest export in `data/current` and run option 4.

## Failure file

The original columns remain supported:

```csv
failure_id,failure_time,failure_type,affected_area,description,time_accuracy
```

Optional columns can be added for better engineering context:

```csv
root_cause,maintenance_action,product,operator_notes,vibration_relevant,confidence
```

## Interpretation guardrail

A 99% resemblance means that selected numerical features resemble a historical phase. It does **not** mean a 99% chance of failure. When a historical pre-failure period looked normal, it is marked as lacking predictive evidence and cannot create a warning.

## Key outputs

- `outputs/current_summary_report.txt`
- `outputs/current_assessment.csv`
- `outputs/current_sensor_status.csv`
- `outputs/current_failure_resemblance.csv`
- `outputs/current_anomaly_plot.png`
- `outputs/strander_dashboard_v2.html`

## Limitation

The historian provides one overall RMS value per second, not raw high-frequency waveforms. This system can detect changes in severity, relationships, and trends. It cannot calculate bearing defect or gear-mesh frequencies from overall RMS alone.
