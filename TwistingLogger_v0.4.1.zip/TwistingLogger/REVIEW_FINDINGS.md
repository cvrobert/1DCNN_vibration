# TW2 review — October 20, 2026

Source: review-20261020-113804(1).zip.

All four sampled groups had zero bad samples; no dropped samples or final error.
Fast group: 579 expressions at 100 ms; median gap 145.57 ms, read p95
137.40 ms, max gap 230.75 ms. Broad group: 26,147 expressions at 30 seconds;
read p95 35.55 seconds, max gap 54.48 seconds. Both failed timing.
Process and configuration passed.

Inventory: 19,693 successful controller/drive read expressions, 7,260 successful
program-scoped expressions. Counts include baseline array expressions.
Rejected reads: 2,197 controller-scoped, 2,055 program-scoped. Of controller
failures, 1,983 contain Pad/pad or DEAD_ZONE. Other examples are CfgIDNum,
CfgSize, CalBits, and PanelView ButtonState members. Returned reason: IOI
syntax/path error. This does not prove that every rejected address is
unrecoverable; all remain documented for review.

All 12 payoff OutputFreq and FreqCommand fields passed original discovery.
The additional 304 "missing roots" came from a heuristic L5K comparison with
names such as AccelerationLimit and ActuatorDiameter. This is not treated as a
verified missing-user-tag count. The old reference is not automatically used.

Installed baseline: 55/57/38 expressions. The logger service uses
/opt/twistinglogger with Restart=always. Only the hyphenated export timer
appeared in the saved timer list.

Offline reassignment gives 103 fast, 57 process, 38 configuration, 501 drive
details and 18,850 slow expressions. Every previously successful in-scope leaf
is covered, including values covered by baseline array reads. Program discovery
is intentionally removed. No new live performance is claimed.

The revised package requires fresh discovery and a five-minute trial. No
installed Pi configuration was changed by this review.
