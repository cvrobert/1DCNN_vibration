# TwistingLogger 0.4.1 — controller tags and drive I/O

Start with TW2: Pi 192.168.20.141, PLC 192.168.20.10. This is a software
package, not a bootable SD image. Preparation leaves installed code/config
unchanged and restores the original logger after a temporary trial.

## Scope and rates

Keep original configured groups/rates. Discover readable controller-scoped
array elements and public structure members, including mapped drive I/O.
Do not add program-scoped tags; preserve any already in the baseline.

| Group | Target interval | Expected TW2 expressions |
|---|---:|---:|
| fast_dynamics | 100 ms (baseline) | 103 |
| process | 1 second (baseline) | 57 |
| configuration | 10 seconds (baseline) | 38 |
| drive_details | 1 second | 501 |
| all_other_tags | 60 seconds | 18,850 |

Counts come from offline reassignment of the Oct 20 inventory, not a new live
trial. Discovery validates actual tags again; other machines may differ.
Baseline array expressions expand into multiple CSV columns.

Keep the original 55 fast expressions, adding 12 each of payoff dancer position,
TPTO02_MTR_PO[i].f_Spd_me, drive :I.OutputFreq and :O.FreqCommand. Other
INV drive I/O/status and payoff motor-monitor members go to drive_details unless
already covered. Some promoted values remain in process for continuity.

In reviewed TW2 logic, f_Spd_me = OutputFreq / 100, in Hz despite its RPM
description. f_Ampere = OutputCurrent / 100, in A. Raw fields remain raw;
verify scaling before comparing them with engineering units. Electrical output
frequency is not measured shaft RPM. Generic UDT labels can be misleading.

Group timestamps mark completion of a read cycle, not simultaneous acquisition.
read_duration_ms is the acquisition span. Large slow groups can span seconds;
use fast signals for subsecond event order. One-second status sampling can miss
short pulses. No PLC writes, mode changes, or drive parameter changes occur.
Reads consume PLC resources; observe PLC scan/communication health onsite.

## Exclusions

Failed reads and unsupported members remain in exclusions.csv. Baseline failures
block candidate generation. Readable does not establish meaningful/updating.
There is no claim to capture hidden/private PLC members or unmapped drive
parameters. The old heuristic tw2_reference.json is no longer used automatically:
its root list includes unverified names. --reference is only for an independently
verified root list. See REVIEW_FINDINGS.md.

## Stage from Windows PowerShell

Save TwistingLogger_v0.4.1.zip on the Windows Desktop. At the PS C:\... prompt:

~~~powershell
scp (Join-Path ([Environment]::GetFolderPath("Desktop")) "TwistingLogger_v0.4.1.zip") twistinglogger@192.168.20.141:~/
ssh twistinglogger@192.168.20.141
~~~

Then run these separately ON THE PI:

~~~bash
unzip -n ~/TwistingLogger_v0.4.1.zip -d ~/TwistingLogger_v0.4.1
cd ~/TwistingLogger_v0.4.1/TwistingLogger
sudo bash prepare_existing.sh
~~~

Uses installed Python packages; no internet installation. Stops the old logger
temporarily, performs fresh discovery, then runs a 300-second trial. Allow extra
time for discovery. Normal history has a gap; trial data is retained separately.
Choose a time when that gap is acceptable.

The EXIT trap restores the previous running state, including on a failed gate.
Power loss/SIGKILL cannot execute a trap. Verify after the trial/reconnection:

~~~bash
systemctl is-active twistinglogger.service
~~~

Send the new review folder, or discovery/report.json, discovery/exclusions.csv
and trial/trial_report.json. A new folder path is printed even on failure.
To ZIP the newest review in this staging directory after the trial:

~~~bash
python3 -c 'import pathlib,shutil; p=max((p for p in pathlib.Path(".").glob("review-*") if p.is_dir()),key=lambda p:p.name); print(shutil.make_archive(str(p),"zip",root_dir=p.parent,base_dir=p.name))'
exit
~~~

Back in WINDOWS PowerShell:

~~~powershell
scp "twistinglogger@192.168.20.141:~/TwistingLogger_v0.4.1/TwistingLogger/review-*.zip" ([Environment]::GetFolderPath("Desktop"))
~~~

Gate: at least 3 samples/group, no bad/dropped samples, read p95 below 80% of
interval, gaps below twice interval. Passing is not proof of no PLC scan impact.
Do not use the old v0.4 trial to activate this build.

## Activation after review

Substitute the actual NEW review folder; the timestamp below is an example:

~~~bash
cd ~/TwistingLogger_v0.4.1/TwistingLogger
sudo bash update_existing.sh review-20261021-120000 --accept-exclusions
~~~

Only accept exclusions after reviewing them; omit the flag if there are none.
Activation verifies matching candidate/report hashes, passing gates, unchanged
baseline config, PLC address and data directory. Installed code/config/services
are backed up. Offline update preserves historical data, network and Samba.
After at least two minutes:

~~~bash
systemctl is-active twistinglogger.service
cat /opt/twistinglogger/status.json
systemctl list-timers --all --no-pager
~~~

Check advancing timestamps, live/good quality, durations and dropped samples.
Use the hyphenated twistinglogger-export.timer; avoid duplicate custom timers.
New group definitions generate additional CSVs; select them in the viewer.

## Rollback / export

Use the actual backup filename printed at activation:

~~~bash
sudo systemctl stop twistinglogger.service
sudo tar -xf /opt/twistinglogger/rollback-20261021-120000.tar -C /
sudo systemctl daemon-reload
sudo systemctl start twistinglogger.service
~~~

Early export example (YYYY-MM-DD; replace with desired date):

~~~bash
/opt/twistinglogger/venv/bin/python /opt/twistinglogger/export_zip.py --day 2026-10-21 --force
~~~

Nightly --force replaces partial-day ZIPs. Large ZIP entries are supported.
The candidate keeps at least 10 GiB free: below that, logging stops with an
error and systemd retries with a startup space check. No automatic deletion.
Measure a full day of database PLUS export growth before estimating retention.

## TW1 later

After TW2 succeeds, clone the powered-off ORIGINAL TW1 card onto the new 1 TB
card, keep the original as rollback, and expand the filesystem if needed.
Verify Pi 192.168.10.141 and PLC 192.168.10.10. Do not copy TW2's .20 settings
unchanged. Stage this package and repeat discovery/trial on TW1; do not reuse
TW2's candidate or timing results. This package alone is not an OS image.
