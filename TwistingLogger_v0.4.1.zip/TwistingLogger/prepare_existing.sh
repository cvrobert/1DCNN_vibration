#!/usr/bin/env bash
# Run with sudo. Always restores the old logger's prior running state.
set -euo pipefail
cd "$(dirname "$0")"
[[ $EUID == 0 ]] || { echo 'Use sudo bash prepare_existing.sh'; exit 1; }
stamp=$(date +%Y%m%d-%H%M%S)
out="$PWD/review-$stamp"
mkdir -p "$out"
was_active=false
systemctl is-active --quiet twistinglogger.service && was_active=true
restore() {
  if "$was_active"; then systemctl start twistinglogger.service; fi
  echo "Review folder: $out"
  echo 'Installed code/configuration unchanged; original running state restored.'
}
trap restore EXIT
systemctl stop twistinglogger.service
cp /opt/twistinglogger/config.toml "$out/installed-config.toml"
cat /opt/twistinglogger/VERSION > "$out/installed-version.txt"
systemctl cat twistinglogger.service > "$out/installed-service.txt"
systemctl list-timers --all --no-pager > "$out/timers.txt"
df -h /opt/twistinglogger > "$out/disk.txt"
py=/opt/twistinglogger/venv/bin/python
"$py" discover_tags.py --config "$out/installed-config.toml" --output "$out/discovery" 2>&1 | tee "$out/discovery.log"
mkdir -p "$out/trial"
"$py" logger.py --config "$out/discovery/candidate.toml" --duration 300 --data-dir "$out/trial/data" --status-file "$out/trial/status.json" 2>&1 | tee "$out/trial.log"
"$py" trial_report.py --config "$out/discovery/candidate.toml" --trial-dir "$out/trial" | tee "$out/trial-summary.txt"
echo 'Trial passed. Review results and exclusions before activation.'
