from __future__ import annotations

import math
import webbrowser
from dataclasses import dataclass
from datetime import timedelta
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd
import plotly.graph_objects as go

TAG_MAP: Dict[str, str] = {
    "A31A31DYNLeftCh0Overall": "Lower motor",
    "A31A31DYNLeftCh1Overall": "Upper gearbox",
    "A31A31DYNLeftCh2Overall": "Lower gearbox",
    "A31A31DYNLeftCh3Overall": "Motor-side bearing",
    "A31A31DYNRightCh0Overall": "Motor-side base",
    "A31A31DYNRightCh1Overall": "Non-motor bearing",
    "A31A31DYNRightCh2Overall": "Non-motor base",
    "A31A31DYNRightCh3Overall": "Upper motor",
}
SPEED_TAG = "A31Cps_ActSpd"
SENSOR_ORDER = [
    "Upper motor", "Lower motor", "Upper gearbox", "Lower gearbox",
    "Motor-side bearing", "Non-motor bearing", "Motor-side base", "Non-motor base",
]
SENSOR_COORDS = {
    "Upper motor": (128, 80), "Lower motor": (128, 142),
    "Upper gearbox": (225, 93), "Lower gearbox": (225, 145),
    "Motor-side bearing": (350, 114), "Non-motor bearing": (675, 114),
    "Motor-side base": (350, 198), "Non-motor base": (675, 198),
}

@dataclass
class DashboardSettings:
    project_root: Path
    historical_dir: Path
    current_dir: Path
    failures_csv: Path
    output_html: Path
    resample_rule: str = "5min"
    current_lookback_hours: int = 24
    failure_lookback_hours: int = 72
    top_window_count: int = 10
    minimum_running_speed: float = 1.0

    @classmethod
    def from_project_root(cls, project_root: Path | str) -> "DashboardSettings":
        root = Path(project_root).resolve()
        return cls(root, root / "data" / "historical", root / "data" / "current",
                   root / "data" / "failures.csv", root / "outputs" / "strander_dashboard.html")

def _find_column(columns: Iterable[str], candidates: Iterable[str]) -> Optional[str]:
    lookup = {str(c).strip().lower(): c for c in columns}
    for candidate in candidates:
        if candidate.lower() in lookup:
            return lookup[candidate.lower()]
    for original in columns:
        normalized = str(original).strip().lower().replace("_", "").replace(" ", "")
        for candidate in candidates:
            c_norm = candidate.lower().replace("_", "").replace(" ", "")
            if c_norm in normalized or normalized in c_norm:
                return original
    return None

def _read_csv_flexible(path: Path) -> pd.DataFrame:
    last_error = None
    for encoding in ("utf-8-sig", "utf-8", "cp1252", "latin1"):
        try:
            return pd.read_csv(path, encoding=encoding, low_memory=False)
        except Exception as exc:
            last_error = exc
    raise RuntimeError(f"Could not read {path.name}: {last_error}")

def _normalize_long_export(df: pd.DataFrame, source_name: str) -> pd.DataFrame:
    timestamp_col = _find_column(df.columns, ["Timestamp", "DateTime", "Date Time", "Time", "LocalDateTime"])
    tag_col = _find_column(df.columns, ["TagName", "Tag Name", "Tag", "Name"])
    value_col = _find_column(df.columns, ["Value", "ProcessValue", "Process Value", "NumericValue"])
    if not timestamp_col or not tag_col or not value_col:
        raise ValueError(f"{source_name}: expected Timestamp, TagName, Value columns. Found: {list(df.columns)}")
    work = df[[timestamp_col, tag_col, value_col]].copy()
    work.columns = ["Timestamp", "TagName", "Value"]
    work["Timestamp"] = pd.to_datetime(work["Timestamp"], errors="coerce")
    work["Value"] = pd.to_numeric(work["Value"], errors="coerce")
    work["TagName"] = work["TagName"].astype(str).str.strip()
    work = work.dropna(subset=["Timestamp", "TagName", "Value"])
    return work[work["TagName"].isin(set(TAG_MAP) | {SPEED_TAG})]

def load_aveva_folder(folder: Path) -> pd.DataFrame:
    folder.mkdir(parents=True, exist_ok=True)
    frames, errors = [], []
    for path in sorted(folder.glob("*.csv")):
        try:
            normalized = _normalize_long_export(_read_csv_flexible(path), path.name)
            if not normalized.empty:
                frames.append(normalized)
        except Exception as exc:
            errors.append(f"{path.name}: {exc}")
    if not frames:
        if errors:
            raise RuntimeError("No usable AVEVA data found:\n" + "\n".join(errors))
        return pd.DataFrame()
    long_df = pd.concat(frames, ignore_index=True).drop_duplicates(["Timestamp", "TagName"], keep="last")
    wide = long_df.pivot(index="Timestamp", columns="TagName", values="Value").sort_index().rename(columns=TAG_MAP)
    wide.columns.name = None
    return wide.replace([np.inf, -np.inf], np.nan).interpolate(method="time", limit=10, limit_area="inside")

def load_failures(path: Path) -> pd.DataFrame:
    cols = ["failure_id", "failure_time", "failure_type", "affected_area", "description", "time_accuracy"]
    if not path.exists():
        return pd.DataFrame(columns=cols)
    df = _read_csv_flexible(path)
    time_col = _find_column(df.columns, ["failure_time", "Failure Time", "Timestamp"])
    if not time_col:
        return pd.DataFrame(columns=cols)
    df["failure_time"] = pd.to_datetime(df[time_col], errors="coerce")
    df = df.dropna(subset=["failure_time"]).sort_values("failure_time")
    defaults = {"failure_id":"", "failure_type":"Unspecified failure", "affected_area":"Unspecified area", "description":"", "time_accuracy":""}
    for col, default in defaults.items():
        if col not in df.columns:
            df[col] = default
    return df[cols]

def _sensor_columns(df: pd.DataFrame) -> List[str]:
    return [s for s in SENSOR_ORDER if s in df.columns]

def make_windows(data: pd.DataFrame, rule: str, minimum_running_speed: float) -> pd.DataFrame:
    if data.empty:
        return pd.DataFrame()
    working = data.copy()
    working["Speed"] = working[SPEED_TAG] if SPEED_TAG in working.columns else np.nan
    sensors = _sensor_columns(working)
    if not sensors:
        return pd.DataFrame()
    aggs = {s:["mean","max","std"] for s in sensors}
    aggs["Speed"] = ["mean","max"]
    windows = working.resample(rule).agg(aggs)
    windows.columns = [f"{a}__{b}" for a,b in windows.columns.to_flat_index()]
    windows["is_running"] = windows.get("Speed__mean", pd.Series(True, index=windows.index)) >= minimum_running_speed
    return windows.dropna(how="all", subset=[f"{s}__mean" for s in sensors])

def robust_baseline(historical_windows: pd.DataFrame, failures: pd.DataFrame, lookback_hours: int):
    if historical_windows.empty:
        return pd.Series(dtype=float), pd.Series(dtype=float), historical_windows
    baseline = historical_windows[historical_windows["is_running"].astype(bool)].copy()
    if not failures.empty:
        keep = pd.Series(True, index=baseline.index)
        for t in failures["failure_time"]:
            keep &= ~((baseline.index >= t - timedelta(hours=lookback_hours)) & (baseline.index <= t))
        baseline = baseline.loc[keep]
    features = [c for c in baseline.columns if (c.endswith("__mean") or c.endswith("__max") or c.endswith("__std")) and not c.startswith("Speed__")]
    median = baseline[features].median()
    mad = (baseline[features] - median).abs().median()
    scale = (1.4826 * mad).replace(0, np.nan).fillna(baseline[features].std().replace(0, np.nan)).fillna(1e-6)
    return median, scale, baseline

def score_windows(windows: pd.DataFrame, median: pd.Series, scale: pd.Series) -> pd.DataFrame:
    if windows.empty or median.empty:
        return pd.DataFrame(index=windows.index)
    features = [c for c in median.index if c in windows.columns]
    z = ((windows[features] - median[features]) / scale[features]).abs().clip(upper=20)
    scored = windows.copy()
    scored["anomaly_score"] = 0.55*z.quantile(.75, axis=1) + 0.30*z.mean(axis=1) + 0.15*z.max(axis=1)
    scored.loc[~scored["is_running"].astype(bool), "anomaly_score"] = np.nan
    for sensor in SENSOR_ORDER:
        cols = [f"{sensor}__mean", f"{sensor}__max", f"{sensor}__std"]
        cols = [c for c in cols if c in z.columns]
        if cols:
            scored[f"{sensor}__score"] = z[cols].mean(axis=1)
    return scored

def health_from_score(score: float):
    if pd.isna(score): return 100, "No running data", "unknown"
    health = max(0, min(100, int(round(100 * math.exp(-0.30 * max(score, 0))))))
    if score < 1.5: return health, "Normal", "normal"
    if score < 2.5: return health, "Elevated", "elevated"
    if score < 4.0: return health, "Anomalous", "anomalous"
    return health, "Critical", "critical"

def status_from_score(score: float):
    return health_from_score(score)[2]

def current_sensor_summary(scored: pd.DataFrame) -> pd.DataFrame:
    rows = []
    if scored.empty: return pd.DataFrame()
    recent = scored.tail(12)
    for sensor in SENSOR_ORDER:
        m, x, s = f"{sensor}__mean", f"{sensor}__max", f"{sensor}__score"
        if m in recent:
            score = recent[s].median() if s in recent else np.nan
            rows.append({"sensor":sensor, "average":recent[m].mean(), "maximum":recent[x].max() if x in recent else np.nan, "score":score, "status":status_from_score(score)})
    return pd.DataFrame(rows).sort_values("score", ascending=False) if rows else pd.DataFrame()

def failure_case_similarity(hist, current, failures, median, scale, lookback_hours):
    if hist.empty or current.empty or failures.empty or median.empty: return pd.DataFrame()
    features = [c for c in median.index if c in hist.columns and c in current.columns]
    current_vec = ((current.tail(12)[features].median() - median[features]) / scale[features]).fillna(0)
    results = []
    for _, row in failures.iterrows():
        t = row["failure_time"]
        case = hist.loc[(hist.index >= t - timedelta(hours=lookback_hours)) & (hist.index <= t), features]
        if case.empty: continue
        case = case.tail(max(6, len(case)//2))
        case_vec = ((case.median() - median[features]) / scale[features]).fillna(0)
        a, b = current_vec.to_numpy(float), case_vec.to_numpy(float)
        denom = np.linalg.norm(a)*np.linalg.norm(b)
        cosine = float(np.dot(a,b)/denom) if denom else 0.0
        mag = min(np.linalg.norm(a),np.linalg.norm(b))/max(np.linalg.norm(a),np.linalg.norm(b)) if max(np.linalg.norm(a),np.linalg.norm(b)) else 0.0
        sim = max(0.0, min(1.0, .75*max(cosine,0)+.25*mag))
        results.append({"failure_id":row["failure_id"], "failure_time":t, "failure_type":row["failure_type"], "affected_area":row["affected_area"], "similarity":round(100*sim,1)})
    return pd.DataFrame(results).sort_values("similarity", ascending=False) if results else pd.DataFrame()

def _plotly_div(fig, include_js=False):
    return fig.to_html(full_html=False, include_plotlyjs="cdn" if include_js else False, config={"displaylogo":False,"responsive":True,"scrollZoom":True})

def make_vibration_trend(data):
    fig = go.Figure()
    if data.empty:
        fig.add_annotation(text="No current data available", showarrow=False)
    else:
        if len(data) > 20000: data = data.iloc[::max(1,len(data)//20000)]
        for sensor in _sensor_columns(data):
            fig.add_trace(go.Scattergl(x=data.index,y=data[sensor],mode="lines",name=sensor,line={"width":1},hovertemplate="%{x}<br>%{y:.3f} mm/s<extra>%{fullData.name}</extra>"))
    fig.update_layout(title="Current vibration trends",height=520,xaxis_title="Time",yaxis_title="Overall RMS vibration (mm/s)",legend={"orientation":"h","y":-0.25},hovermode="x unified")
    return fig

def make_anomaly_timeline(scored, failures):
    fig = go.Figure()
    if scored.empty or "anomaly_score" not in scored:
        fig.add_annotation(text="No anomaly scores available", showarrow=False)
    else:
        fig.add_trace(go.Scatter(x=scored.index,y=scored["anomaly_score"],mode="lines",name="Anomaly score"))
        for y,label in [(1.5,"Elevated"),(2.5,"Anomalous"),(4.0,"Critical")]: fig.add_hline(y=y,line_dash="dot",annotation_text=label)
        for _,f in failures.iterrows(): fig.add_vline(x=f["failure_time"].timestamp()*1000,line_dash="dash",annotation_text=str(f["failure_type"]))
    fig.update_layout(title="Anomaly score over time",height=380,xaxis_title="Time",yaxis_title="Robust anomaly score")
    return fig

def make_sensor_bar(summary):
    fig = go.Figure()
    if summary.empty: fig.add_annotation(text="No sensor summary available",showarrow=False)
    else:
        d=summary.sort_values("average")
        fig.add_trace(go.Bar(x=d["average"],y=d["sensor"],orientation="h",customdata=np.column_stack([d["maximum"],d["score"]]),hovertemplate="%{y}<br>Avg %{x:.3f} mm/s<br>Max %{customdata[0]:.3f}<br>Score %{customdata[1]:.2f}<extra></extra>"))
    fig.update_layout(title="Current average vibration by sensor",height=430,xaxis_title="Average RMS vibration (mm/s)")
    return fig

def make_similarity_bar(sim):
    fig=go.Figure()
    if sim.empty: fig.add_annotation(text="No historical failure cases available",showarrow=False)
    else:
        d=sim.head(10).sort_values("similarity").copy(); d["label"]=d["failure_type"].astype(str)+" — "+d["failure_id"].astype(str)
        fig.add_trace(go.Bar(x=d["similarity"],y=d["label"],orientation="h"))
    fig.update_layout(title="Similarity to historical failure cases",height=380,xaxis={"title":"Similarity (%)","range":[0,100]})
    return fig

def make_heatmap(scored):
    fig=go.Figure(); cols=[f"{s}__score" for s in SENSOR_ORDER if f"{s}__score" in scored]
    if scored.empty or not cols: fig.add_annotation(text="No sensor-level history available",showarrow=False)
    else:
        d=scored[cols].resample("1D").quantile(.90); d.columns=[c.replace("__score","") for c in d.columns]
        fig.add_trace(go.Heatmap(z=d.T.values,x=d.index,y=d.columns,colorbar={"title":"Deviation"}))
    fig.update_layout(title="Daily sensor heat map",height=430,xaxis_title="Day")
    return fig

def make_failure_timeline(failures):
    fig=go.Figure()
    if failures.empty: fig.add_annotation(text="No failures entered yet",showarrow=False)
    else:
        labels=[f"{r.failure_id} — {r.failure_type}" for r in failures.itertuples()]
        fig.add_trace(go.Scatter(x=failures["failure_time"],y=list(range(len(failures))),mode="markers",marker={"size":15},text=labels,hovertemplate="%{text}<br>%{x}<extra></extra>"))
    fig.update_layout(title="Maintenance and failure timeline",height=max(300,90+35*len(failures)),yaxis={"showticklabels":False})
    return fig

def machine_svg(summary):
    status_lookup,value_lookup={},{}
    if not summary.empty:
        for r in summary.itertuples(): status_lookup[r.sensor]=r.status; value_lookup[r.sensor]=r.average
    colors={"normal":"#22c55e","elevated":"#eab308","anomalous":"#f97316","critical":"#ef4444","unknown":"#94a3b8"}
    nodes=[]
    for sensor,(x,y) in SENSOR_COORDS.items():
        st=status_lookup.get(sensor,"unknown"); val=value_lookup.get(sensor,np.nan); txt="No data" if pd.isna(val) else f"{val:.3f} mm/s"
        nodes.append(f'<g><circle cx="{x}" cy="{y}" r="13" fill="{colors[st]}" stroke="white" stroke-width="3"><title>{sensor}: {txt}</title></circle><text x="{x}" y="{y+29}" text-anchor="middle" class="sensor-label">{sensor}</text><text x="{x}" y="{y+45}" text-anchor="middle" class="sensor-value">{txt}</text></g>')
    return f'''<svg viewBox="0 0 820 275" role="img" aria-label="TDC 18-position strander sensor map"><rect x="70" y="58" width="115" height="112" rx="14" fill="#334155"/><rect x="188" y="70" width="82" height="105" rx="10" fill="#475569"/><line x1="270" y1="122" x2="314" y2="122" stroke="#64748b" stroke-width="16"/><rect x="310" y="72" width="405" height="98" rx="49" fill="#64748b"/><ellipse cx="350" cy="121" rx="28" ry="49" fill="#334155"/><ellipse cx="675" cy="121" rx="28" ry="49" fill="#334155"/><line x1="395" y1="86" x2="630" y2="156" stroke="#cbd5e1" stroke-width="8"/><line x1="395" y1="156" x2="630" y2="86" stroke="#cbd5e1" stroke-width="8"/><rect x="290" y="184" width="455" height="26" rx="6" fill="#334155"/>{''.join(nodes)}</svg>'''

def top_windows_table(scored,count):
    if scored.empty or "anomaly_score" not in scored: return "<p>No scored windows available.</p>"
    top=scored.dropna(subset=["anomaly_score"]).nlargest(count,"anomaly_score")
    rows=[]; sensor_cols=[c for c in top if c.endswith("__score")]
    for t,row in top.iterrows():
        strongest="Unknown"; sscore=""
        if sensor_cols:
            vals=row[sensor_cols].dropna()
            if not vals.empty: strongest=vals.idxmax().replace("__score",""); sscore=f"{vals.max():.2f}"
        _,status,key=health_from_score(row["anomaly_score"])
        rows.append(f"<tr><td>{t:%Y-%m-%d %H:%M}</td><td><span class='badge {key}'>{status}</span></td><td>{row['anomaly_score']:.2f}</td><td>{strongest}</td><td>{sscore}</td></tr>")
    return "<div class='table-wrap'><table><thead><tr><th>Window</th><th>Status</th><th>Score</th><th>Strongest sensor</th><th>Sensor score</th></tr></thead><tbody>"+"".join(rows)+"</tbody></table></div>"

def failure_table(sim):
    if sim.empty: return "<p>No comparable historical failure cases found.</p>"
    rows=[f"<tr><td>{r.failure_id}</td><td>{r.failure_type}</td><td>{r.affected_area}</td><td>{r.failure_time:%Y-%m-%d %H:%M}</td><td><strong>{r.similarity:.1f}%</strong></td></tr>" for r in sim.head(10).itertuples()]
    return "<div class='table-wrap'><table><thead><tr><th>ID</th><th>Failure type</th><th>Area</th><th>Time</th><th>Similarity</th></tr></thead><tbody>"+"".join(rows)+"</tbody></table></div>"

def generate_dashboard(project_root: Path | str = ".", open_browser: bool = True) -> Path:
    s=DashboardSettings.from_project_root(project_root); s.output_html.parent.mkdir(parents=True,exist_ok=True)
    historical=load_aveva_folder(s.historical_dir); current=load_aveva_folder(s.current_dir); failures=load_failures(s.failures_csv)
    hw=make_windows(historical,s.resample_rule,s.minimum_running_speed); cw=make_windows(current,s.resample_rule,s.minimum_running_speed)
    median,scale,baseline=robust_baseline(hw,failures,s.failure_lookback_hours)
    sh=score_windows(hw,median,scale); sc=score_windows(cw,median,scale)
    summary=current_sensor_summary(sc); sim=failure_case_similarity(hw,cw,failures,median,scale,s.failure_lookback_hours)
    latest=sc["anomaly_score"].tail(12).median() if not sc.empty and "anomaly_score" in sc else np.nan
    health,status,key=health_from_score(latest)
    strongest="No current data"; strongest_val=""
    if not summary.empty: strongest=summary.iloc[0]["sensor"]; strongest_val=f"{summary.iloc[0]['average']:.3f} mm/s"
    closest="No historical match"; closest_sim=""
    if not sim.empty: closest=f"{sim.iloc[0]['failure_type']} ({sim.iloc[0]['failure_id']})"; closest_sim=f"{sim.iloc[0]['similarity']:.1f}%"
    latest_time=current.index.max().strftime("%Y-%m-%d %H:%M:%S") if not current.empty else "No current files loaded"
    combined=pd.concat([sh,sc]).sort_index()
    css='''body{margin:0;font-family:Segoe UI,Arial,sans-serif;background:#f1f5f9;color:#0f172a}.page{max-width:1500px;margin:auto;padding:24px}.header{display:flex;justify-content:space-between;gap:20px}.grid{display:grid;grid-template-columns:repeat(12,1fr);gap:18px}.card{background:white;border:1px solid #e2e8f0;border-radius:14px;padding:18px;min-width:0}.metric{grid-column:span 3}.half{grid-column:span 6}.full{grid-column:span 12}.metric-label,.muted{color:#64748b}.metric-value{font-size:28px;font-weight:750}.badge,.status-pill{display:inline-block;border-radius:999px;padding:5px 10px;font-weight:700;font-size:13px}.normal{background:#dcfce7;color:#166534}.elevated{background:#fef9c3;color:#854d0e}.anomalous{background:#ffedd5;color:#9a3412}.critical{background:#fee2e2;color:#991b1b}.unknown{background:#e2e8f0;color:#334155}.health-track{height:14px;background:#e2e8f0;border-radius:999px;overflow:hidden}.health-fill{height:100%;background:linear-gradient(90deg,#ef4444,#eab308 55%,#22c55e)}svg{width:100%;height:auto}.sensor-label{font-size:11px;fill:#0f172a;font-weight:650}.sensor-value{font-size:10px;fill:#64748b}.table-wrap{overflow-x:auto}table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:10px 12px;border-bottom:1px solid #e2e8f0;white-space:nowrap}th{font-size:12px;color:#64748b}@media(max-width:900px){.metric,.half{grid-column:span 12}.page{padding:12px}.header{display:block}}'''
    html=f'''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Strander Dashboard</title><style>{css}</style></head><body><div class="page"><div class="header"><div><h1>TDC 18-Position Strander Health Dashboard</h1><p class="muted">Latest current sample: {latest_time}</p></div><div><span class="status-pill {key}">{status}</span></div></div><div class="grid"><section class="card metric"><div class="metric-label">Machine health</div><div class="metric-value">{health}%</div><div class="health-track"><div class="health-fill" style="width:{health}%"></div></div></section><section class="card metric"><div class="metric-label">Current status</div><div class="metric-value">{status}</div><div class="muted">Score: {'' if pd.isna(latest) else f'{latest:.2f}'}</div></section><section class="card metric"><div class="metric-label">Most elevated sensor</div><div class="metric-value" style="font-size:22px">{strongest}</div><div class="muted">{strongest_val}</div></section><section class="card metric"><div class="metric-label">Closest historical failure</div><div class="metric-value" style="font-size:20px">{closest}</div><div class="muted">{closest_sim}</div></section><section class="card full"><h2>Machine sensor map</h2>{machine_svg(summary)}<p class="muted">Edit SENSOR_COORDS in src/dashboard.py if you want to fine-tune physical locations.</p></section><section class="card full">{_plotly_div(make_vibration_trend(current.tail(s.current_lookback_hours*3600)),True)}</section><section class="card half">{_plotly_div(make_sensor_bar(summary))}</section><section class="card half">{_plotly_div(make_similarity_bar(sim))}</section><section class="card full">{_plotly_div(make_anomaly_timeline(combined,failures))}</section><section class="card full">{_plotly_div(make_heatmap(sh))}</section><section class="card full"><h2>Top {s.top_window_count} most important windows</h2>{top_windows_table(combined,s.top_window_count)}</section><section class="card half">{_plotly_div(make_failure_timeline(failures))}</section><section class="card half"><h2>Historical failure matches</h2>{failure_table(sim)}</section><section class="card full"><h2>Data coverage</h2><p><strong>Healthy baseline windows:</strong> {len(baseline):,}</p><p><strong>Known failures:</strong> {len(failures):,}</p></section></div><p class="muted">Engineering decision-support only. Similarity does not prove the same component will fail.</p></div></body></html>'''
    s.output_html.write_text(html,encoding="utf-8")
    summary.to_csv(s.output_html.parent/"dashboard_sensor_summary.csv",index=False)
    sim.to_csv(s.output_html.parent/"dashboard_failure_similarity.csv",index=False)
    if not sc.empty: sc.to_csv(s.output_html.parent/"dashboard_current_window_scores.csv")
    print(f"\nDashboard created:\n{s.output_html}\n")
    if open_browser: webbrowser.open(s.output_html.as_uri())
    return s.output_html

if __name__ == "__main__":
    generate_dashboard(Path(__file__).resolve().parents[1])
