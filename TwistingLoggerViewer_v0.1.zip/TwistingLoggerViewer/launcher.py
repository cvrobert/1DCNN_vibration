"""Windows launcher with a native file/folder picker for the Streamlit viewer."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path
from tkinter import Tk, filedialog, messagebox


def select_source() -> str | None:
    root = Tk()
    root.withdraw()
    root.attributes("-topmost", True)
    selected = filedialog.askopenfilename(
        title="Select a TwistingLogger daily ZIP or CSV",
        filetypes=[
            ("TwistingLogger exports", "*.zip *.csv"),
            ("ZIP archives", "*.zip"),
            ("CSV files", "*.csv"),
            ("All files", "*.*"),
        ],
    )
    if not selected:
        use_folder = messagebox.askyesno(
            "Select folder",
            "No file was selected. Would you like to select a folder containing CSV files?",
            parent=root,
        )
        if use_folder:
            selected = filedialog.askdirectory(
                title="Select a folder containing TwistingLogger CSV files"
            )
    root.destroy()
    return selected or None


def main() -> int:
    source = select_source()
    if source is None:
        return 0

    project = Path(__file__).resolve().parent
    command = [
        sys.executable,
        "-m",
        "streamlit",
        "run",
        str(project / "app.py"),
        "--server.headless=false",
        "--browser.gatherUsageStats=false",
        "--",
        "--source",
        source,
    ]
    return subprocess.call(command, cwd=project)


if __name__ == "__main__":
    raise SystemExit(main())

