# TwistingLogger Data Viewer

Version 0.1.0

This offline Windows viewer opens a TwistingLogger daily ZIP, an individual CSV,
or a folder containing the exported CSV groups. It filters the data to a precise
time window before plotting selected tags.

## First-time installation

1. Extract this entire folder to the Windows computer.
2. Connect the computer to the internet for the initial installation.
3. Double-click `Install_Viewer.bat`.
4. If Python is not installed, install Python 3.11 or newer from python.org and
   select **Add Python to PATH** during installation.

The viewer does not need internet access after installation.

## Open logger data

1. Double-click `Start_Viewer.bat`.
2. Select the daily `TwistingLogger-YYYY-MM-DD.zip` file.
3. The viewer opens in the default web browser, but all processing remains on
   the local computer.
4. Choose Eastern local time or UTC.
5. Enter the event start and end time.
6. Select tags from any of the available group tabs.
7. Select **Stacked historian tracks** to compare different scales, or
   **Overlay all tags** to place them on one chart.
8. Select **Plot selected tags**.

## Viewer functions

- Trends tags from multiple sample groups on a synchronized time axis.
- Reads only the requested columns and time window from large CSV files.
- Uses min/max decimation for display so short current spikes are retained.
- Supports zooming, panning, hover values, and an optional event-time marker.
- Converts logger UTC timestamps to America/New_York time.
- Exports the selected raw time window to a smaller ZIP of CSV files.
- Saves the interactive trend as a standalone HTML file.

## Notes

- The source ZIP and CSV files are never modified.
- The 100 ms fast-dynamics data is best viewed over a focused window around the
  event, such as 5 to 30 minutes.
- Select no more than 24 tags at once for a readable display.
- Boolean tags are displayed as 0 for false and 1 for true.
- A current-day early export is a snapshot only through the time it was created.
