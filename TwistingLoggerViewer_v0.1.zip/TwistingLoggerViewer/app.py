"""Interactive historian-style viewer for TwistingLogger CSV and ZIP exports."""

from __future__ import annotations

import argparse
from datetime import timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from plotly.subplots import make_subplots

from viewer_core import (
    SourceCatalog,
    build_filtered_zip,
    catalog_source,
    local_selection_to_utc,
    materialize_group,
    minmax_decimate,
    read_time_window,
    scan_catalog_time_range,
)


LOCAL_TIMEZONE = "America/New_York"


def source_argument() -> str:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--source", default="")
    args, _ = parser.parse_known_args()
    return args.source


@st.cache_resource(show_spinner=False)
def load_catalog(source: str) -> SourceCatalog:
    return catalog_source(source)


@st.cache_data(show_spinner=False)
def catalog_range(source_path: str, groups_signature: tuple[str, ...]):
    catalog = load_catalog(source_path)
    return scan_catalog_time_range(catalog)


@st.cache_data(show_spinner=False)
def load_group_window(
    source_path: str,
    group_id: str,
    tags: tuple[str, ...],
    start_iso: str,
    end_iso: str,
):
    catalog = load_catalog(source_path)
    group = next(item for item in catalog.groups if item.group_id == group_id)
    csv_path = materialize_group(catalog, group)
    return read_time_window(
        csv_path,
        tags,
        pd.Timestamp(start_iso),
        pd.Timestamp(end_iso),
    )


def initialize_source() -> None:
    if "source_path" not in st.session_state:
        st.session_state.source_path = source_argument()


def display_timestamp(series: pd.Series, mode: str) -> pd.Series:
    timestamps = pd.to_datetime(
        series,
        utc=True,
        errors="coerce",
        format="mixed",
    )
    if mode == "Eastern local time":
        return timestamps.dt.tz_convert(LOCAL_TIMEZONE)
    return timestamps


def create_figure(
    data_by_group: dict[str, tuple[pd.DataFrame, tuple[str, ...]]],
    plot_mode: str,
    timezone_mode: str,
    max_points: int,
    event_utc: pd.Timestamp | None,
) -> go.Figure:
    traces: list[tuple[str, str, pd.DataFrame]] = []
    for group_name, (frame, tags) in data_by_group.items():
        for tag in tags:
            traces.append((group_name, tag, frame))

    if plot_mode == "Stacked historian tracks":
        figure = make_subplots(
            rows=len(traces),
            cols=1,
            shared_xaxes=True,
            vertical_spacing=min(0.025, 0.20 / max(1, len(traces))),
            subplot_titles=[f"{group}: {tag}" for group, tag, _ in traces],
        )
        for row, (group_name, tag, frame) in enumerate(traces, start=1):
            x_values = display_timestamp(frame["timestamp_utc"], timezone_mode)
            x_plot, y_plot = minmax_decimate(x_values, frame[tag], max_points)
            figure.add_trace(
                go.Scattergl(
                    x=x_plot,
                    y=y_plot,
                    mode="lines",
                    name=f"{group_name}: {tag}",
                    line={"width": 1.25},
                    connectgaps=False,
                    hovertemplate="%{x}<br>%{y}<extra>" + tag + "</extra>",
                ),
                row=row,
                col=1,
            )
            figure.update_yaxes(title_text=tag, row=row, col=1)
        height = max(600, min(2600, 210 * len(traces)))
    else:
        figure = go.Figure()
        for group_name, tag, frame in traces:
            x_values = display_timestamp(frame["timestamp_utc"], timezone_mode)
            x_plot, y_plot = minmax_decimate(x_values, frame[tag], max_points)
            figure.add_trace(
                go.Scattergl(
                    x=x_plot,
                    y=y_plot,
                    mode="lines",
                    name=f"{group_name}: {tag}",
                    line={"width": 1.3},
                    connectgaps=False,
                    hovertemplate="%{x}<br>%{y}<extra>" + tag + "</extra>",
                )
            )
        height = 720

    if event_utc is not None:
        event_display = event_utc
        if timezone_mode == "Eastern local time":
            event_display = event_utc.tz_convert(LOCAL_TIMEZONE)
        figure.add_vline(
            x=event_display,
            line_width=2,
            line_dash="dash",
            line_color="#C62828",
            annotation_text="Event",
        )

    figure.update_layout(
        title="TwistingLogger historian view",
        height=height,
        template="plotly_white",
        hovermode="x unified" if plot_mode != "Stacked historian tracks" else "x",
        legend={"orientation": "h", "yanchor": "bottom", "y": 1.02, "x": 0},
        margin={"l": 90, "r": 25, "t": 100, "b": 65},
    )
    figure.update_xaxes(
        title_text=timezone_mode,
        showspikes=True,
        spikemode="across",
        spikesnap="cursor",
        rangeslider={"visible": plot_mode != "Stacked historian tracks"},
    )
    return figure


def main() -> None:
    st.set_page_config(
        page_title="TwistingLogger Viewer",
        page_icon="📈",
        layout="wide",
    )
    initialize_source()

    st.title("TwistingLogger Data Viewer")
    st.caption(
        "Open a daily logger ZIP or CSV, select an exact time window, and trend tags "
        "from multiple sample groups on a synchronized time axis."
    )

    with st.sidebar:
        st.header("Data source")
        source = st.text_input(
            "ZIP, CSV, or CSV folder",
            key="source_path",
            help="Paste a full Windows path, or restart with Start_Viewer.bat to use the file picker.",
        )
        load_clicked = st.button("Load source", type="primary", width="stretch")

    if load_clicked:
        st.cache_resource.clear()
        st.cache_data.clear()
        st.session_state.pop("catalog_loaded", None)
        st.session_state.pop("plot_result", None)

    if not source:
        st.info("Choose a TwistingLogger ZIP or CSV using Start_Viewer.bat, or paste its path in the sidebar.")
        return

    try:
        catalog = load_catalog(source)
        st.session_state.catalog_loaded = True
        group_signature = tuple(group.group_id for group in catalog.groups)
        with st.spinner("Reading timestamp ranges from the selected logger data..."):
            minimum_utc, maximum_utc = catalog_range(catalog.source_path, group_signature)
    except Exception as error:
        st.error(f"Unable to load the source: {error}")
        return

    minimum_local = minimum_utc.tz_convert(LOCAL_TIMEZONE)
    maximum_local = maximum_utc.tz_convert(LOCAL_TIMEZONE)
    st.success(
        f"Loaded {Path(catalog.source_path).name} — "
        f"{minimum_local:%Y-%m-%d %H:%M:%S} through {maximum_local:%Y-%m-%d %H:%M:%S} Eastern"
    )

    st.subheader("1 Select the event window")
    timezone_mode = st.radio(
        "Time display",
        ["Eastern local time", "UTC"],
        horizontal=True,
    )
    display_zone = LOCAL_TIMEZONE if timezone_mode == "Eastern local time" else "UTC"
    minimum_display = minimum_utc.tz_convert(display_zone)
    maximum_display = maximum_utc.tz_convert(display_zone)

    default_end = maximum_display
    default_start = max(minimum_display, default_end - timedelta(minutes=10))
    time_columns = st.columns(4)
    start_date = time_columns[0].date_input("Start date", value=default_start.date())
    start_time = time_columns[1].time_input(
        "Start time",
        value=default_start.time().replace(tzinfo=None),
        step=1,
    )
    end_date = time_columns[2].date_input("End date", value=default_end.date())
    end_time = time_columns[3].time_input(
        "End time",
        value=default_end.time().replace(tzinfo=None),
        step=1,
    )

    try:
        start_utc = local_selection_to_utc(start_date, start_time, display_zone)
        # Treat the displayed end second as inclusive so all 100 ms samples in
        # that second are included even though the UI intentionally stays at
        # a practical one-second resolution.
        end_utc = (
            local_selection_to_utc(end_date, end_time, display_zone)
            + pd.Timedelta(seconds=1)
            - pd.Timedelta(microseconds=1)
        )
    except Exception as error:
        st.error(f"Invalid time selection: {error}")
        return
    if end_utc <= start_utc:
        st.error("The end time must be later than the start time.")
        return

    st.subheader("2 Select tags")
    selections: dict[str, tuple[str, ...]] = {}
    tabs = st.tabs([group.display_name for group in catalog.groups])
    for tab, group in zip(tabs, catalog.groups):
        with tab:
            st.caption(f"{len(group.tag_columns)} available tags from {group.filename}")
            selected = st.multiselect(
                "Tags to trend",
                options=list(group.tag_columns),
                key=f"tags:{catalog.source_path}:{group.group_id}",
                placeholder="Search or select one or more tags",
            )
            if selected:
                selections[group.group_id] = tuple(selected)

    st.subheader("3 Build the trend")
    option_columns = st.columns([2, 2, 2, 1])
    plot_mode = option_columns[0].selectbox(
        "Display mode",
        ["Stacked historian tracks", "Overlay all tags"],
    )
    max_points = option_columns[1].select_slider(
        "Maximum points per trace",
        options=[5_000, 10_000, 25_000, 50_000, 100_000],
        value=25_000,
        help="Min/max decimation preserves short peaks while keeping the display responsive.",
    )
    mark_event = option_columns[2].checkbox("Add event-time marker")
    event_time = option_columns[3].time_input(
        "Event time",
        value=start_time,
        step=1,
        disabled=not mark_event,
    )

    if st.button("Plot selected tags", type="primary", width="stretch"):
        if not selections:
            st.warning("Select at least one tag from one of the group tabs.")
        elif sum(len(value) for value in selections.values()) > 24:
            st.warning("Select 24 tags or fewer for a readable interactive trend.")
        else:
            loaded: dict[str, tuple[pd.DataFrame, tuple[str, ...]]] = {}
            progress = st.progress(0, text="Reading the selected time window...")
            selected_items = list(selections.items())
            for index, (group_id, tags) in enumerate(selected_items, start=1):
                group = next(item for item in catalog.groups if item.group_id == group_id)
                frame = load_group_window(
                    catalog.source_path,
                    group_id,
                    tags,
                    start_utc.isoformat(),
                    end_utc.isoformat(),
                )
                loaded[group.display_name] = (frame, tags)
                progress.progress(
                    index / len(selected_items),
                    text=f"Loaded {group.display_name}",
                )
            progress.empty()
            event_utc = None
            if mark_event:
                event_utc = local_selection_to_utc(start_date, event_time, display_zone)
            figure = create_figure(
                loaded,
                plot_mode,
                timezone_mode,
                max_points,
                event_utc,
            )
            st.session_state.plot_result = {
                "data": loaded,
                "figure": figure,
                "start_utc": start_utc,
                "end_utc": end_utc,
            }

    result = st.session_state.get("plot_result")
    if not result:
        return

    empty_groups = [name for name, (frame, _) in result["data"].items() if frame.empty]
    if empty_groups:
        st.warning("No rows were found in the selected window for: " + ", ".join(empty_groups))
    st.plotly_chart(result["figure"], width="stretch", config={"scrollZoom": True})

    export_frames = {
        name: frame for name, (frame, _) in result["data"].items() if not frame.empty
    }
    if export_frames:
        download_columns = st.columns(2)
        filtered_zip = build_filtered_zip(
            export_frames,
            result["start_utc"],
            result["end_utc"],
        )
        download_columns[0].download_button(
            "Download filtered CSVs",
            data=filtered_zip,
            file_name="TwistingLogger-filtered-window.zip",
            mime="application/zip",
            width="stretch",
        )
        chart_html = result["figure"].to_html(include_plotlyjs=True, full_html=True)
        download_columns[1].download_button(
            "Download interactive chart",
            data=chart_html,
            file_name="TwistingLogger-trend.html",
            mime="text/html",
            width="stretch",
        )


if __name__ == "__main__":
    main()
