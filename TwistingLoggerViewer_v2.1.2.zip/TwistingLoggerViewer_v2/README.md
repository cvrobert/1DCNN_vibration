# TwistingLogger Viewer 2.1.2 — familiar workspaces

2.1.2 fixes Event A rendering wider than its column in exported comparisons. Export columns now have explicit widths and charts resize after loading. Download a NEW HTML export after updating; existing HTML files are not changed.

2.1.1 fixes clipped legend entries when many traces are selected. Legends now sit above the plots, with extra headroom for wrapped rows in single views, comparisons, and HTML exports.

## Update or install

Close the viewer console first.

If v2 is already installed: extract this ZIP, then copy the files INSIDE its TwistingLoggerViewer_v2 folder into your existing installed viewer folder. Replace matching files and KEEP the existing .venv folder. Run Start_Viewer.bat. No package reinstall is required.

For a fresh installation: extract to a new folder, run Install_Viewer.bat once with internet access, then run Start_Viewer.bat.

Keep the original v1 separately if desired. This app only reads exported CSVs; it does not change either Pi or PLC.

## Your normal workflow

1. Open the daily ZIP/CSV in Event A. Browse is available in the page as well as the launcher. A folder of CSVs also works.
2. Use the original date and time boxes to select the approximate event time. As in v1, the whole end second is included.
3. Pick tags from the Fast Dynamics / Process / Configuration group tabs (or your CSV's group name).
4. Choose Stacked historian tracks or Overlay all tags, then Plot selected tags.
5. Zoom to investigate. Click a legend entry to hide/show a trace; double-click it to isolate that trace. Add/remove tags in the picker and replot to change the selection.
6. When you recognize a possible earlier event, check Open a second event in the sidebar.
7. Event B has the SAME interface. Pick its ZIP, find its time, select its tags, and plot. Event A stays available.
8. Open Compare side by side. The two last-generated charts appear together, each retaining its own overlay/stacked choice.

You can choose the same file in A and B to compare two times from one day. Disable the second event to return to a single workspace; its settings are retained for the session.

## How to focus the comparison

Actual timestamps are the default and are all you need for ordinary browsing.

Browser zoom/pan is temporary. When you identify the important section, put its start/end times into the workspace's time boxes and replot. The Compare tab and downloaded HTML use those plotted windows, not a temporary mouse zoom.

The end second is inclusive: 12:00:00 through 12:00:14 covers 15 seconds of logging. Durations are shown to one decimal place.

The Compare tab has one collapsed Optional: compare timing and scales section:

- Actual time: Event A might show Monday 10:15 and Event B Tuesday 14:30. Each chart shows its own original times.
- Seconds from window start: each chosen window starts at zero. If both windows begin when the line starts, a change at +5 means five seconds after each run starts.
- Align event markers: in BOTH workspaces enable Add event-time marker, set the exact event date/time, and replot. Choose Align event markers in Compare. Both events now occur at zero, regardless of their dates. Negative seconds are before the marker and positive seconds are after it. For example, compare whether current starts rising 3 seconds before each dancer excursion.
- Use the same displayed time span: both charts show the same amount of time across their width, so a 15-second event isn't stretched to look like an 18-second event. Zoom is independent in this revision; it does not automatically move the other chart.
- Match vertical scales: matches identical PLC tags with identical unit labels. For different payoff numbers, enter the same manual limits in both workspaces. Overlay traces always share one axis.

## Optional labels, units, and scales

Open Optional: names, units, and vertical scales only when needed.
Known names/units are suggested. Original PLC tags remain visible. Unknown units remain blank.
Changing a unit label does not convert values. Payoff speed COMMAND is not actual motor speed feedback.

Stacked tracks can have separate Y limits. Overlays use one Y axis, just like v1: use identical manual limits across traces or leave all limits automatic. Use stacked tracks to compare unlike quantities without one large signal obscuring a small one.

## Comments and sharing

Under Optional: timestamped comments, add rows with:

Timestamp: 2026-10-01 19:09:38.700
Kind: Observation
Comment: Current begins rising here.

Use the selected timezone. Choose Assumption for interpretations (for example, suspected mechanical resistance). Replot to apply changes. Numbered chart markers identify notes; full notes are included in the HTML export.

Download interactive chart in a workspace exports that event.
Download side-by-side interactive comparison in Compare exports BOTH events, their notes, labels, units, and PLC tag references into one standalone HTML file.

Attach the actual HTML file to email. Recipients save it and open it in Edge or Chrome; they do not need Python or the viewer. Their email policy may restrict HTML attachments. Do not send a file:// link to your local Downloads folder.

Filtered CSV downloads contain all selected-window samples, without display decimation.

## Settings and limits

Save settings stores paths, selections, time windows, labels, and notes. Restore the JSON through the sidebar and plot again. Data files are not embedded. This simplified interface uses 2.1 settings; older 2.0 profiles are not compatible.

Reload clears cached reads after a ZIP is replaced with a newer export.
Normal use is offline; installation needs internet. The viewer cannot recreate unlogged data or infer unknown units.
Large windows may be downsampled for plotting; min/max sampling preserves peaks. Explicit missing values break lines. Missing timestamps without blank values may still be connected.
During the ambiguous fall daylight-saving hour, switch to UTC to select exact times.

Automated checks cover independent workspaces, adding/removing traces, overlays, optional comparisons, notes, exports, and settings behavior. Native Windows installation/file-picker behavior still requires checking on the target laptop.
