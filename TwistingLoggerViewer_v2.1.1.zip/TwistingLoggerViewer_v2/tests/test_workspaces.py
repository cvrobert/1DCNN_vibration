import unittest
from test_comparison import panel
from workspace_charts import figure_for,export_html,comparison_panels

class WorkspaceTests(unittest.TestCase):
    def data(self,pid="A",mode="Overlay all tags"):
        p=panel(pid)
        p.update(zone="America/New_York",plotmode=mode,points=5000)
        return p
    def test_overlay_legend_axis_and_export(self):
        a=self.data(); b=self.data("B","Stacked historian tracks")
        figs=[figure_for(p,"Actual time") for p in (a,b)]
        self.assertTrue(figs[0].layout.showlegend)
        self.assertEqual(figs[0].data[0].yaxis,"y")
        out=export_html([a,b],figs,"Two events")
        self.assertIn('display:flex',out)
        self.assertIn('&lt;script&gt;',out)
        self.assertNotIn('<script>alert(1)</script>',out)
        self.assertEqual(out.count('plotly.js v'),1)
    def test_optional_marker_and_y_matching(self):
        a=self.data(); b=self.data("B")
        a["event"]=None
        self.assertTrue(figure_for(a,"Actual time").data)
        b["signals"][0]["y"]*=4
        matched=comparison_panels([a,b],True)
        self.assertEqual(matched[0]["signals"][0]["max"],matched[1]["signals"][0]["max"])
        self.assertIsNone(a["signals"][0]["max"])
    def test_many_traces_use_top_legend_in_both_modes(self):
        for count in (7,12,24):
            for mode in ("Overlay all tags","Stacked historian tracks"):
                p=self.data(mode=mode)
                base=p["signals"][0]
                p["signals"]=[dict(base,tag=f"tag{i}",name=f"Payoff {i+1} Motor Current") for i in range(count)]
                f=figure_for(p,"Actual time")
                self.assertEqual(len(f.data),count)
                self.assertGreater(f.layout.legend.y,1)
                self.assertEqual(f.layout.legend.yanchor,"bottom")
                self.assertTrue(f.layout.margin.autoexpand)
                self.assertGreaterEqual(f.layout.margin.t,28*((count+1)//2)+120)
                self.assertEqual(len({t.name for t in f.data}),count)

if __name__=="__main__": unittest.main()
