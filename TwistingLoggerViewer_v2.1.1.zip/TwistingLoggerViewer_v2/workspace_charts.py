"""Independent charts and portable side-by-side HTML."""
import html
import hashlib
import plotly.graph_objects as go
from comparison import build_chart, finite_range, coordinate

def figure_for(panel,mode):
    fig=build_chart([panel],mode,panel["zone"],False,False,panel["points"],panel["title"])
    if panel["plotmode"]=="Overlay all tags":
        overlay=go.Figure()
        for trace in fig.data:
            trace=go.Scattergl(trace)
            trace.xaxis="x"; trace.yaxis="y"
            overlay.add_trace(trace)
        bounds={tuple((s["min"],s["max"])) for s in panel["signals"] if s["min"] is not None}
        if len(bounds)>1: raise ValueError("Overlay uses one Y axis. Give traces the same manual limits, or use stacked tracks.")
        units={s["unit"].strip() for s in panel["signals"] if s["unit"].strip()}
        overlay.update_layout(template="plotly_white",title=html.escape(panel["title"]),height=720,
            margin={"l":80,"r":25,"t":100,"b":70},hovermode="x unified",
            shapes=[s for s in fig.layout.shapes if s.xref=="x"],
            annotations=[a for a in fig.layout.annotations if a.xref=="x"])
        overlay.update_xaxes(range=[coordinate(panel["start"],panel,mode,panel["zone"]),coordinate(panel["end"],panel,mode,panel["zone"])],
            title_text=panel["zone"] if mode=="Actual time" else ("Seconds from event" if mode=="Aligned event" else "Seconds from window start"),
            rangeslider={"visible":True})
        overlay.update_yaxes(title_text=html.escape(next(iter(units))) if len(units)==1 else "Values — units shown in legend / hover",
                             range=next(iter(bounds)) if bounds else None)
        fig=overlay
    for trace,s in zip(fig.data,panel["signals"]):
        trace.name=html.escape(s["name"]+(" ["+s["unit"]+"]" if s["unit"] else ""))
    identity = str((panel["source"],panel["start"],panel["end"],panel["plotmode"],mode,
                    [(s["tag"],s["name"],s["unit"],s["min"],s["max"]) for s in panel["signals"]]))
    # Put the legend above the plotting area, away from the range slider.
    # Budget two entries per row; Plotly can expand the margin further for
    # longer labels. Increase total height to preserve the useful plot area.
    legend_space = 28 * ((len(fig.data) + 1) // 2) + 60
    old_top = fig.layout.margin.t or 100
    new_top = max(old_top, legend_space + 60)
    # The extra comparison header occupied the same area as the top legend.
    # The chart title and workspace/export headings already identify the event.
    fig.layout.annotations = tuple(a for a in fig.layout.annotations
        if not (a.xref == "paper" and a.yref == "paper" and a.yshift == 72))
    fig.update_layout(
        height=(fig.layout.height or 720) + new_top - old_top,
        margin={"t":new_top,"autoexpand":True},
        title={"y":0.99,"yanchor":"top","yref":"container"},
        showlegend=True,
        legend={"orientation":"h","y":1.08,"yanchor":"bottom","x":0,"xanchor":"left",
                "traceorder":"normal","font":{"size":12}},
                      uirevision=hashlib.sha256(identity.encode()).hexdigest())
    return fig

def comparison_panels(panels,match):
    # Copy metadata, not potentially huge dataframes/series.
    result=[dict(p,signals=[dict(s) for s in p["signals"]]) for p in panels]
    if not match: return result
    pooled={}
    for p in result:
        for s in p["signals"]:
            k=(s["tag"],s["unit"])
            values=s["y"].dropna()
            if not values.empty: pooled.setdefault(k,[]).extend([values.min(),values.max()])
    for p in result:
        if p["plotmode"]=="Overlay all tags":
            # A shared overlay axis must get one range for all selected tags.
            if any(s["min"] is not None for s in p["signals"]): continue
            values=[v for s in p["signals"] for v in pooled.get((s["tag"],s["unit"]),[])]
            limits=finite_range(values)
            for s in p["signals"]: s["min"],s["max"]=limits
        else:
            for s in p["signals"]:
                if s["min"] is None: s["min"],s["max"]=finite_range(pooled.get((s["tag"],s["unit"]),[]))
    return result

def export_html(panels,figures,title):
    charts=[]; details=[]
    for i,(p,fig) in enumerate(zip(panels,figures)):
        duration=(p["end"]-p["start"]).total_seconds()
        label=f'Event {p["id"]}: {html.escape(p["title"])}'
        span=f'{p["start"].tz_convert(p["zone"])} to {p["end"].tz_convert(p["zone"])}'
        charts.append(f'<section><h2>{label}</h2><p>{html.escape(span)}<br><b>{duration:.1f} seconds</b></p>'+fig.to_html(full_html=False,include_plotlyjs=True if i==0 else False,config={"responsive":True,"scrollZoom":True})+'</section>')
        notes="".join(f'<li><b>{p["id"]}{j}: {html.escape(n["kind"])}</b> — {html.escape(str(n["time"].tz_convert(p["zone"])))} — {html.escape(n["text"])}</li>' for j,n in enumerate(p["notes"],1))
        tags="".join("<tr>"+"".join(f"<td>{html.escape(str(s[k]))}</td>" for k in ("name","unit","tag"))+"</tr>" for s in p["signals"])
        details.append(f'<h2>{label}: notes and tag reference</h2><ul>{notes}</ul><table><tr><th>Name</th><th>Unit</th><th>PLC tag</th></tr>{tags}</table>')
    return '<!doctype html><html><head><meta charset="utf-8"><title>'+html.escape(title)+'</title><style>body{font:16px Arial;color:#183044;margin:20px}.charts{display:flex;gap:24px}.charts>section{flex:1;min-width:0}table{border-collapse:collapse}td,th{border:1px solid #ccd;padding:8px}li{margin:10px 0}@media(max-width:850px){.charts{display:block}}</style></head><body><h1>'+html.escape(title)+'</h1><p>Drag to zoom. Click legend entries to hide/show traces; double-click to isolate. Each plot zooms independently. Labels do not convert values. Data may be downsampled for display.</p><div class="charts">'+"".join(charts)+'</div>'+"".join(details)+'</body></html>'
