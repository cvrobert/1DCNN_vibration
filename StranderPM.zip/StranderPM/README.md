# Strander Predictive Maintenance

This project imports AVEVA Historian Excel/CSV exports and builds an incremental predictive-maintenance workflow for the strander.

## What it does

### Phase 1
- Imports the eight overall vibration RMS tags and actual speed
- Converts AVEVA long-format exports to wide format
- Resamples to one-second intervals
- Detects running periods
- Excludes startup and shutdown
- Builds five-minute condition-monitoring windows
- Learns expected vibration versus speed
- Detects two recurring operating regimes
- Trains one anomaly detector per regime
- Exports ranked anomaly windows and plots

### Phase 2
- Reads known failure events from `data/failures.csv`
- Labels the hours before each event
- Creates a signature for each historical failure

### Phase 3
- Scores current data using the saved Phase 1 baseline
- Compares current behavior with earlier failure signatures
- Exports similarity rankings, sensor status, plots, and a text report

---

# Windows Setup in VS Code

## 1. Extract the ZIP

Use a short folder path to avoid Windows path-length problems, for example:

```text
C:\SPM
```

## 2. Open the folder in VS Code

Select:

```text
File > Open Folder > C:\SPM
```

## 3. Open the terminal

Select:

```text
Terminal > New Terminal
```

## 4. Create the virtual environment

```powershell
py -m venv .venv
```

## 5. Activate it

```powershell
.\.venv\Scripts\Activate.ps1
```

If PowerShell activation is blocked by company policy, use Command Prompt in VS Code instead:

```cmd
.venv\Scripts\activate.bat
```

You can change the VS Code terminal from PowerShell to Command Prompt using the terminal dropdown.

## 6. Install only the required packages

```powershell
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

This project does not require Jupyter or JupyterLab.

## 7. Run the program

```powershell
python main.py
```

---

# First Test

Place the July 1 Excel export in:

```text
data\historical\
```

Then run:

```powershell
python main.py
```

Choose:

```text
1) Validate AVEVA historian import
```

Review:

```text
processed\import_validation_sample.csv
```

Confirm that it contains:

- Timestamp
- ActualSpeed
- LowerMotor
- UpperGearbox
- LowerGearbox
- MotorSideBearing
- MotorSideBase
- NonMotorBearing
- NonMotorBase
- UpperMotor

---

# Recommended Workflow

## Phase 1

1. Add mostly healthy Excel or CSV exports to `data/historical`.
2. Validate the import.
3. Add enough healthy operation for a useful baseline.
4. Choose menu option 2.
5. Review:
   - `outputs/phase1_historical_anomaly_plot.png`
   - `outputs/phase1_top_500_anomaly_windows.csv`
   - `processed/historical_window_scores.csv`

Do not repeatedly retrain the baseline using every new file. Retrain only after verifying that the added data represents healthy operation.

## Phase 2

Edit:

```text
data\failures.csv
```

Example:

```csv
failure_id,failure_time,failure_type,affected_area,description,time_accuracy
F001,2026-07-17 14:32:00,Bearing Failure,Motor-side bearing,Bearing replaced after drive fault,Exact
```

Then choose menu option 3.

## Phase 3

1. Remove old files from `data/current`.
2. Add the newest Excel or CSV export.
3. Choose menu option 4.
4. Review:
   - `outputs/current_summary_report.txt`
   - `outputs/current_anomaly_plot.png`
   - `outputs/current_sensor_status.csv`
   - `outputs/current_failure_similarity.csv`

---

# Important limitations

The historian stores one overall RMS value per second. This system can identify changes in vibration severity, trends, relationships, and resemblance to earlier failures. It cannot identify bearing defect frequencies or gear-mesh frequencies because the original high-frequency waveform is not available.

A similarity result should support an inspection decision. It is not proof that the same failure will occur.
