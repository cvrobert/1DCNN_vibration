import pandas as pd

from config import (
    FAILURE_FILE,
    PROCESSED_DIR,
    LOOKBACK_HOURS,
    RECENT_FAILURE_HOURS,
    VIBRATION_COLUMNS,
)
from src.phase1 import get_feature_lists

def load_failures() -> pd.DataFrame:
    if not FAILURE_FILE.exists():
        return pd.DataFrame()

    failures = pd.read_csv(FAILURE_FILE)
    if failures.empty:
        return failures

    failures["failure_time"] = pd.to_datetime(
        failures["failure_time"],
        errors="coerce",
    )

    return failures.dropna(subset=["failure_time"])

def label_pre_failure_windows(scored_windows: pd.DataFrame) -> pd.DataFrame:
    failures = load_failures()
    labeled = scored_windows.copy()

    labeled["failure_label"] = "normal"
    labeled["failure_id"] = pd.NA
    labeled["hours_to_failure"] = pd.NA

    for _, failure in failures.iterrows():
        failure_time = failure["failure_time"]

        mask = (
            (labeled["window_center"] >= failure_time - pd.Timedelta(hours=LOOKBACK_HOURS))
            & (labeled["window_center"] < failure_time)
        )

        labeled.loc[mask, "failure_label"] = failure["failure_type"]
        labeled.loc[mask, "failure_id"] = failure["failure_id"]
        labeled.loc[mask, "hours_to_failure"] = (
            failure_time - labeled.loc[mask, "window_center"]
        ).dt.total_seconds() / 3600

    return labeled

def build_failure_signatures(labeled_windows: pd.DataFrame) -> pd.DataFrame:
    failures = load_failures()
    if failures.empty:
        return pd.DataFrame()

    residual_columns, _, _ = get_feature_lists()

    pattern_features = (
        residual_columns
        + [
            "anomaly_score",
            "ratio_motor_top_bottom",
            "ratio_gearbox_top_bottom",
            "ratio_motor_bearing_to_base",
            "ratio_nonmotor_bearing_to_base",
            "ratio_motor_to_nonmotor_bearing",
            "bearing_minus_base",
            "gearbox_minus_motor",
        ]
        + [f"{sensor}_slope" for sensor in VIBRATION_COLUMNS]
        + [f"{sensor}_std" for sensor in VIBRATION_COLUMNS]
    )

    signatures = []

    for failure_id, group in labeled_windows.dropna(
        subset=["failure_id"]
    ).groupby("failure_id"):

        failure_row = failures[
            failures["failure_id"] == failure_id
        ].iloc[0]

        signature = {
            "failure_id": failure_id,
            "failure_type": failure_row["failure_type"],
            "affected_area": failure_row.get("affected_area", ""),
            "failure_time": failure_row["failure_time"],
            "window_count": len(group),
        }

        for column in pattern_features:
            signature[f"{column}__mean"] = group[column].mean()
            signature[f"{column}__max"] = group[column].max()
            signature[f"{column}__last6h"] = group.loc[
                group["hours_to_failure"].astype(float) <= RECENT_FAILURE_HOURS,
                column,
            ].mean()

        signatures.append(signature)

    result = pd.DataFrame(signatures)
    if not result.empty:
        result.to_csv(PROCESSED_DIR / "failure_signatures.csv", index=False)

    return result
