from pathlib import Path
import matplotlib.pyplot as plt
import pandas as pd

from config import OUTPUTS_DIR, VIBRATION_COLUMNS

def save_anomaly_plot(
    scored_windows: pd.DataFrame,
    filename: str,
    title: str,
) -> Path:
    path = OUTPUTS_DIR / filename

    plt.figure(figsize=(15, 5))
    plt.plot(
        scored_windows["window_center"],
        scored_windows["anomaly_score"],
        linewidth=0.8,
        label="Anomaly score",
    )

    abnormal = scored_windows[
        scored_windows.get("persistent_anomaly", False)
    ]

    if not abnormal.empty:
        plt.scatter(
            abnormal["window_center"],
            abnormal["anomaly_score"],
            s=25,
            label="Persistent anomaly",
        )

    plt.title(title)
    plt.xlabel("Time")
    plt.ylabel("Higher = more unusual")
    plt.legend()
    plt.tight_layout()
    plt.savefig(path, dpi=160)
    plt.close()

    return path

def create_sensor_status_table(scored_windows: pd.DataFrame) -> pd.DataFrame:
    rows = []

    for sensor in VIBRATION_COLUMNS:
        mean_col = f"{sensor}_mean"
        residual_col = f"{sensor}_speed_residual"

        rows.append({
            "sensor": sensor,
            "current_mean": scored_windows[mean_col].tail(5).mean(),
            "period_max": scored_windows[mean_col].max(),
            "mean_speed_adjusted_residual": scored_windows[residual_col].mean(),
            "recent_speed_adjusted_residual": scored_windows[residual_col].tail(5).mean(),
        })

    table = pd.DataFrame(rows).sort_values(
        "recent_speed_adjusted_residual",
        ascending=False,
    )

    table.to_csv(
        OUTPUTS_DIR / "current_sensor_status.csv",
        index=False,
    )

    return table

def create_text_report(
    scored_windows: pd.DataFrame,
    comparison: pd.DataFrame | None = None,
) -> Path:
    path = OUTPUTS_DIR / "current_summary_report.txt"

    lines = [
        "STRANDER PREDICTIVE MAINTENANCE REPORT",
        "=" * 45,
        "",
        f"Analysis start: {scored_windows['window_start'].min()}",
        f"Analysis end: {scored_windows['window_end'].max()}",
        f"Windows analyzed: {len(scored_windows):,}",
        f"Maximum anomaly score: {scored_windows['anomaly_score'].max():.6f}",
        f"Raw anomaly windows: {int(scored_windows['is_anomaly_raw'].sum())}",
        f"Persistent anomaly windows: {int(scored_windows['persistent_anomaly'].sum())}",
        f"Dominant regime: {scored_windows['detected_regime'].mode().iloc[0]}",
        f"Mean regime confidence: {scored_windows['regime_confidence'].mean():.3f}",
        "",
    ]

    if comparison is not None and not comparison.empty:
        top = comparison.iloc[0]
        lines.extend([
            "CLOSEST HISTORICAL FAILURE",
            "-" * 30,
            f"Failure ID: {top['failure_id']}",
            f"Failure type: {top['failure_type']}",
            f"Affected area: {top['affected_area']}",
            f"Failure time: {top['failure_time']}",
            f"Similarity score: {top['similarity']:.3f}",
            "",
            "Important: similarity supports inspection; it does not prove",
            "that the same failure will occur.",
        ])
    else:
        lines.extend([
            "No historical failure comparison was available.",
            "Phase 1 anomaly scoring was still completed.",
        ])

    path.write_text("\n".join(lines), encoding="utf-8")
    return path
