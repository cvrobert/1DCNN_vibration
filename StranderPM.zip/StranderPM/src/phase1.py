import joblib
import numpy as np
import pandas as pd

from sklearn.preprocessing import RobustScaler
from sklearn.ensemble import HistGradientBoostingRegressor, IsolationForest
from sklearn.mixture import GaussianMixture

from config import (
    MODELS_DIR,
    VIBRATION_COLUMNS,
    N_OPERATING_REGIMES,
    ISOLATION_CONTAMINATION,
    MIN_CONSECUTIVE_ANOMALOUS_WINDOWS,
    RANDOM_SEED,
)

SPEED_CONTEXT_COLUMNS = [
    "speed_mean",
    "speed_std",
    "speed_min",
    "speed_max",
    "speed_slope",
    "seconds_from_run_start",
]

def _base_regime_features(speed_residual_columns):
    return (
        speed_residual_columns
        + [f"{sensor}_share" for sensor in VIBRATION_COLUMNS]
        + [
            "ratio_motor_top_bottom",
            "ratio_gearbox_top_bottom",
            "ratio_motor_bearing_to_base",
            "ratio_nonmotor_bearing_to_base",
            "ratio_motor_to_nonmotor_bearing",
            "bearing_minus_base",
            "gearbox_minus_motor",
        ]
    )

def _anomaly_features(speed_residual_columns):
    return (
        SPEED_CONTEXT_COLUMNS
        + [
            f"{sensor}_{stat}"
            for sensor in VIBRATION_COLUMNS
            for stat in [
                "mean", "median", "std", "max",
                "range", "slope", "delta", "p90", "diff_std"
            ]
        ]
        + speed_residual_columns
        + [f"{sensor}_share" for sensor in VIBRATION_COLUMNS]
        + [
            "ratio_motor_top_bottom",
            "ratio_gearbox_top_bottom",
            "ratio_motor_bearing_to_base",
            "ratio_nonmotor_bearing_to_base",
            "ratio_motor_to_nonmotor_bearing",
            "motor_average",
            "gearbox_average",
            "bearing_average",
            "base_average",
            "bearing_minus_base",
            "gearbox_minus_motor",
        ]
    )

def train_phase1(windows: pd.DataFrame) -> pd.DataFrame:
    if windows.empty:
        raise ValueError("No feature windows available for training.")

    windows = windows.copy()
    speed_models = {}
    residual_columns = []

    for sensor in VIBRATION_COLUMNS:
        model = HistGradientBoostingRegressor(
            max_iter=300,
            learning_rate=0.05,
            max_leaf_nodes=20,
            l2_regularization=1.0,
            random_state=RANDOM_SEED,
        )

        target = f"{sensor}_mean"
        model.fit(windows[SPEED_CONTEXT_COLUMNS], windows[target])

        windows[f"{sensor}_expected"] = model.predict(
            windows[SPEED_CONTEXT_COLUMNS]
        )
        windows[f"{sensor}_speed_residual"] = (
            windows[target] - windows[f"{sensor}_expected"]
        )

        speed_models[sensor] = model
        residual_columns.append(f"{sensor}_speed_residual")

    regime_features = _base_regime_features(residual_columns)

    regime_scaler = RobustScaler()
    X_regime = regime_scaler.fit_transform(windows[regime_features])

    regime_model = GaussianMixture(
        n_components=N_OPERATING_REGIMES,
        covariance_type="full",
        n_init=20,
        random_state=RANDOM_SEED,
    )

    labels = regime_model.fit_predict(X_regime)
    windows["detected_regime"] = [f"regime_{label}" for label in labels]
    windows["regime_confidence"] = regime_model.predict_proba(X_regime).max(axis=1)

    anomaly_features = _anomaly_features(residual_columns)
    anomaly_assets = {}

    windows["anomaly_score"] = np.nan
    windows["is_anomaly_raw"] = False

    for regime, group in windows.groupby("detected_regime"):
        scaler = RobustScaler()
        X = scaler.fit_transform(group[anomaly_features])

        model = IsolationForest(
            n_estimators=500,
            contamination=ISOLATION_CONTAMINATION,
            random_state=RANDOM_SEED,
            n_jobs=-1,
        )
        model.fit(X)

        windows.loc[group.index, "anomaly_score"] = -model.score_samples(X)
        windows.loc[group.index, "is_anomaly_raw"] = model.predict(X) == -1

        anomaly_assets[regime] = {
            "scaler": scaler,
            "model": model,
        }

    assets = {
        "speed_models": speed_models,
        "regime_scaler": regime_scaler,
        "regime_model": regime_model,
        "anomaly_assets": anomaly_assets,
        "regime_features": regime_features,
        "anomaly_features": anomaly_features,
        "residual_columns": residual_columns,
    }

    joblib.dump(assets, MODELS_DIR / "phase1_assets.joblib")
    return apply_persistence(windows)

def score_phase1(windows: pd.DataFrame) -> pd.DataFrame:
    if windows.empty:
        return windows

    asset_path = MODELS_DIR / "phase1_assets.joblib"
    if not asset_path.exists():
        raise FileNotFoundError("Phase 1 model has not been trained yet.")

    assets = joblib.load(asset_path)
    windows = windows.copy()

    for sensor in VIBRATION_COLUMNS:
        target = f"{sensor}_mean"
        expected = assets["speed_models"][sensor].predict(
            windows[SPEED_CONTEXT_COLUMNS]
        )

        windows[f"{sensor}_expected"] = expected
        windows[f"{sensor}_speed_residual"] = windows[target] - expected

    X_regime = assets["regime_scaler"].transform(
        windows[assets["regime_features"]]
    )

    labels = assets["regime_model"].predict(X_regime)
    windows["detected_regime"] = [f"regime_{label}" for label in labels]
    windows["regime_confidence"] = (
        assets["regime_model"].predict_proba(X_regime).max(axis=1)
    )

    windows["anomaly_score"] = np.nan
    windows["is_anomaly_raw"] = False

    for regime, group in windows.groupby("detected_regime"):
        if regime not in assets["anomaly_assets"]:
            continue

        model_assets = assets["anomaly_assets"][regime]
        X = model_assets["scaler"].transform(
            group[assets["anomaly_features"]]
        )

        windows.loc[group.index, "anomaly_score"] = (
            -model_assets["model"].score_samples(X)
        )
        windows.loc[group.index, "is_anomaly_raw"] = (
            model_assets["model"].predict(X) == -1
        )

    return apply_persistence(windows)

def apply_persistence(windows: pd.DataFrame) -> pd.DataFrame:
    windows = windows.sort_values("window_center").reset_index(drop=True)
    windows["persistent_anomaly"] = False
    windows["anomaly_event_id"] = np.nan

    event_counter = 0

    for run_id, group in windows.groupby("run_id"):
        idx = list(group.index)
        flags = windows.loc[idx, "is_anomaly_raw"].to_numpy(dtype=bool)

        start = 0
        while start < len(flags):
            if not flags[start]:
                start += 1
                continue

            end = start + 1
            while end < len(flags) and flags[end]:
                end += 1

            if end - start >= MIN_CONSECUTIVE_ANOMALOUS_WINDOWS:
                event_counter += 1
                event_idx = idx[start:end]
                windows.loc[event_idx, "persistent_anomaly"] = True
                windows.loc[event_idx, "anomaly_event_id"] = event_counter

            start = end

    return windows

def get_feature_lists():
    assets = joblib.load(MODELS_DIR / "phase1_assets.joblib")
    return (
        assets["residual_columns"],
        assets["regime_features"],
        assets["anomaly_features"],
    )
