from pathlib import Path
import pandas as pd

from config import TAG_MAP

TIMESTAMP_CANDIDATES = [
    "DateTime", "Datetime", "Timestamp", "TimeStamp", "Time", "Date"
]

TAG_CANDIDATES = [
    "TagName", "Tag Name", "Tag", "Name"
]

VALUE_CANDIDATES = [
    "Value", "AnalogValue", "ProcessValue", "Val"
]

def _find_column(columns, candidates):
    normalized = {str(c).strip().lower(): c for c in columns}
    for candidate in candidates:
        match = normalized.get(candidate.lower())
        if match is not None:
            return match
    return None

def list_data_files(folder: Path):
    folder = Path(folder)
    files = []
    for pattern in ("*.xlsx", "*.xls", "*.csv"):
        files.extend(folder.glob(pattern))
    return sorted(set(files))

def read_export_file(file_path: Path) -> pd.DataFrame:
    file_path = Path(file_path)

    if file_path.suffix.lower() in (".xlsx", ".xls"):
        raw = pd.read_excel(file_path)
    elif file_path.suffix.lower() == ".csv":
        raw = pd.read_csv(file_path)
    else:
        raise ValueError(f"Unsupported file type: {file_path.suffix}")

    if raw.empty:
        raise ValueError("File is empty.")

    timestamp_col = _find_column(raw.columns, TIMESTAMP_CANDIDATES)
    tag_col = _find_column(raw.columns, TAG_CANDIDATES)
    value_col = _find_column(raw.columns, VALUE_CANDIDATES)

    # AVEVA fallback: first three columns are timestamp, tag, and value.
    if timestamp_col is None and len(raw.columns) >= 1:
        timestamp_col = raw.columns[0]
    if tag_col is None and len(raw.columns) >= 2:
        tag_col = raw.columns[1]
    if value_col is None and len(raw.columns) >= 3:
        value_col = raw.columns[2]

    subset = raw[[timestamp_col, tag_col, value_col]].copy()
    subset.columns = ["Timestamp", "TagName", "Value"]

    subset["Timestamp"] = pd.to_datetime(subset["Timestamp"].astype(str).str.strip(), format = "mixed", errors="coerce")
    subset["TagName"] = subset["TagName"].astype(str).str.strip()
    subset["Value"] = pd.to_numeric(subset["Value"], errors="coerce")

    subset = subset.dropna(subset=["Timestamp", "TagName", "Value"])
    subset = subset[subset["TagName"].isin(TAG_MAP.keys())].copy()

    if subset.empty:
        raise ValueError(
            "No configured strander tags were found. "
            "Check config.py and the export column order."
        )

    subset["ModelColumn"] = subset["TagName"].map(TAG_MAP)
    subset["SourceFile"] = file_path.name
    return subset

def import_folder(folder: Path) -> pd.DataFrame:
    files = list_data_files(folder)
    if not files:
        return pd.DataFrame()

    pieces = []
    for file_path in files:
        try:
            part = read_export_file(file_path)
            pieces.append(part)
            print(f"Imported {file_path.name}: {len(part):,} usable rows")
        except Exception as exc:
            print(f"FAILED {file_path.name}: {exc}")

    if not pieces:
        return pd.DataFrame()

    combined = pd.concat(pieces, ignore_index=True)
    return combined.sort_values(["Timestamp", "ModelColumn"])

def long_to_wide(long_df: pd.DataFrame, speed_column: str, vibration_columns: list[str]) -> pd.DataFrame:
    if long_df.empty:
        return pd.DataFrame()

    clean = (
        long_df.sort_values(["Timestamp", "ModelColumn", "SourceFile"])
        .drop_duplicates(subset=["Timestamp", "ModelColumn"], keep="last")
    )

    wide = clean.pivot(
        index="Timestamp",
        columns="ModelColumn",
        values="Value",
    ).sort_index()

    wide.columns.name = None
    wide = wide.reset_index()

    for column in [speed_column, *vibration_columns]:
        if column not in wide.columns:
            wide[column] = pd.NA

    return wide[["Timestamp", speed_column, *vibration_columns]]
