import numpy as np
import pandas as pd

from sklearn.preprocessing import StandardScaler
from sklearn.metrics.pairwise import cosine_similarity

from config import PROCESSED_DIR, OUTPUTS_DIR, RECENT_FAILURE_HOURS

def compare_current_to_failures(
    current_scored: pd.DataFrame,
    failure_signatures: pd.DataFrame,
) -> pd.DataFrame:
    if current_scored.empty:
        raise ValueError("No current scored windows are available.")

    if failure_signatures.empty:
        raise ValueError("No historical failure signatures are available.")

    signature_columns = [
        c for c in failure_signatures.columns
        if c.endswith("__mean") or c.endswith("__max") or c.endswith("__last6h")
    ]

    current_signature = {}

    recent_cutoff = (
        current_scored["window_center"].max()
        - pd.Timedelta(hours=RECENT_FAILURE_HOURS)
    )

    recent = current_scored[
        current_scored["window_center"] >= recent_cutoff
    ]

    for feature_column in signature_columns:
        source_column, aggregation = feature_column.rsplit("__", 1)

        if source_column not in current_scored.columns:
            current_signature[feature_column] = np.nan
            continue

        if aggregation == "mean":
            current_signature[feature_column] = current_scored[source_column].mean()
        elif aggregation == "max":
            current_signature[feature_column] = current_scored[source_column].max()
        elif aggregation == "last6h":
            current_signature[feature_column] = recent[source_column].mean()

    reference = failure_signatures[signature_columns].copy()
    reference = reference.fillna(reference.median(numeric_only=True)).fillna(0)

    current_vector = pd.Series(current_signature)[signature_columns]
    current_vector = current_vector.fillna(0).to_numpy().reshape(1, -1)

    scaler = StandardScaler()
    reference_scaled = scaler.fit_transform(reference)
    current_scaled = scaler.transform(current_vector)

    similarities = cosine_similarity(
        current_scaled,
        reference_scaled,
    ).flatten()

    comparison = failure_signatures[
        [
            "failure_id",
            "failure_type",
            "affected_area",
            "failure_time",
            "window_count",
        ]
    ].copy()

    comparison["similarity"] = similarities
    comparison = comparison.sort_values("similarity", ascending=False)

    comparison.to_csv(
        OUTPUTS_DIR / "current_failure_similarity.csv",
        index=False,
    )

    return comparison
