from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent

DATA_DIR = PROJECT_ROOT / "data"
HISTORICAL_DATA_DIR = DATA_DIR / "historical"
CURRENT_DATA_DIR = DATA_DIR / "current"
FAILURE_FILE = DATA_DIR / "failures.csv"

PROCESSED_DIR = PROJECT_ROOT / "processed"
MODELS_DIR = PROJECT_ROOT / "models"
OUTPUTS_DIR = PROJECT_ROOT / "outputs"

TAG_MAP = {
    "A31A31DYNLeftCh0Overall": "LowerMotor",
    "A31A31DYNLeftCh1Overall": "UpperGearbox",
    "A31A31DYNLeftCh2Overall": "LowerGearbox",
    "A31A31DYNLeftCh3Overall": "MotorSideBearing",
    "A31A31DYNRightCh0Overall": "MotorSideBase",
    "A31A31DYNRightCh1Overall": "NonMotorBearing",
    "A31A31DYNRightCh2Overall": "NonMotorBase",
    "A31A31DYNRightCh3Overall": "UpperMotor",
    "A31Cps_ActSpd": "ActualSpeed",
}

VIBRATION_COLUMNS = [
    "LowerMotor",
    "UpperGearbox",
    "LowerGearbox",
    "MotorSideBearing",
    "MotorSideBase",
    "NonMotorBearing",
    "NonMotorBase",
    "UpperMotor",
]

SPEED_COLUMN = "ActualSpeed"

RUNNING_SPEED_THRESHOLD = 5.0
STARTUP_EXCLUSION_SECONDS = 120
SHUTDOWN_EXCLUSION_SECONDS = 120

WINDOW_SECONDS = 300
WINDOW_STEP_SECONDS = 60
MIN_WINDOW_COMPLETENESS = 0.90
MAX_INTERNAL_GAP_SECONDS = 5

N_OPERATING_REGIMES = 2
ISOLATION_CONTAMINATION = 0.005
MIN_CONSECUTIVE_ANOMALOUS_WINDOWS = 3

RANDOM_SEED = 42

LOOKBACK_HOURS = 72
RECENT_FAILURE_HOURS = 6
