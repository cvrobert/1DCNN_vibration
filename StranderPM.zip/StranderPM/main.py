from pathlib import Path
import sys
import pandas as pd

from config import (
    HISTORICAL_DATA_DIR,
    CURRENT_DATA_DIR,
    PROCESSED_DIR,
    OUTPUTS_DIR,
    SPEED_COLUMN,
    VIBRATION_COLUMNS,
)
from src.utils import ensure_project_folders, print_banner
from src.import_data import import_folder, long_to_wide
from src.preprocess import clean_and_resample, identify_runs
from src.features import build_windows
from src.phase1 import train_phase1, score_phase1
from src.phase2 import label_pre_failure_windows, build_failure_signatures
from src.phase3 import compare_current_to_failures
from src.visualize import (
    save_anomaly_plot,
    create_sensor_status_table,
    create_text_report,
)


def prepare_folder(folder: Path) -> pd.DataFrame:
    long_df = import_folder(folder)
    if long_df.empty:
        raise ValueError(f"No usable files were found in {folder.resolve()}")

    wide = long_to_wide(long_df, SPEED_COLUMN, VIBRATION_COLUMNS)
    clean = clean_and_resample(wide)
    runs = identify_runs(clean)
    windows = build_windows(runs)

    if windows.empty:
        raise ValueError(
            "No valid steady-running windows were produced. "
            "Check the data, speed threshold, and run duration."
        )

    return windows

def validate_import() -> None:
    print_banner("VALIDATE HISTORIAN IMPORT")

    long_df = import_folder(HISTORICAL_DATA_DIR)
    if long_df.empty:
        print("No usable files found.")
        print("Place Excel or CSV exports in data/historical.")
        return

    wide = long_to_wide(long_df, SPEED_COLUMN, VIBRATION_COLUMNS)

    print("\nDate range:")
    print(wide["Timestamp"].min(), "to", wide["Timestamp"].max())

    print("\nRows by model column:")
    print(long_df["ModelColumn"].value_counts())

    print("\nMissing values after pivot:")
    print(wide.isna().sum())

    sample_path = PROCESSED_DIR / "import_validation_sample.csv"
    wide.head(5000).to_csv(sample_path, index=False)

    print(f"\nSaved validation sample to:\n{sample_path.resolve()}")

def train_normal_baseline() -> None:
    print_banner("PHASE 1 — TRAIN NORMAL BASELINE")

    windows = prepare_folder(HISTORICAL_DATA_DIR)
    scored = train_phase1(windows)

    scored.to_csv(
        PROCESSED_DIR / "historical_window_scores.csv",
        index=False,
    )

    scored.sort_values(
        "anomaly_score",
        ascending=False,
    ).head(500).to_csv(
        OUTPUTS_DIR / "phase1_top_500_anomaly_windows.csv",
        index=False,
    )

    plot_path = save_anomaly_plot(
        scored,
        "phase1_historical_anomaly_plot.png",
        "Historical Strander Anomaly Score",
    )

    print(f"Feature windows: {len(scored):,}")
    print(f"Persistent anomaly windows: {int(scored['persistent_anomaly'].sum())}")
    print(f"Saved model and outputs.")
    print(f"Plot: {plot_path.resolve()}")

def build_failure_patterns() -> None:
    print_banner("PHASE 2 — BUILD FAILURE PATTERNS")

    scored_path = PROCESSED_DIR / "historical_window_scores.csv"
    if not scored_path.exists():
        raise FileNotFoundError(
            "Run Phase 1 first. historical_window_scores.csv does not exist."
        )

    scored = pd.read_csv(
        scored_path,
        parse_dates=["window_start", "window_end", "window_center"],
    )

    labeled = label_pre_failure_windows(scored)
    labeled.to_csv(
        PROCESSED_DIR / "historical_labeled_windows.csv",
        index=False,
    )

    signatures = build_failure_signatures(labeled)

    if signatures.empty:
        print("No usable failures were found.")
        print("Add events to data/failures.csv, then run Phase 2 again.")
    else:
        print(f"Built {len(signatures)} failure signatures.")
        print(signatures[
            ["failure_id", "failure_type", "affected_area", "window_count"]
        ])

def analyze_current_data() -> None:
    print_banner("PHASE 3 — ANALYZE CURRENT DATA")

    windows = prepare_folder(CURRENT_DATA_DIR)
    scored = score_phase1(windows)

    scored.to_csv(
        OUTPUTS_DIR / "current_scored_windows.csv",
        index=False,
    )

    plot_path = save_anomaly_plot(
        scored,
        "current_anomaly_plot.png",
        "Current Strander Anomaly Score",
    )

    sensor_table = create_sensor_status_table(scored)
    print("\nMost elevated current sensor residuals:")
    print(sensor_table.head(8).to_string(index=False))

    signatures_path = PROCESSED_DIR / "failure_signatures.csv"
    comparison = None

    if signatures_path.exists():
        signatures = pd.read_csv(
            signatures_path,
            parse_dates=["failure_time"],
        )

        if not signatures.empty:
            comparison = compare_current_to_failures(scored, signatures)
            print("\nClosest historical failures:")
            print(comparison.head(5).to_string(index=False))
    else:
        print("\nNo failure signatures found. Phase 1 scoring was still completed.")

    report_path = create_text_report(scored, comparison)

    print(f"\nPlot: {plot_path.resolve()}")
    print(f"Report: {report_path.resolve()}")
    print(f"Scored data: {(OUTPUTS_DIR / 'current_scored_windows.csv').resolve()}")

def show_menu() -> None:
    ensure_project_folders()

    while True:
        print_banner("STRANDER PREDICTIVE MAINTENANCE")
        print("1) Validate AVEVA historian import")
        print("2) Train Phase 1 normal baseline")
        print("3) Build Phase 2 failure patterns")
        print("4) Analyze current data / Phase 3")
        print("5) Show project folder locations")
        print("6) Exit")

        choice = input("\nSelection: ").strip()

        try:
            if choice == "1":
                validate_import()
            elif choice == "2":
                train_normal_baseline()
            elif choice == "3":
                build_failure_patterns()
            elif choice == "4":
                analyze_current_data()
            elif choice == "5":
                print(f"Historical files: {HISTORICAL_DATA_DIR.resolve()}")
                print(f"Current files: {CURRENT_DATA_DIR.resolve()}")
                print(f"Processed data: {PROCESSED_DIR.resolve()}")
                print(f"Outputs: {OUTPUTS_DIR.resolve()}")
            elif choice == "6":
                print("Exiting.")
                break
            else:
                print("Enter a number from 1 through 6.")
        except Exception as exc:
            print(f"\nERROR: {exc}")

        input("\nPress Enter to return to the menu...")

if __name__ == "__main__":
    show_menu()
