"""Comparison model, metadata and portable chart export (no Streamlit dependency)."""
import html
import json
import re
import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from viewer_core import minmax_decimate

COLORS = ["#087e8b", "#c74516", "#7053b7", "#167a42", "#bd3264", "#87651a"]

def defaults(tag):
    """Only assign units supported by known tag descriptions."""
    m = re.fullmatch(r"TPTO02_MTR_PO\[(\d+)\]\.f_Ampere", tag)
    if m:
        return f"Payoff {int(m[1])+1} Motor Current", "A"
    for pattern, label, unit in [
        (r"GPO_f_DNCR_Spd_as\[(\d+)\]", "Speed Command", ""),
        (r"TPTO02_f_PO_BBN_DIA_me\[(\d+)\]", "Bobbin Diameter", "mm"),
        (r"TPTO02_f_DncrPstn_PO_me\[(\d+)\]", "Dancer Position", ""),
    ]:
        m = re.fullmatch(pattern, tag)
        if m:
            return f"Payoff {int(m[1])+1} {label}", unit
    known = {"TPTO02_f_LineSpd_me": ("Line Speed", "m/min"),
             "GCAP_f_Spd_as": ("Line Speed Reference", "m/min")}
    return known.get(tag, (tag, ""))

def timestamp(text, zone):
    value = pd.Timestamp(text)
    if pd.isna(value):
        raise ValueError("A timestamp is required.")
    return value.tz_localize(zone, ambiguous="raise", nonexistent="raise").tz_convert("UTC") if value.tzinfo is None else value.tz_convert("UTC")

def coordinate(ts, panel, mode, zone):
    if mode == "Actual time":
        # Local wall-clock labels with explicit zone; raw UTC retained in hover.
        return ts.tz_convert(zone).tz_localize(None)
    origin = panel["event"] if mode == "Aligned event" else panel["start"]
    return (ts - origin).total_seconds()

def finite_range(values):
    a = np.asarray(values, dtype=float)
    a = a[np.isfinite(a)]
    if not len(a):
        return [0, 1]
    lo, hi = float(a.min()), float(a.max())
    pad = (hi-lo)*.05 if hi != lo else max(abs(lo)*.05, .5)
    return [lo-pad, hi+pad]

def build_chart(panels, mode, zone, link_time, match_values, max_points, title):
    rows = max(len(p["signals"]) for p in panels)
    cols = len(panels)
    titles = []
    for row in range(rows):
        for p in panels:
            s = p["signals"][row] if row < len(p["signals"]) else None
            titles.append(html.escape(s["name"]) if s else "")
    fig = make_subplots(rows=rows, cols=cols, shared_xaxes="columns",
                        horizontal_spacing=.12 if cols == 2 else .02,
                        vertical_spacing=min(.06, .22/rows), subplot_titles=titles)
    pooled = {}
    for p in panels:
        for s in p["signals"]:
            if s["match"].strip():
                key = (s["match"].strip(), s["unit"].strip())
                pooled.setdefault(key, []).extend(s["y"].dropna().tolist())
    for col, p in enumerate(panels, 1):
        for row, s in enumerate(p["signals"], 1):
            x = pd.Series([coordinate(t, p, mode, zone) for t in s["t"]])
            # Preserve missing-data breaks: decimate each valid segment separately.
            y = s["y"].reset_index(drop=True)
            groups = y.isna().cumsum()
            xp, yp, raw = [], [], []
            for _, segment in pd.DataFrame({"x": x, "y": y, "raw": s["t"].reset_index(drop=True)}).groupby(groups):
                segment = segment.dropna(subset=["y"])
                if segment.empty:
                    continue
                budget = max(4, int(max_points * len(segment)/max(1,len(y))))
                xx, yy = minmax_decimate(segment.x, segment.y, budget)
                xp.extend(xx.tolist()+[None]); yp.extend(yy.tolist()+[None])
                raw.extend([str(t) for t in segment.loc[xx.index, "raw"]]+[""])
            unit = s["unit"].strip() or "unit unspecified"
            fig.add_trace(go.Scattergl(x=xp, y=yp, customdata=raw, mode="lines",
                name=f'{p["id"]}: {s["name"]}', connectgaps=False,
                line={"color": COLORS[(row-1)%len(COLORS)], "width":1.7},
                hovertemplate="%{x}<br>%{y} "+html.escape(unit)+"<br>%{customdata}<extra>"+html.escape(s["tag"])+"</extra>"),
                row=row, col=col)
            bounds = None
            if s["min"] is not None and s["max"] is not None:
                bounds = [s["min"], s["max"]]
            elif match_values and s["match"].strip():
                bounds = finite_range(pooled[(s["match"].strip(), s["unit"].strip())])
            fig.update_yaxes(title_text=html.escape(unit), range=bounds, row=row, col=col)
            fig.update_xaxes(range=[coordinate(p["start"],p,mode,zone),coordinate(p["end"],p,mode,zone)],
                title_text=(zone if mode == "Actual time" else "Seconds from "+("event" if mode == "Aligned event" else "window start")) if row==len(p["signals"]) else None,
                row=row,col=col)
            if p["start"] <= p["event"] <= p["end"]:
                event_x = coordinate(p["event"],p,mode,zone)
                fig.add_shape(type="line",x0=event_x,x1=event_x,y0=0,y1=1,yref="y domain",
                              line={"color":"#456","dash":"dash"},row=row,col=col)
                if row == 1:
                    fig.add_annotation(x=event_x,y=1,yref="y domain",text="Event",
                                       showarrow=False,yshift=28,row=row,col=col)
            for n, note in enumerate(p["notes"],1):
                if not p["start"] <= note["time"] <= p["end"]:
                    continue
                xx = coordinate(note["time"],p,mode,zone)
                fig.add_shape(type="line",x0=xx,x1=xx,y0=0,y1=1,yref="y domain",
                              line={"color":"#b34242","dash":"dot"},row=row,col=col)
                if row==1:
                    fig.add_annotation(x=xx,y=1,yref="y domain",text=f'{p["id"]}{n}',
                                       showarrow=False,yshift=12,row=row,col=col)
    if link_time and cols == 2:
        if mode == "Actual time":
            # Equal durations while keeping independent dates/origins.
            duration = max((p["end"]-p["start"]).total_seconds() for p in panels)
            for col,p in enumerate(panels,1):
                start = coordinate(p["start"],p,mode,zone)
                fig.update_xaxes(range=[start,start+pd.Timedelta(seconds=duration)],col=col)
        else:
            lo = min(coordinate(p["start"],p,mode,zone) for p in panels)
            hi = max(coordinate(p["end"],p,mode,zone) for p in panels)
            fig.update_xaxes(range=[lo,hi],matches="x")
    for col,p in enumerate(panels,1):
        center = .5 if cols == 1 else (.22 if col == 1 else .78)
        duration = (p["end"]-p["start"]).total_seconds()
        fig.add_annotation(x=center,y=1,xref="paper",yref="paper",yshift=72,showarrow=False,
                           text=f'<b>Chart {p["id"]}: {html.escape(p["title"])}</b><br>{duration:g} seconds',
                           font={"size":14})
    fig.update_layout(title=html.escape(title),template="plotly_white",height=max(580,rows*240+80),
                      showlegend=False,hovermode="closest",margin={"t":145,"b":65,"l":70,"r":35})
    return fig

def report_html(fig, panels, title):
    details = []
    for p in panels:
        duration = (p["end"]-p["start"]).total_seconds()
        notes = "".join(f'<li><b>{p["id"]}{i} — {html.escape(n["kind"])}</b> at {html.escape(str(n["time"]))}: {html.escape(n["text"])}</li>' for i,n in enumerate(p["notes"],1))
        signals = "".join("<tr>"+"".join(f"<td>{html.escape(str(s[k]))}</td>" for k in ("name","unit","tag"))+"</tr>" for s in p["signals"])
        details.append(f'<section><h2>Chart {p["id"]}: {html.escape(p["title"])}</h2><p>{html.escape(p["source"])}<br>{p["start"]} to {p["end"]} (UTC) — <b>{duration:g} seconds</b></p><ol>{notes}</ol><table><tr><th>Display name</th><th>Units</th><th>PLC tag</th></tr>{signals}</table></section>')
    chart = fig.to_html(full_html=False,include_plotlyjs=True,config={"scrollZoom":True,"responsive":True})
    return '<!doctype html><html><head><meta charset="utf-8"><title>'+html.escape(title)+'</title><style>body{font:16px Arial;margin:24px;color:#152a3a}table{border-collapse:collapse}td,th{border:1px solid #ccd;padding:8px;text-align:left}section{margin:24px 0}li{margin:10px 0}</style></head><body><h1>'+html.escape(title)+'</h1><p>Interactive snapshot. Drag to zoom; double-click to reset. Units and names are labels only. Time windows are inclusive at the exact entered timestamps. Empty units are unverified. Plot may be decimated; CSV export retains selected samples.</p>'+chart+"".join(details)+'</body></html>'

def validate_profile(obj):
    if not isinstance(obj,dict) or obj.get("version") != 2 or not isinstance(obj.get("settings"),dict):
        raise ValueError("Select a v2 viewer settings JSON file.")
    settings = obj["settings"]
    if any(not isinstance(k,str) or not k.startswith(("A_","B_","global_")) for k in settings):
        raise ValueError("Settings file contains unsupported keys.")
    return settings
