# TwistingLogger Viewer v2

Compare two historian events from different ZIPs, CSVs, or folders. Runs locally on Windows; no AI account, API key, Pi changes, or PLC changes are required. Input files are read only.

## Install and open

1. Extract this entire ZIP into a new folder (keep v1 separately).
2. Run Install_Viewer.bat once with internet access. Python 3.11 or newer is required, as in v1.
3. Run Start_Viewer.bat. Choose the first logger ZIP in the file picker.
4. Your browser opens the local viewer. For Chart B, click Browse for B or paste the second ZIP's full path. You can choose the same ZIP twice to compare different events.
5. Leave the launcher console open while using the viewer. Close it when finished.

The first install needs internet to obtain Python packages. Normal viewing and HTML exports work offline.

## Select windows and signals

- Select Eastern time (America/New_York, with daylight saving) or UTC in the sidebar.
- Enter each chart's start/end as YYYY-MM-DD HH:MM:SS.sss. Example: 2026-10-01 19:09:30.000 to 2026-10-01 19:09:48.000 is exactly 18 seconds.
- Endpoints are inclusive at the exact timestamp entered. To include every sample within second 48, enter 19:09:48.999999.
- Select any tags from any sampling group. Selection order is the vertical track order, up to 16 tracks per chart. Disable Chart B for a single chart.
- Open each tag's settings to edit its display name, units, and Y limits. Both Y limits must be filled, or both blank.
- Labels do not convert values. Unknown units remain blank. Dancer position units and payoff command units are deliberately unverified. Speed command is not actual speed feedback.
- Known payoff array indexes are displayed as index + 1 (index 2 = Payoff 3). Original PLC tags remain visible in the controls, hover, and exported reference table.
- Click Build / update comparison after edits. The built result stays visible until rebuilt.

## Compare time and value scales

- Actual time: show each event's original date/time. Chart A and B zoom independently.
- Elapsed seconds: the start of each selected window is zero.
- Aligned event: enter a separate event reference timestamp for each chart. That timestamp is zero; preceding samples have negative seconds.
- Equal time scales OFF: each chart fills its own available width. Duration labels make a 15-second window distinct from an 18-second window.
- Equal time scales ON in either seconds mode: both charts use a common range, and horizontal zoom is linked. Shorter windows have empty space rather than stretched data.
- Equal time scales ON in actual-time mode: both initially show the longer duration while retaining their separate dates. Interactive zoom remains independent in this mode.
- Tracks within each chart share the horizontal axis.
- Match Y scales by key + units: signals with the same matching key and identical unit text share an automatic range. For example, give PO3 and PO5 current the key "Payoff current" and units "A". Different units are never automatically matched. Manual limits override this option; enter identical limits in both charts if desired.

## Add observations and assumptions

Expand Timestamped observations and assumptions under either chart. Add rows to the table:

Timestamp: 2026-10-01 19:09:38.700
Kind: Observation
Comment: Current rises before the command begins increasing.

Use the selected timezone. Choose Assumption for an interpretation, such as suspected mechanical resistance. Build / update comparison to apply changes. Markers A1, A2, B1, etc. identify notes, with full text below the chart. Out-of-window notes remain listed but are not marked on the plot.

## Save, export, and email

- Save settings downloads a JSON file containing paths, selected tags, labels, units, windows, scales, and notes. Load it and click Apply saved settings to restore. Source data are not included; update paths if moving computers.
- Download interactive comparison creates a standalone HTML file with both charts, embedded Plotly, notes, duration summaries, and the PLC tag reference. Attach the actual HTML file to email, not its file:// link. The recipient saves it and opens it in Edge or Chrome. Their email/security policy may restrict HTML attachments.
- Download selected-window CSVs creates a ZIP containing A/ and B/ folders and timestamps in UTC. These contain the selected numeric/bool samples without display downsampling.
- Exports use the last built snapshot and configured limits. Browser-only zoom/pan is not captured. Set exact window fields and Y limits, then rebuild before exporting a specific view.
- Refresh source files clears cached reads after replacing an early-export ZIP with a newer one.

## Limits and data interpretation

This viewer cannot recover unlogged actual speeds, infer unknown physical units, or establish causation from trends. Missing numeric values break the line rather than being interpolated. Large windows use min/max decimation to keep peaks visible; exported selected-window CSVs retain the selected samples. Missing timestamps without explicit blank values may still be connected. Large full-day windows across many tags require more memory; start with a few minutes.

Ambiguous local times during the fall daylight-saving transition are rejected. Switch to UTC to select those events precisely.

Validated with automated reader, axis, annotation, export, profile, and Streamlit interface tests. Native Windows file-picker and installation behavior require confirmation on the target laptop.
