"""Local, read-only, two-window historian comparison."""
import argparse
import io
import json
import subprocess
import sys
import zipfile
from pathlib import Path
import pandas as pd
import streamlit as st
from viewer_core import catalog_source, materialize_group, scan_catalog_time_range, read_time_window
from comparison import defaults, timestamp, build_chart, report_html, validate_profile

st.set_page_config(page_title="TwistingLogger Viewer v2",page_icon="📈",layout="wide")

@st.cache_data(show_spinner=False)
def inspect_source(source, stamp):
    catalog = catalog_source(source)
    return catalog, scan_catalog_time_range(catalog)

@st.cache_data(show_spinner=False, max_entries=24)
def window(csv, stamp, tags, start, end):
    return read_time_window(Path(csv),tags,pd.Timestamp(start),pd.Timestamp(end)).sort_values("timestamp_utc").reset_index(drop=True)

def signature(source):
    path = Path(source.strip().strip('"')).expanduser()
    if path.is_dir():
        return tuple((str(p),p.stat().st_size,p.stat().st_mtime_ns) for p in sorted(path.glob("*.csv")))
    stat = path.stat()
    return (stat.st_size,stat.st_mtime_ns)

def config(key, default):
    if key not in st.session_state:
        st.session_state[key] = default
    return st.session_state[key]

def text(label,key,default="",**kwargs):
    config(key,default)
    return st.text_input(label,key=key,**kwargs)

def panel_controls(pid,zone):
    st.subheader("Chart "+pid)
    source = text("ZIP, CSV, or CSV folder",pid+"_source")
    if st.button("Browse for "+pid):
        try:
            r = subprocess.run([sys.executable,str(Path(__file__).with_name("pick_file.py"))],
                               capture_output=True,text=True,check=True)
            if r.stdout.strip():
                st.session_state["pending_source"] = (pid,r.stdout.strip())
                st.rerun()
        except (OSError,subprocess.CalledProcessError):
            st.error("File picker unavailable. Paste the full file path above.")
    if not source:
        st.info("Choose a source to configure this chart.")
        return None
    try:
        cat,(first,last) = inspect_source(source,signature(source))
    except Exception as exc:
        st.error(str(exc))
        return None
    st.caption(f"Available: {first.tz_convert(zone)} through {last.tz_convert(zone)}")
    # Reset source-dependent selections on a change, but retain edited tag metadata.
    identity = str(cat.source_path)+"|"+zone
    if st.session_state.get(pid+"_identity") != identity:
        for suffix in ("start","end","event","tags"):
            st.session_state.pop(pid+"_"+suffix,None)
        st.session_state[pid+"_identity"] = identity
    title = text("Chart title",pid+"_title","Event "+pid)
    start_default = max(first,last-pd.Timedelta(minutes=1)).tz_convert(zone).strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
    end_default = last.tz_convert(zone).strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
    start = text("Start (YYYY-MM-DD HH:MM:SS.sss)",pid+"_start",start_default)
    end = text("End (exact timestamp, inclusive)",pid+"_end",end_default)
    event = text("Event reference (zero in aligned mode)",pid+"_event",start)
    try:
        start,end,event = [timestamp(t,zone) for t in (start,end,event)]
        if end <= start:
            raise ValueError("End must be later than start.")
    except Exception as exc:
        st.error(str(exc))
        return None
    st.write(f"**Selected duration: {(end-start).total_seconds():g} seconds**")
    choices = {g.group_id+"::"+tag:(g,tag) for g in cat.groups for tag in g.tag_columns}
    key = pid+"_tags"
    config(key,[])
    st.session_state[key] = [k for k in st.session_state[key] if k in choices]
    selected = st.multiselect("Signals (selection order sets track order)",list(choices),key=key,
        format_func=lambda k:choices[k][0].display_name+" · "+choices[k][1])
    if len(selected)>16:
        st.error("Please select no more than 16 signals per chart.")
        return None
    specs = []
    for i,k in enumerate(selected):
        group,tag = choices[k]
        prefix = pid+"_signal_"+tag+"_"
        name,unit = defaults(tag)
        with st.expander(f"{i+1}. {tag}"):
            alias = text("Display name",prefix+"name",name)
            units = text("Units (blank = unspecified; no conversion)",prefix+"unit",unit)
            match = text("Scale matching key",prefix+"match",tag,
                help="Use the same key and units in A and B to match vertical scales, including different payoff numbers.")
            c1,c2 = st.columns(2)
            with c1:
                low = text("Y minimum (blank = auto)",prefix+"min")
            with c2:
                high = text("Y maximum (blank = auto)",prefix+"max")
            try:
                bounds = [float(v) if str(v).strip() else None for v in (low,high)]
                if (bounds[0] is None)!=(bounds[1] is None):
                    raise ValueError("Enter both limits or leave both blank.")
                if bounds[0] is not None and (not all(__import__("math").isfinite(v) for v in bounds) or bounds[0]>=bounds[1]):
                    raise ValueError("Y limits must be finite and minimum below maximum.")
            except ValueError as exc:
                st.error(str(exc))
                return None
        specs.append(dict(group=group,tag=tag,name=alias or tag,unit=units,match=match,min=bounds[0],max=bounds[1]))
    with st.expander("Timestamped observations and assumptions",expanded=False):
        st.caption("Enter date/time in the selected timezone. Notes outside the window remain listed but are not marked.")
        config(pid+"_notes",[])
        config(pid+"_note_seed",st.session_state[pid+"_notes"])
        edited = st.data_editor(pd.DataFrame(st.session_state[pid+"_note_seed"],columns=["Timestamp","Kind","Comment"]),
            num_rows="dynamic",hide_index=True,key=pid+"_note_editor",
            column_config={"Kind":st.column_config.SelectboxColumn(options=["Observation","Assumption"],required=True),
                           "Timestamp":st.column_config.TextColumn(required=True),
                           "Comment":st.column_config.TextColumn(required=True)},width="stretch")
        st.session_state[pid+"_notes"] = json.loads(edited.to_json(orient="records"))
    notes = []
    try:
        for row in st.session_state[pid+"_notes"]:
            if not row.get("Comment"):
                continue
            notes.append(dict(time=timestamp(row["Timestamp"],zone),kind=row.get("Kind") or "Observation",text=row["Comment"]))
    except Exception as exc:
        st.error("Check note timestamps: "+str(exc))
        return None
    return dict(id=pid,source=cat.source_path,title=title,start=start,end=end,event=event,notes=notes,specs=specs,cat=cat)

def load_panel(p):
    signals=[]
    frames={}
    for group in p["cat"].groups:
        specs = [s for s in p["specs"] if s["group"] == group]
        if not specs:
            continue
        csv = materialize_group(p["cat"],group)
        stat=csv.stat()
        frame=window(str(csv),(stat.st_size,stat.st_mtime_ns),tuple(s["tag"] for s in specs),p["start"].isoformat(),p["end"].isoformat())
        frames[group.filename]=frame
    for s in p["specs"]:
        frame=frames[s["group"].filename]
        if frame.empty or not frame[s["tag"]].notna().any():
            st.warning(f'Chart {p["id"]}: no numeric samples for {s["tag"]} in this window.')
        signals.append({k:v for k,v in s.items() if k!="group"}|{"t":frame.timestamp_utc,"y":frame[s["tag"]]})
    return {k:v for k,v in p.items() if k not in ("cat","specs")}|{"signals":signals,"frames":frames}

def main():
    parser=argparse.ArgumentParser(add_help=False)
    parser.add_argument("--source",default="")
    args,_=parser.parse_known_args()
    config("A_source",args.source)
    if "pending_source" in st.session_state:
        pid,path=st.session_state.pop("pending_source")
        st.session_state[pid+"_source"]=path
    if "pending_profile" in st.session_state:
        settings=st.session_state.pop("pending_profile")
        for key in list(st.session_state):
            if key.startswith(("A_","B_","global_")):
                del st.session_state[key]
        st.session_state.update(settings)
        st.session_state.pop("result",None)
    st.title("TwistingLogger Viewer v2")
    st.caption("Independent event windows • Editable labels and units • Shareable annotated comparisons")
    with st.sidebar:
        st.subheader("Comparison settings")
        config("global_compare",True)
        compare=st.checkbox("Enable Chart B",key="global_compare")
        config("global_zone","America/New_York")
        zone=st.selectbox("Timestamp timezone",["America/New_York","UTC"],key="global_zone")
        config("global_mode","Elapsed seconds")
        mode=st.selectbox("Horizontal axis",["Actual time","Elapsed seconds","Aligned event"],key="global_mode")
        config("global_link",False)
        link=st.checkbox("Equal time scales",key="global_link")
        st.caption("Seconds modes: zoom is linked. Actual-time mode: equal initial duration; zoom remains independent.")
        config("global_match",False)
        match=st.checkbox("Match Y scales by key + units",key="global_match")
        st.caption("Manual limits override matching. Use matching keys for equivalent signals on different payoffs.")
        title=text("Report title","global_title","TwistingLogger event comparison")
        config("global_points",10000)
        points=st.select_slider("Points per trace (approximate)",[5000,10000,25000,50000],key="global_points")
        st.divider()
        profile=st.file_uploader("Load saved settings",type=["json"])
        if st.button("Apply saved settings",disabled=profile is None):
            try:
                st.session_state.pending_profile=validate_profile(json.loads(profile.getvalue()))
                st.rerun()
            except (ValueError,TypeError) as exc:
                st.error(str(exc))
        if st.button("Refresh source files"):
            st.cache_data.clear()
            st.session_state.pop("result",None)
            st.rerun()
    cols=st.columns(2 if compare else 1)
    panels=[]
    for col,pid in zip(cols,["A","B"]):
        with col:
            panels.append(panel_controls(pid,zone))
    if st.button("Build / update comparison",type="primary",width="stretch"):
        if any(p is None or not p["specs"] for p in panels):
            st.error("Load a source and select at least one signal in each enabled chart.")
        else:
            try:
                with st.spinner("Reading selected windows and building comparison…"):
                    loaded=[load_panel(p) for p in panels]
                    fig=build_chart(loaded,mode,zone,link,match,points,title)
                    st.session_state.result=(loaded,fig,title)
            except Exception as exc:
                st.error("Could not build comparison: "+str(exc))
    settings={k:v for k,v in st.session_state.items() if k.startswith(("A_","B_","global_")) and not k.endswith(("_note_editor","_note_seed"))}
    st.sidebar.download_button("Save settings",json.dumps({"version":2,"settings":settings},indent=2),
                               "TwistingLogger-v2-settings.json","application/json")
    result=st.session_state.get("result")
    if not result:
        return
    loaded,fig,report_title=result
    st.info("Built snapshot below. After changing controls or notes, click Build / update comparison. Downloads use this built snapshot; browser zoom is not saved.")
    heads=st.columns(len(loaded))
    for col,p in zip(heads,loaded):
        col.markdown(f'**Chart {p["id"]} · {p["title"]} · {(p["end"]-p["start"]).total_seconds():g} seconds**')
        col.caption(f'{p["start"].tz_convert(zone)} → {p["end"].tz_convert(zone)}')
    st.plotly_chart(fig,width="stretch",config={"scrollZoom":True})
    for p in loaded:
        for i,n in enumerate(p["notes"],1):
            st.write(f'{p["id"]}{i} | {n["time"].tz_convert(zone)} | {n["kind"]}: {n["text"]}')
    left,right=st.columns(2)
    left.download_button("Download interactive comparison",report_html(fig,loaded,report_title),
                         "TwistingLogger-comparison.html","text/html",width="stretch")
    out=io.BytesIO()
    with zipfile.ZipFile(out,"w",zipfile.ZIP_DEFLATED) as archive:
        for p in loaded:
            for name,frame in p["frames"].items():
                archive.writestr(p["id"]+"/"+name,frame.to_csv(index=False))
        archive.writestr("WINDOW_INFO.txt","\n".join(f'{p["id"]}: {p["start"]} to {p["end"]}' for p in loaded))
    right.download_button("Download selected-window CSVs",out.getvalue(),"TwistingLogger-comparison-data.zip","application/zip",width="stretch")

if __name__=="__main__":
    main()
