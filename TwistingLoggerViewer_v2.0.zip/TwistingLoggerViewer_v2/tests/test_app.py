import json
import tempfile
import unittest
from pathlib import Path
import pandas as pd
from streamlit.testing.v1 import AppTest

class AppTests(unittest.TestCase):
    def test_two_windows_build_labels_notes_and_restore(self):
        with tempfile.TemporaryDirectory() as td:
            source=Path(td)/"sample.csv"
            pd.DataFrame({"timestamp_utc":pd.date_range("2026-10-01T12:00:00Z",periods=301,freq="100ms"),
                          "TPTO02_MTR_PO[2].f_Ampere":[.6]*301,"Other":[2]*301}).to_csv(source,index=False)
            at=AppTest.from_file(str(Path(__file__).parents[1]/"app.py"),default_timeout=30)
            at.session_state["A_source"]=str(source)
            at.session_state["B_source"]=str(source)
            at.run()
            self.assertFalse(at.exception)
            for widget in at.multiselect:
                widget.set_value(widget.options[:1])
            at.run()
            self.assertFalse(at.exception)
            at.text_input(key="A_end").set_value("2026-10-01 08:00:15")
            at.text_input(key="B_end").set_value("2026-10-01 08:00:18")
            at.text_input(key="A_signal_TPTO02_MTR_PO[2].f_Ampere_name").set_value("Test motor")
            at.run()
            next(b for b in at.button if b.label=="Build / update comparison").click().run()
            self.assertFalse(at.exception)
            panels,fig,title=at.session_state["result"]
            self.assertEqual(panels[0]["signals"][0]["name"],"Test motor")
            self.assertEqual(list(fig.layout.xaxis.range),[0,15])
            self.assertEqual(list(fig.layout.xaxis2.range),[0,18])
            self.assertEqual(len(panels[0]["signals"][0]["y"]),151)
            settings={k:v for k,v in at.session_state._state.filtered_state.items() if k.startswith(("A_","B_","global_")) and not k.endswith(("_note_editor","_note_seed"))}
            settings["A_notes"]=[{"Timestamp":"2026-10-01 08:00:05","Kind":"Observation","Comment":"Current starts here"}]
            at.session_state["pending_profile"]=json.loads(json.dumps(settings))
            at.run()
            next(b for b in at.button if b.label=="Build / update comparison").click().run()
            self.assertFalse(at.exception)
            self.assertEqual(at.session_state["result"][0][0]["notes"][0]["text"],"Current starts here")
            at.checkbox(key="global_link").check().run()
            next(b for b in at.button if b.label=="Build / update comparison").click().run()
            self.assertFalse(at.exception)
            self.assertEqual(list(at.session_state["result"][1].layout.xaxis.range),[0,18])

if __name__=="__main__":
    unittest.main()
