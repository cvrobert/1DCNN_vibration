#!/usr/bin/env bash
set -euo pipefail

if [[ "${EUID}" -ne 0 ]]; then
  echo "Run this setup with: sudo ./setup_sharing.sh [reader-name]" >&2
  exit 1
fi

reader_name="${1:-loggerreader}"
share_name="TwistingLogger"
share_path="/opt/twistinglogger/exports"
smb_config="/etc/samba/smb.conf"

if ! command -v smbd >/dev/null 2>&1; then
  apt-get update
  apt-get install -y samba
fi

if ! id "${reader_name}" >/dev/null 2>&1; then
  useradd --system --no-create-home --shell /usr/sbin/nologin "${reader_name}"
fi

mkdir -p "${share_path}"
chmod 0755 "${share_path}"

if ! grep -q "^\[${share_name}\]$" "${smb_config}"; then
  cp -a "${smb_config}" "${smb_config}.before-twistinglogger"
  cat >> "${smb_config}" <<EOF

[${share_name}]
   path = ${share_path}
   browseable = yes
   read only = yes
   guest ok = no
   valid users = ${reader_name}
   follow symlinks = no
EOF
fi

echo "Set the read-only Windows-share password for ${reader_name}:"
smbpasswd -a "${reader_name}"
testparm -s >/dev/null
systemctl enable --now smbd
if systemctl list-unit-files nmbd.service >/dev/null 2>&1; then
  systemctl enable --now nmbd
fi

echo
echo "Read-only share ready: \\\\192.168.20.141\\${share_name}"
