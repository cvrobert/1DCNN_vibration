#!/usr/bin/env python3
"""Read every configured PLC tag once and report individual failures."""

from __future__ import annotations

import argparse
import time
from pathlib import Path
from typing import Any

from logger import GroupConfig, load_config


def chunks(values: tuple[str, ...], size: int):
    for start in range(0, len(values), size):
        yield values[start : start + size]


def value_summary(value: Any) -> str:
    if isinstance(value, (list, tuple)):
        return f"{type(value).__name__}[{len(value)}]"
    if isinstance(value, dict):
        return f"dict[{len(value)}]"
    rendered = repr(value)
    return rendered if len(rendered) <= 48 else rendered[:45] + "..."


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=Path("config.toml"))
    parser.add_argument("--group", help="Validate only one configured group")
    parser.add_argument("--batch-size", type=int, default=20)
    args = parser.parse_args()
    if args.batch_size < 1:
        raise SystemExit("--batch-size must be at least 1")

    config = load_config(args.config.resolve())
    address = str(config["plc"]["address"])
    groups: list[GroupConfig] = config["parsed_groups"]
    if args.group:
        groups = [group for group in groups if group.name == args.group]
        if not groups:
            raise SystemExit(f"Configured group not found: {args.group}")

    from pycomm3 import LogixDriver

    total = sum(len(group.tags) for group in groups)
    passed = 0
    failed = 0
    started = time.monotonic()
    print(f"Read-only validation of {total} tag expressions on {address}")

    # Load controller tag/type definitions before validating symbolic names.
    with LogixDriver(address, init_program_tags=False) as plc:
        for group in groups:
            print(f"\n[{group.name}] {len(group.tags)} expressions")
            for batch in chunks(group.tags, args.batch_size):
                result = plc.read(*batch)
                results = result if isinstance(result, list) else [result]
                for index, tag in enumerate(batch):
                    if index >= len(results):
                        failed += 1
                        print(f"FAIL  {tag} :: no result returned")
                        continue
                    item = results[index]
                    if item.error:
                        failed += 1
                        print(f"FAIL  {tag} :: {item.error}")
                    else:
                        passed += 1
                        print(f"OK    {tag} :: {value_summary(item.value)}")

    elapsed = time.monotonic() - started
    print(f"\nValidation complete: {passed} passed, {failed} failed, {elapsed:.2f} s")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
