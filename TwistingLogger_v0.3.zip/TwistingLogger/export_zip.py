#!/usr/bin/env python3
"""Stream a completed TwistingLogger day directly into a ZIP of CSV files."""

from __future__ import annotations

import argparse
import csv
import io
import json
import os
import sqlite3
import sys
import zipfile
from datetime import datetime, timedelta
from pathlib import Path

from export_csv import columns_for_tag, csv_values, decode_json, safe_name


def default_day() -> str:
    return (datetime.now().astimezone().date() - timedelta(days=1)).isoformat()


def export_archive(database: Path, output_dir: Path, force: bool) -> Path:
    if not database.is_file():
        raise FileNotFoundError(f"Database does not exist: {database}")

    output_dir.mkdir(parents=True, exist_ok=True)
    archive = output_dir / f"TwistingLogger-{database.stem}.zip"
    temporary = archive.with_suffix(".zip.tmp")
    if archive.exists() and not force:
        print(f"Archive already exists: {archive}")
        return archive
    temporary.unlink(missing_ok=True)

    connection = sqlite3.connect(f"file:{database.resolve()}?mode=ro", uri=True)
    try:
        definitions = connection.execute(
            """
            SELECT id, group_name, interval_ms, tags_json
            FROM group_definitions
            ORDER BY id
            """
        ).fetchall()
        if not definitions:
            raise RuntimeError(f"No group definitions found in {database}")

        with zipfile.ZipFile(
            temporary,
            mode="w",
            compression=zipfile.ZIP_DEFLATED,
            compresslevel=6,
        ) as bundle:
            summary: list[str] = [
                "TwistingLogger daily CSV export",
                f"Source database: {database.name}",
                f"Created: {datetime.now().astimezone().isoformat()}",
                "",
            ]
            for definition_id, group_name, interval_ms, tags_json in definitions:
                tags = json.loads(tags_json)
                expanded_columns = [columns_for_tag(tag) for tag in tags]
                entry_name = (
                    f"{database.stem}_{safe_name(group_name)}_{definition_id}.csv"
                )
                count = 0
                with bundle.open(entry_name, mode="w") as binary_handle:
                    with io.TextIOWrapper(
                        binary_handle, encoding="utf-8", newline=""
                    ) as text_handle:
                        writer = csv.writer(text_handle)
                        writer.writerow(
                            [
                                "timestamp_utc",
                                "timestamp_local",
                                "sequence",
                                "quality",
                                "read_duration_ms",
                                *(
                                    column
                                    for columns in expanded_columns
                                    for column in columns
                                ),
                                "errors_json",
                            ]
                        )
                        rows = connection.execute(
                            """
                            SELECT timestamp_utc, timestamp_local, sequence, quality,
                                   read_duration_ms, values_zlib, errors_zlib
                            FROM samples
                            WHERE definition_id = ?
                            ORDER BY id
                            """,
                            (definition_id,),
                        )
                        for row in rows:
                            values = decode_json(row[5])
                            errors = decode_json(row[6])
                            expanded_values: list[object] = []
                            for index, columns in enumerate(expanded_columns):
                                value = values[index] if index < len(values) else None
                                expanded_values.extend(csv_values(value, len(columns)))
                            writer.writerow(
                                [
                                    *row[:5],
                                    *expanded_values,
                                    json.dumps(errors, separators=(",", ":")),
                                ]
                            )
                            count += 1
                summary.append(
                    f"{entry_name}: {count} rows, {interval_ms} ms group"
                )
                print(f"Added {count} rows to {entry_name}")
            bundle.writestr("EXPORT_INFO.txt", "\n".join(summary) + "\n")
        os.replace(temporary, archive)
    except Exception:
        temporary.unlink(missing_ok=True)
        raise
    finally:
        connection.close()

    print(f"Created {archive}")
    return archive


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--day", default=default_day(), help="YYYY-MM-DD; default yesterday")
    parser.add_argument("--data-dir", type=Path, default=Path("/opt/twistinglogger/data"))
    parser.add_argument(
        "--output-dir", type=Path, default=Path("/opt/twistinglogger/exports")
    )
    parser.add_argument("--force", action="store_true", help="Replace an existing archive")
    args = parser.parse_args()

    database = args.data_dir / f"{args.day}.sqlite3"
    if not database.exists():
        print(f"No completed database for {args.day}; nothing to export")
        return 0
    try:
        export_archive(database, args.output_dir, args.force)
    except Exception as error:
        print(f"Export failed: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
