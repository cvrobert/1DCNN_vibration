# TwistingLogger

TwistingLogger is an unattended Raspberry Pi data logger for an Allen-Bradley
CompactLogix 5069-L340ERM at `192.168.20.10`. It supports multiple sampling
groups, daily SQLite database rotation, CSV export, automatic reconnection,
tag-by-tag commissioning validation, and an offline mock mode.

The supplied TW2 configuration was built from the September 16, 2026 controller
tag listing. Test tags, HMI pushbuttons, motion-axis objects, raw module-defined
I/O assemblies, internal timers, and redundant display-only values are omitted.

- `fast_dynamics`: 100 ms live motor currents, payoff overload levels, and speeds
- `process`: 1 second production values, alarms, payoff events, and machine state
- `configuration`: 10 second recipe, limit, threshold, and setup values

The three groups contain exactly 150 configured read expressions. Array reads
expand these to 293 individual CSV signal columns without issuing hundreds of
separate array-element requests.

## First installation

Copy this package to the Raspberry Pi, then run:

```bash
cd TwistingLogger
chmod +x install.sh
sudo ./install.sh
```

The installer copies the application to `/opt/twistinglogger`, creates or
updates its Python virtual environment, and installs a systemd service. It does
not start the service automatically, allowing the configuration to be reviewed
first.

## Updating an existing installation offline

The installer can use the already-installed Python environment without internet
access. Omit `--replace-config` to preserve the active onsite configuration:

```bash
cd TwistingLogger
chmod +x install.sh
sudo ./install.sh --offline
```

When `--replace-config` is used, the prior configuration is preserved as a
timestamped `/opt/twistinglogger/config.toml.backup-*` file. The installer stops
the historian while files are updated and does not automatically restart it.

## Offline test mode

Set `mock_mode = true` for an offline test, then run a 15-second foreground test:

```bash
/opt/twistinglogger/venv/bin/python /opt/twistinglogger/logger.py \
  --config /opt/twistinglogger/config.toml --duration 15
```

Check status and database files. A 15 second run should produce about 151 fast
samples, 16 process samples, and 2 configuration samples:

```bash
cat /opt/twistinglogger/status.json
ls -lh /opt/twistinglogger/data
```

Export the newest database to CSV:

```bash
/opt/twistinglogger/venv/bin/python /opt/twistinglogger/export_csv.py \
  /opt/twistinglogger/data/YYYY-MM-DD.sqlite3 \
  --output-dir /opt/twistinglogger/exports
```

Create one compressed archive containing a day's three CSV files:

```bash
/opt/twistinglogger/venv/bin/python /opt/twistinglogger/export_zip.py \
  --day YYYY-MM-DD --force
```

The installed `twistinglogger-export.timer` automatically archives the completed
previous day at approximately 12:15 AM. It writes directly into the ZIP without
leaving large temporary CSV files on disk.

## Service controls

```bash
sudo systemctl enable --now twistinglogger
systemctl status twistinglogger
journalctl -u twistinglogger -f
sudo systemctl restart twistinglogger
sudo systemctl stop twistinglogger
```

## PLC commissioning

1. Connect the Pi and PLC to the same controls network.
2. Confirm `ping -c 3 192.168.20.10` succeeds. Note that `192.168.20.20` is a
   5094-AENTR remote-I/O adapter, not the controller.
3. Stop the service and validate every configured expression with read-only
   requests:

```bash
sudo systemctl stop twistinglogger
/opt/twistinglogger/venv/bin/python /opt/twistinglogger/validate_tags.py \
  --config /opt/twistinglogger/config.toml
```

4. Resolve every reported failure before live logging. Common causes are an
   exact tag-name mismatch, a UDT member-name mismatch, or External Access set
   to None.
5. Confirm `mock_mode = false`.
6. Run a short foreground test before enabling the service.

```bash
sudo systemctl stop twistinglogger
/opt/twistinglogger/venv/bin/python /opt/twistinglogger/logger.py \
  --config /opt/twistinglogger/config.toml --duration 15
```

If the reads are valid, enable and start the service.

## Read-only Windows access

Install Samba while temporary internet access is available, then run:

```bash
sudo /opt/twistinglogger/setup_sharing.sh
```

The script creates or reuses the non-login `loggerreader` account and prompts
for its Windows-share password. Engineers can then open:

```text
\\192.168.20.141\TwistingLogger
```

Only the export directory is shared, and it is read-only. The live database,
configuration, service files, and Pi administrator account are not exposed.

## Recovery

For a replacement SD card or Pi:

1. Install Raspberry Pi OS Lite 64-bit with hostname `twistinglogger`.
2. Configure Ethernet as `192.168.20.141/24`, with no controls-network gateway.
3. Install this package and confirm the controller is `192.168.20.10`.
4. Run all three read-only validation groups and a short foreground live test.
5. Enable the historian and daily-export timer.
6. Install the read-only Samba share if engineer access is required.

Keeping this ZIP and a recent copy of `config.toml` off the Pi makes the logger
rebuildable even after total SD-card loss. Historical data still requires an
independent SSD, USB, or network backup.

## Storage notes

- A new database is created at local midnight.
- No automatic deletion is enabled.
- `minimum_free_gb` causes a warning in the status file and journal; it does
  not delete data.
- An abrupt shutdown should be avoided. SQLite WAL mode is enabled to improve
  resilience.
- For final Pi 5 deployment, an SSD is preferred over continuous microSD
  database writes.

## Timekeeping

Every row contains UTC and local Pi timestamps. For an offline installation,
the Pi 5 RTC should have a backup battery or the PLC clock should eventually be
included in the configured data and treated as the authoritative timestamp.
