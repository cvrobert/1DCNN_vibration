#!/usr/bin/env python3
"""Configurable CompactLogix historian with offline mock support."""

from __future__ import annotations

import argparse
import hashlib
import json
import logging
import math
import os
import queue
import random
import re
import shutil
import signal
import sqlite3
import threading
import time
import tomllib
import zlib
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo


LOG = logging.getLogger("twistinglogger")
ARRAY_READ_COUNT = re.compile(r"\{(\d+)\}$")


@dataclass(frozen=True)
class GroupConfig:
    name: str
    interval_ms: int
    tags: tuple[str, ...]


@dataclass
class Sample:
    timestamp_utc: str
    timestamp_local: str
    group: GroupConfig
    sequence: int
    quality: str
    read_duration_ms: float
    values: list[Any]
    errors: list[str | None]


def load_config(path: Path) -> dict[str, Any]:
    with path.open("rb") as handle:
        cfg = tomllib.load(handle)
    if "application" not in cfg or "plc" not in cfg or "groups" not in cfg:
        raise ValueError("Config must contain application, plc, and groups sections")
    names: set[str] = set()
    parsed_groups: list[GroupConfig] = []
    for raw in cfg["groups"]:
        name = str(raw["name"]).strip()
        interval = int(raw["interval_ms"])
        tags = tuple(str(tag).strip() for tag in raw["tags"])
        if not name or name in names:
            raise ValueError(f"Group name is blank or duplicated: {name!r}")
        if interval < 20:
            raise ValueError(f"Group {name}: interval_ms must be at least 20")
        if not tags or any(not tag for tag in tags):
            raise ValueError(f"Group {name}: at least one nonblank tag is required")
        names.add(name)
        parsed_groups.append(GroupConfig(name, interval, tags))
    cfg["parsed_groups"] = parsed_groups
    return cfg


def json_safe(value: Any) -> Any:
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, (list, tuple)):
        return [json_safe(item) for item in value]
    if isinstance(value, dict):
        return {str(key): json_safe(item) for key, item in value.items()}
    return str(value)


def encode_json(value: Any) -> bytes:
    raw = json.dumps(value, separators=(",", ":"), allow_nan=False).encode("utf-8")
    return zlib.compress(raw, level=3)


def definition_hash(group: GroupConfig) -> str:
    payload = json.dumps(
        {"name": group.name, "interval_ms": group.interval_ms, "tags": group.tags},
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


class StatusTracker:
    def __init__(self, status_file: Path, minimum_free_gb: float):
        self.status_file = status_file
        self.minimum_free_gb = minimum_free_gb
        self.lock = threading.Lock()
        self.started_utc = datetime.now(timezone.utc).isoformat()
        self.groups: dict[str, dict[str, Any]] = {}
        self.database_file: str | None = None
        self.queue_depth = 0
        self.dropped_samples = 0
        self.last_database_write_utc: str | None = None
        self.last_error: str | None = None

    def update_group(self, name: str, **values: Any) -> None:
        with self.lock:
            self.groups.setdefault(name, {}).update(values)

    def set_error(self, error: str) -> None:
        with self.lock:
            self.last_error = error

    def write(self, data_dir: Path) -> None:
        free_gb = shutil.disk_usage(data_dir).free / (1024**3)
        with self.lock:
            payload = {
                "application": "TwistingLogger",
                "started_utc": self.started_utc,
                "updated_utc": datetime.now(timezone.utc).isoformat(),
                "database_file": self.database_file,
                "last_database_write_utc": self.last_database_write_utc,
                "queue_depth": self.queue_depth,
                "dropped_samples": self.dropped_samples,
                "free_space_gb": round(free_gb, 3),
                "low_disk_space": free_gb < self.minimum_free_gb,
                "last_error": self.last_error,
                "groups": self.groups,
            }
        self.status_file.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.status_file.with_suffix(self.status_file.suffix + ".tmp")
        temporary.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
        os.replace(temporary, self.status_file)


class DatabaseWriter(threading.Thread):
    def __init__(
        self,
        sample_queue: queue.Queue[Sample],
        data_dir: Path,
        local_zone: ZoneInfo,
        commit_interval_ms: int,
        stop_event: threading.Event,
        status: StatusTracker,
    ):
        super().__init__(name="database-writer", daemon=True)
        self.sample_queue = sample_queue
        self.data_dir = data_dir
        self.local_zone = local_zone
        self.commit_interval = commit_interval_ms / 1000.0
        self.stop_event = stop_event
        self.status = status
        self.connection: sqlite3.Connection | None = None
        self.database_date: str | None = None
        self.definitions: dict[str, int] = {}

    def open_for(self, local_date: str) -> None:
        if self.connection is not None:
            self.connection.commit()
            self.connection.close()
        self.data_dir.mkdir(parents=True, exist_ok=True)
        database_path = self.data_dir / f"{local_date}.sqlite3"
        self.connection = sqlite3.connect(database_path)
        self.connection.execute("PRAGMA journal_mode=WAL")
        self.connection.execute("PRAGMA synchronous=NORMAL")
        self.connection.execute("PRAGMA busy_timeout=5000")
        self.connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS group_definitions (
                id INTEGER PRIMARY KEY,
                definition_hash TEXT NOT NULL UNIQUE,
                group_name TEXT NOT NULL,
                interval_ms INTEGER NOT NULL,
                tags_json TEXT NOT NULL,
                created_utc TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS samples (
                id INTEGER PRIMARY KEY,
                timestamp_utc TEXT NOT NULL,
                timestamp_local TEXT NOT NULL,
                definition_id INTEGER NOT NULL,
                sequence INTEGER NOT NULL,
                quality TEXT NOT NULL,
                read_duration_ms REAL NOT NULL,
                values_zlib BLOB NOT NULL,
                errors_zlib BLOB NOT NULL,
                FOREIGN KEY(definition_id) REFERENCES group_definitions(id)
            );
            CREATE INDEX IF NOT EXISTS ix_samples_time
                ON samples(timestamp_utc);
            CREATE INDEX IF NOT EXISTS ix_samples_definition_time
                ON samples(definition_id, timestamp_utc);
            """
        )
        self.connection.commit()
        self.database_date = local_date
        self.definitions.clear()
        self.status.database_file = str(database_path)
        LOG.info("Writing to %s", database_path)

    def get_definition_id(self, group: GroupConfig) -> int:
        assert self.connection is not None
        key = definition_hash(group)
        if key in self.definitions:
            return self.definitions[key]
        self.connection.execute(
            """
            INSERT OR IGNORE INTO group_definitions
                (definition_hash, group_name, interval_ms, tags_json, created_utc)
            VALUES (?, ?, ?, ?, ?)
            """,
            (
                key,
                group.name,
                group.interval_ms,
                json.dumps(group.tags),
                datetime.now(timezone.utc).isoformat(),
            ),
        )
        row = self.connection.execute(
            "SELECT id FROM group_definitions WHERE definition_hash = ?", (key,)
        ).fetchone()
        if row is None:
            raise RuntimeError("Could not create group definition")
        definition_id = int(row[0])
        self.definitions[key] = definition_id
        return definition_id

    def write_sample(self, sample: Sample) -> None:
        local_date = sample.timestamp_local[:10]
        if self.connection is None or self.database_date != local_date:
            self.open_for(local_date)
        assert self.connection is not None
        definition_id = self.get_definition_id(sample.group)
        self.connection.execute(
            """
            INSERT INTO samples
                (timestamp_utc, timestamp_local, definition_id, sequence,
                 quality, read_duration_ms, values_zlib, errors_zlib)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                sample.timestamp_utc,
                sample.timestamp_local,
                definition_id,
                sample.sequence,
                sample.quality,
                sample.read_duration_ms,
                encode_json(sample.values),
                encode_json(sample.errors),
            ),
        )

    def run(self) -> None:
        last_commit = time.monotonic()
        try:
            while not self.stop_event.is_set() or not self.sample_queue.empty():
                try:
                    sample = self.sample_queue.get(timeout=0.2)
                except queue.Empty:
                    sample = None
                if sample is not None:
                    self.write_sample(sample)
                    self.sample_queue.task_done()
                now = time.monotonic()
                if self.connection is not None and now - last_commit >= self.commit_interval:
                    self.connection.commit()
                    last_commit = now
                    self.status.last_database_write_utc = datetime.now(timezone.utc).isoformat()
                self.status.queue_depth = self.sample_queue.qsize()
        except Exception as exc:
            LOG.exception("Database writer failed")
            self.status.set_error(f"Database writer failed: {exc}")
            self.stop_event.set()
        finally:
            if self.connection is not None:
                self.connection.commit()
                self.connection.close()


class Sampler(threading.Thread):
    def __init__(
        self,
        group: GroupConfig,
        plc_address: str,
        mock_mode: bool,
        reconnect_delay: float,
        local_zone: ZoneInfo,
        sample_queue: queue.Queue[Sample],
        stop_event: threading.Event,
        status: StatusTracker,
    ):
        super().__init__(name=f"sampler-{group.name}", daemon=True)
        self.group = group
        self.plc_address = plc_address
        self.mock_mode = mock_mode
        self.reconnect_delay = reconnect_delay
        self.local_zone = local_zone
        self.sample_queue = sample_queue
        self.stop_event = stop_event
        self.status = status
        self.sequence = 0
        self.random = random.Random(group.name)

    def make_mock_values(self, elapsed: float) -> list[Any]:
        values: list[Any] = []
        for index, tag in enumerate(self.group.tags):
            count_match = ARRAY_READ_COUNT.search(tag)
            count = int(count_match.group(1)) if count_match else 1

            def mock_element(element: int) -> Any:
                lower_tag = tag.lower()
                phase = index * 0.4 + element * 0.07
                if "ampere" in lower_tag:
                    base = 0.65 + 0.06 * (index % 12)
                    value = base + 0.12 * math.sin(elapsed * 1.7 + phase)
                    value += self.random.uniform(-0.025, 0.025)
                    if int(elapsed) % 29 == 17 and elapsed % 1.0 < 0.2:
                        value += 1.4
                    return round(max(0.0, value), 4)
                if "spd" in lower_tag or "speed" in lower_tag:
                    return round(13.5 + 1.5 * math.sin(elapsed / 8.0 + phase), 4)
                if "_b_" in lower_tag or any(
                    marker in lower_tag
                    for marker in ("active", "running", "pulse", "timing")
                ):
                    return bool((int(elapsed) + index + element) % 2)
                return round(10.0 + index + element * 0.01 + math.sin(elapsed / 5.0), 4)

            if count_match:
                values.append([mock_element(element) for element in range(count)])
            else:
                values.append(mock_element(0))
        return values

    def enqueue(self, sample: Sample) -> None:
        try:
            self.sample_queue.put_nowait(sample)
        except queue.Full:
            self.status.dropped_samples += 1
            self.status.set_error(f"Sample queue full; dropped {self.group.name} sample")

    def run_mock(self) -> None:
        interval = self.group.interval_ms / 1000.0
        started = time.monotonic()
        deadline = started
        while not self.stop_event.is_set():
            deadline += interval
            read_started = time.monotonic()
            values = self.make_mock_values(read_started - started)
            now_utc = datetime.now(timezone.utc)
            now_local = now_utc.astimezone(self.local_zone)
            self.sequence += 1
            self.enqueue(
                Sample(
                    now_utc.isoformat(),
                    now_local.isoformat(),
                    self.group,
                    self.sequence,
                    "good",
                    (time.monotonic() - read_started) * 1000.0,
                    values,
                    [None] * len(values),
                )
            )
            self.status.update_group(
                self.group.name,
                mode="mock",
                connected=True,
                sequence=self.sequence,
                last_sample_utc=now_utc.isoformat(),
                quality="good",
            )
            wait = deadline - time.monotonic()
            if wait > 0:
                self.stop_event.wait(wait)
            else:
                missed = int((-wait) // interval) + 1
                deadline += missed * interval
                self.status.update_group(self.group.name, missed_intervals=missed)

    def run_live(self) -> None:
        from pycomm3 import LogixDriver

        interval = self.group.interval_ms / 1000.0
        while not self.stop_event.is_set():
            try:
                self.status.update_group(self.group.name, mode="live", connected=False)
                LOG.info("%s connecting to %s", self.group.name, self.plc_address)
                # Symbolic reads require the controller tag/type definitions.
                # LogixDriver loads them once when this group connects.
                # TW2 only uses controller-scoped logging tags. Avoid downloading
                # every program-scoped symbol and datatype on each connection.
                with LogixDriver(self.plc_address, init_program_tags=False) as plc:
                    self.status.update_group(self.group.name, connected=True)
                    deadline = time.monotonic()
                    while not self.stop_event.is_set():
                        deadline += interval
                        read_started = time.monotonic()
                        result = plc.read(*self.group.tags)
                        results = result if isinstance(result, list) else [result]
                        values: list[Any] = []
                        errors: list[str | None] = []
                        for item in results:
                            error = str(item.error) if item.error else None
                            errors.append(error)
                            values.append(None if error else json_safe(item.value))
                        while len(values) < len(self.group.tags):
                            values.append(None)
                            errors.append("No result returned")
                        quality = "good" if all(error is None for error in errors) else "bad"
                        now_utc = datetime.now(timezone.utc)
                        now_local = now_utc.astimezone(self.local_zone)
                        self.sequence += 1
                        duration_ms = (time.monotonic() - read_started) * 1000.0
                        self.enqueue(
                            Sample(
                                now_utc.isoformat(),
                                now_local.isoformat(),
                                self.group,
                                self.sequence,
                                quality,
                                duration_ms,
                                values,
                                errors,
                            )
                        )
                        self.status.update_group(
                            self.group.name,
                            connected=True,
                            sequence=self.sequence,
                            last_sample_utc=now_utc.isoformat(),
                            quality=quality,
                            read_duration_ms=round(duration_ms, 3),
                        )
                        wait = deadline - time.monotonic()
                        if wait > 0:
                            self.stop_event.wait(wait)
                        else:
                            missed = int((-wait) // interval) + 1
                            deadline += missed * interval
                            self.status.update_group(self.group.name, missed_intervals=missed)
            except Exception as exc:
                LOG.warning("%s PLC connection/read error: %s", self.group.name, exc)
                self.status.update_group(
                    self.group.name,
                    connected=False,
                    quality="disconnected",
                    last_error=str(exc),
                )
                self.status.set_error(f"{self.group.name}: {exc}")
                self.stop_event.wait(self.reconnect_delay)

    def run(self) -> None:
        if self.mock_mode:
            self.run_mock()
        else:
            self.run_live()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="config.toml", type=Path)
    parser.add_argument("--duration", type=float, help="Stop after this many seconds")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(threadName)s %(message)s",
    )
    cfg = load_config(args.config.resolve())
    app_cfg = cfg["application"]
    plc_cfg = cfg["plc"]
    groups: list[GroupConfig] = cfg["parsed_groups"]
    local_zone = ZoneInfo(str(app_cfg.get("timezone", "America/New_York")))
    data_dir = Path(str(app_cfg["data_dir"]))
    status_file = Path(str(app_cfg["status_file"]))
    data_dir.mkdir(parents=True, exist_ok=True)
    status_file.parent.mkdir(parents=True, exist_ok=True)

    stop_event = threading.Event()

    def request_stop(signum: int, _frame: Any) -> None:
        LOG.info("Received signal %s; stopping", signum)
        stop_event.set()

    signal.signal(signal.SIGTERM, request_stop)
    signal.signal(signal.SIGINT, request_stop)

    sample_queue: queue.Queue[Sample] = queue.Queue(
        maxsize=int(app_cfg.get("queue_capacity", 20000))
    )
    status = StatusTracker(
        status_file,
        float(app_cfg.get("minimum_free_gb", 2.0)),
    )
    writer = DatabaseWriter(
        sample_queue,
        data_dir,
        local_zone,
        int(app_cfg.get("database_commit_interval_ms", 500)),
        stop_event,
        status,
    )
    samplers = [
        Sampler(
            group,
            str(plc_cfg["address"]),
            bool(app_cfg.get("mock_mode", True)),
            float(plc_cfg.get("reconnect_delay_seconds", 5)),
            local_zone,
            sample_queue,
            stop_event,
            status,
        )
        for group in groups
    ]

    LOG.info(
        "Starting %s in %s mode with %d groups",
        app_cfg.get("name", "TwistingLogger"),
        "mock" if app_cfg.get("mock_mode", True) else "live",
        len(groups),
    )
    writer.start()
    for sampler in samplers:
        sampler.start()

    started = time.monotonic()
    status_interval = float(app_cfg.get("status_interval_seconds", 10))
    next_status = 0.0
    try:
        while not stop_event.is_set():
            elapsed = time.monotonic() - started
            if args.duration is not None and elapsed >= args.duration:
                stop_event.set()
                break
            if elapsed >= next_status:
                status.write(data_dir)
                next_status = elapsed + status_interval
            stop_event.wait(0.25)
    finally:
        stop_event.set()
        for sampler in samplers:
            sampler.join(timeout=10)
        writer.join(timeout=15)
        status.write(data_dir)
    if writer.is_alive():
        LOG.error("Database writer did not stop cleanly")
        return 2
    LOG.info("Stopped cleanly")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
