from launcher import select_source
if __name__ == "__main__":
    print(select_source() or "")
