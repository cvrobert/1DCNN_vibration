import unittest
from test_comparison import panel
from workspace_charts import figure_for,export_html,comparison_panels

class WorkspaceTests(unittest.TestCase):
    def data(self,pid="A",mode="Overlay all tags"):
        p=panel(pid)
        p.update(zone="America/New_York",plotmode=mode,points=5000)
        return p
    def test_overlay_legend_axis_and_export(self):
        a=self.data(); b=self.data("B","Stacked historian tracks")
        figs=[figure_for(p,"Actual time") for p in (a,b)]
        self.assertTrue(figs[0].layout.showlegend)
        self.assertEqual(figs[0].data[0].yaxis,"y")
        out=export_html([a,b],figs,"Two events")
        self.assertIn('display:flex',out)
        self.assertIn('&lt;script&gt;',out)
        self.assertNotIn('<script>alert(1)</script>',out)
        self.assertEqual(out.count('plotly.js v'),1)
    def test_optional_marker_and_y_matching(self):
        a=self.data(); b=self.data("B")
        a["event"]=None
        self.assertTrue(figure_for(a,"Actual time").data)
        b["signals"][0]["y"]*=4
        matched=comparison_panels([a,b],True)
        self.assertEqual(matched[0]["signals"][0]["max"],matched[1]["signals"][0]["max"])
        self.assertIsNone(a["signals"][0]["max"])

if __name__=="__main__": unittest.main()
