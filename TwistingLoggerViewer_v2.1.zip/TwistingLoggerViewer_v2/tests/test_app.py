import tempfile
import unittest
from pathlib import Path
import pandas as pd
from streamlit.testing.v1 import AppTest

class AppTests(unittest.TestCase):
    def test_independent_workspaces_overlay_and_compare(self):
        with tempfile.TemporaryDirectory() as td:
            source=Path(td)/"sample.csv"
            pd.DataFrame({"timestamp_utc":pd.date_range("2026-10-01T12:00:00Z",periods=301,freq="100ms"),
                "TPTO02_MTR_PO[2].f_Ampere":[.6]*301,"Other":[2]*301}).to_csv(source,index=False)
            at=AppTest.from_file(str(Path(__file__).parents[1]/"app.py"),default_timeout=120)
            at.session_state["A_source"]=str(source)
            at.run()
            self.assertFalse(at.exception)
            self.assertEqual(len(at.date_input),2)
            at.multiselect[0].set_value(["TPTO02_MTR_PO[2].f_Ampere","Other"])
            at.selectbox(key="A_plotmode").set_value("Overlay all tags")
            at.button(key="A_plot").click().run()
            self.assertFalse(at.exception)
            panel,fig=at.session_state["A_result"]
            self.assertEqual(len(fig.data),2)
            self.assertTrue(fig.layout.showlegend)
            self.assertTrue(all(t.yaxis=="y" for t in fig.data))
            at.checkbox(key="second").check().run()
            at.text_input(key="B_source").set_value(str(source)).run()
            self.assertFalse(at.exception)
            self.assertEqual(len(at.date_input),4)
            at.multiselect[1].set_value(["Other"])
            at.button(key="B_plot").click().run()
            self.assertFalse(at.exception)
            self.assertEqual(len(at.session_state["A_result"][0]["signals"]),2)
            self.assertEqual(len(at.session_state["B_result"][0]["signals"]),1)
            at.multiselect[0].set_value(["Other"])
            at.button(key="A_plot").click().run()
            self.assertFalse(at.exception)
            self.assertEqual(len(at.session_state["A_result"][1].data),1)
            self.assertEqual(len(at.session_state["B_result"][1].data),1)
            at.checkbox(key="A_marker").check().run()
            at.button(key="A_plot").click().run()
            at.checkbox(key="B_marker").check().run()
            at.button(key="B_plot").click().run()
            at.radio(key="compare_axis").set_value("Align event markers").run()
            self.assertFalse(at.exception)
            self.assertIsNotNone(at.session_state["A_result"][0]["event"])
            at.radio(key="compare_axis").set_value("Align event markers").run()
            self.assertFalse(at.exception)
            self.assertFalse(any("BOTH" in w.value for w in at.warning))
            at.radio(key="compare_axis").set_value("Seconds from window start").run()
            at.checkbox(key="compare_equal").check().run()
            self.assertFalse(at.exception)
            at.checkbox(key="second").uncheck().run()
            at.checkbox(key="second").check().run()
            self.assertFalse(at.exception)
            self.assertEqual(len(at.session_state["B_result"][1].data),1)

if __name__=="__main__": unittest.main()
