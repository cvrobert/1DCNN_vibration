from __future__ import annotations

import csv
import tempfile
import unittest
import zipfile
from datetime import date, time
from pathlib import Path

import numpy as np
import pandas as pd

from viewer_core import (
    build_filtered_zip,
    catalog_source,
    local_selection_to_utc,
    materialize_group,
    minmax_decimate,
    read_time_window,
    scan_catalog_time_range,
)


class ViewerCoreTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.archive = self.root / "TwistingLogger-2026-09-30.zip"
        timestamps = pd.date_range("2026-09-30T12:00:00Z", periods=1000, freq="100ms")
        fast_rows = [
            [
                stamp.isoformat(),
                stamp.tz_convert("America/New_York").isoformat(),
                index,
                "good",
                5.0,
                99.0 if index == 501 else float(np.sin(index / 20)),
                12.5,
                "{}",
            ]
            for index, stamp in enumerate(timestamps)
        ]
        process_rows = [
            [
                stamp.isoformat(),
                stamp.tz_convert("America/New_York").isoformat(),
                index,
                "good",
                6.0,
                index % 2 == 0,
                "{}",
            ]
            for index, stamp in enumerate(timestamps[::10])
        ]
        with zipfile.ZipFile(self.archive, "w", zipfile.ZIP_DEFLATED) as bundle:
            bundle.writestr(
                "2026-09-30_fast_dynamics_1.csv",
                self._csv_text(
                    [
                        "timestamp_utc",
                        "timestamp_local",
                        "sequence",
                        "quality",
                        "read_duration_ms",
                        "Current_A",
                        "LineSpeed",
                        "errors_json",
                    ],
                    fast_rows,
                ),
            )
            bundle.writestr(
                "2026-09-30_process_2.csv",
                self._csv_text(
                    [
                        "timestamp_utc",
                        "timestamp_local",
                        "sequence",
                        "quality",
                        "read_duration_ms",
                        "LineRunning",
                        "errors_json",
                    ],
                    process_rows,
                ),
            )

    def tearDown(self):
        self.temporary.cleanup()

    @staticmethod
    def _csv_text(header, rows):
        import io

        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(header)
        writer.writerows(rows)
        return output.getvalue()

    def test_catalog_and_time_range(self):
        catalog = catalog_source(self.archive)
        self.assertEqual(len(catalog.groups), 2)
        self.assertEqual(catalog.groups[0].display_name, "Fast Dynamics")
        minimum, maximum = scan_catalog_time_range(catalog, self.root / "cache")
        self.assertEqual(minimum, pd.Timestamp("2026-09-30T12:00:00Z"))
        self.assertEqual(maximum, pd.Timestamp("2026-09-30T12:01:39.900000Z"))

    def test_read_window_and_boolean_conversion(self):
        catalog = catalog_source(self.archive)
        process = next(group for group in catalog.groups if group.display_name == "Process")
        csv_path = materialize_group(catalog, process, self.root / "cache")
        frame = read_time_window(
            csv_path,
            ["LineRunning"],
            pd.Timestamp("2026-09-30T12:00:01Z"),
            pd.Timestamp("2026-09-30T12:00:03Z"),
        )
        self.assertEqual(len(frame), 3)
        self.assertEqual(set(frame["LineRunning"].dropna().unique()), {0.0, 1.0})

    def test_peak_preserving_decimation(self):
        catalog = catalog_source(self.archive)
        fast = next(group for group in catalog.groups if group.display_name == "Fast Dynamics")
        csv_path = materialize_group(catalog, fast, self.root / "cache")
        frame = read_time_window(
            csv_path,
            ["Current_A"],
            pd.Timestamp("2026-09-30T12:00:00Z"),
            pd.Timestamp("2026-09-30T12:02:00Z"),
        )
        x_values, y_values = minmax_decimate(
            frame["timestamp_utc"], frame["Current_A"], max_points=100
        )
        self.assertLessEqual(len(x_values), 102)
        self.assertEqual(float(y_values.max()), 99.0)

    def test_timezone_conversion_and_filtered_export(self):
        stamp = local_selection_to_utc(
            date(2026, 9, 30), time(8, 0, 0), "America/New_York"
        )
        self.assertEqual(stamp, pd.Timestamp("2026-09-30T12:00:00Z"))
        frame = pd.DataFrame({"timestamp_utc": [stamp], "Value": [1.0]})
        payload = build_filtered_zip({"Fast Dynamics": frame}, stamp, stamp)
        export_path = self.root / "filtered.zip"
        export_path.write_bytes(payload)
        with zipfile.ZipFile(export_path) as bundle:
            self.assertIn("Fast_Dynamics.csv", bundle.namelist())
            self.assertIn("WINDOW_INFO.txt", bundle.namelist())


if __name__ == "__main__":
    unittest.main()

