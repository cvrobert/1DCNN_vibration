import json
import unittest
import pandas as pd
from comparison import defaults, timestamp, build_chart, report_html, validate_profile

def panel(pid="A",duration=15,day="2026-10-01",note=True):
    start=pd.Timestamp(day+"T12:00:00Z")
    ts=pd.Series(pd.date_range(start,periods=duration*10+1,freq="100ms"))
    return dict(id=pid,title="Example",source="example.zip",start=start,end=start+pd.Timedelta(seconds=duration),
                event=start+pd.Timedelta(seconds=5),
                notes=[dict(time=start+pd.Timedelta(seconds=7),kind="Assumption",text="<script>alert(1)</script>")] if note else [],
                signals=[dict(tag="current",name="Current",unit="A",match="motor",min=None,max=None,t=ts,y=pd.Series([.6]*len(ts)))])

class ComparisonTests(unittest.TestCase):
    def test_labels_and_unverified_units(self):
        self.assertEqual(defaults("TPTO02_MTR_PO[2].f_Ampere"),("Payoff 3 Motor Current","A"))
        self.assertEqual(defaults("GPO_f_DNCR_Spd_as[2]")[1],"")
        self.assertEqual(defaults("Unseen_Tag"),("Unseen_Tag",""))

    def test_timezone_and_invalid_dst(self):
        self.assertEqual(timestamp("2026-10-01 08:00:00","America/New_York"),pd.Timestamp("2026-10-01T12:00:00Z"))
        with self.assertRaises(Exception):
            timestamp("2026-11-01 01:30:00","America/New_York")

    def test_independent_durations_and_linking(self):
        a,b=panel(),panel("B",18,"2026-10-03")
        fig=build_chart([a,b],"Elapsed seconds","UTC",False,False,5000,"Test")
        self.assertEqual(list(fig.layout.xaxis.range),[0,15])
        self.assertEqual(list(fig.layout.xaxis2.range),[0,18])
        fig=build_chart([a,b],"Aligned event","UTC",True,False,5000,"Test")
        self.assertEqual(list(fig.layout.xaxis.range),[-5,13])
        self.assertEqual(fig.layout.xaxis2.matches,"x")

    def test_value_matching_manual_and_missing_breaks(self):
        a,b=panel(),panel("B")
        b["signals"][0]["y"]*=4
        a["signals"][0]["y"].iloc[20]=float("nan")
        fig=build_chart([a,b],"Elapsed seconds","UTC",False,True,50,"Test")
        self.assertEqual(fig.layout.yaxis.range,fig.layout.yaxis2.range)
        self.assertIn(None,list(fig.data[0].y)[:-1])
        b["signals"][0].update(min=0,max=5)
        fig=build_chart([a,b],"Elapsed seconds","UTC",False,True,50,"Test")
        self.assertEqual(list(fig.layout.yaxis2.range),[0,5])

    def test_offline_export_notes_and_axes(self):
        a,b=panel(),panel("B",18)
        fig=build_chart([a,b],"Actual time","America/New_York",True,False,5000,"Test")
        self.assertEqual(fig.layout.xaxis.range,fig.layout.xaxis2.range)
        output=report_html(fig,[a,b],"Test")
        self.assertIn("plotly.js",output)
        self.assertNotIn('<script>alert(1)</script>',output)
        self.assertIn("&lt;script&gt;",output)
        self.assertIn("18 seconds",output)
        self.assertIn("A1",output)

    def test_profile(self):
        settings={"A_source":"C:/data.zip","A_signal_tag_unit":"A"}
        self.assertEqual(validate_profile(json.loads(json.dumps({"version":2,"settings":settings}))),settings)
        with self.assertRaises(ValueError):
            validate_profile({"version":1})

if __name__=="__main__":
    unittest.main()
