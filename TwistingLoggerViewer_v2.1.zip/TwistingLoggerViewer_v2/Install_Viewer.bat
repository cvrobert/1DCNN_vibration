@echo off
setlocal
cd /d "%~dp0"

where py >nul 2>nul
if errorlevel 1 (
    echo Python was not found.
    echo Install Python 3.11 or newer from https://www.python.org/downloads/windows/
    echo During installation, select "Add Python to PATH".
    pause
    exit /b 1
)

echo Creating the viewer environment...
py -3 -m venv .venv
if errorlevel 1 goto :failed

echo Installing the viewer packages...
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto :failed
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto :failed

echo.
echo Installation complete.
echo Double-click Start_Viewer.bat to open a logger ZIP or CSV.
pause
exit /b 0

:failed
echo.
echo Installation did not complete. Internet access is required for the first installation.
pause
exit /b 1

