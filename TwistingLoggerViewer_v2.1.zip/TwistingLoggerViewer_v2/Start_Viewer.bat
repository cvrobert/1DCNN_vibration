@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo The viewer has not been installed yet.
    call Install_Viewer.bat
    if errorlevel 1 exit /b 1
)

".venv\Scripts\python.exe" launcher.py

