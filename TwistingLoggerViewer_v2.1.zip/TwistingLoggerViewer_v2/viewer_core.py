"""Data discovery, time filtering, and peak-preserving decimation."""

from __future__ import annotations

import csv
import hashlib
import io
import math
import os
import re
import shutil
import tempfile
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd


METADATA_COLUMNS = {
    "timestamp_utc",
    "timestamp_local",
    "sequence",
    "quality",
    "read_duration_ms",
    "errors_json",
}

GROUP_PATTERN = re.compile(
    r"^\d{4}-\d{2}-\d{2}_(?P<group>.+)_(?P<definition>\d+)\.csv$",
    re.IGNORECASE,
)


@dataclass(frozen=True)
class GroupInfo:
    group_id: str
    display_name: str
    filename: str
    columns: tuple[str, ...]
    direct_path: str | None = None
    zip_member: str | None = None

    @property
    def tag_columns(self) -> tuple[str, ...]:
        return tuple(column for column in self.columns if column not in METADATA_COLUMNS)


@dataclass(frozen=True)
class SourceCatalog:
    source_path: str
    groups: tuple[GroupInfo, ...]


def normalize_source_path(value: str | os.PathLike[str]) -> Path:
    text = str(value).strip().strip('"').strip("'")
    return Path(os.path.expandvars(os.path.expanduser(text))).resolve()


def group_display_name(filename: str) -> str:
    match = GROUP_PATTERN.match(Path(filename).name)
    if match:
        return match.group("group").replace("_", " ").title()
    return Path(filename).stem.replace("_", " ").title()


def read_csv_header_from_handle(handle: io.TextIOBase) -> tuple[str, ...]:
    row = next(csv.reader(handle), None)
    if not row:
        raise ValueError("CSV is empty or has no header")
    return tuple(row)


def catalog_source(value: str | os.PathLike[str]) -> SourceCatalog:
    source = normalize_source_path(value)
    if not source.exists():
        raise FileNotFoundError(f"Source does not exist: {source}")

    groups: list[GroupInfo] = []
    if source.is_file() and source.suffix.lower() == ".zip":
        with zipfile.ZipFile(source) as archive:
            members = sorted(
                name for name in archive.namelist() if name.lower().endswith(".csv")
            )
            for index, member in enumerate(members):
                with archive.open(member) as binary:
                    with io.TextIOWrapper(binary, encoding="utf-8-sig", newline="") as text:
                        columns = read_csv_header_from_handle(text)
                groups.append(
                    GroupInfo(
                        group_id=f"zip:{index}:{member}",
                        display_name=group_display_name(member),
                        filename=Path(member).name,
                        columns=columns,
                        zip_member=member,
                    )
                )
    else:
        if source.is_dir():
            csv_files = sorted(source.glob("*.csv"))
        elif source.is_file() and source.suffix.lower() == ".csv":
            csv_files = [source]
        else:
            raise ValueError("Select a TwistingLogger ZIP, CSV, or folder of CSV files")

        for index, csv_file in enumerate(csv_files):
            with csv_file.open("r", encoding="utf-8-sig", newline="") as handle:
                columns = read_csv_header_from_handle(handle)
            groups.append(
                GroupInfo(
                    group_id=f"file:{index}:{csv_file.name}",
                    display_name=group_display_name(csv_file.name),
                    filename=csv_file.name,
                    columns=columns,
                    direct_path=str(csv_file.resolve()),
                )
            )

    if not groups:
        raise ValueError("No CSV groups were found in the selected source")
    for group in groups:
        if "timestamp_utc" not in group.columns:
            raise ValueError(f"{group.filename} does not contain timestamp_utc")
    return SourceCatalog(str(source), tuple(groups))


def source_signature(source_path: str, group: GroupInfo) -> str:
    source = Path(source_path)
    stat = source.stat()
    payload = f"{source.resolve()}|{stat.st_size}|{stat.st_mtime_ns}|{group.group_id}"
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:20]


def materialize_group(
    catalog: SourceCatalog,
    group: GroupInfo,
    cache_root: Path | None = None,
) -> Path:
    if group.direct_path:
        return Path(group.direct_path)
    if not group.zip_member:
        raise ValueError(f"Group has no data source: {group.display_name}")

    root = cache_root or Path(tempfile.gettempdir()) / "TwistingLoggerViewer"
    destination_dir = root / source_signature(catalog.source_path, group)
    destination = destination_dir / group.filename
    if destination.exists() and destination.stat().st_size > 0:
        return destination

    destination_dir.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(destination.suffix + ".tmp")
    with zipfile.ZipFile(catalog.source_path) as archive:
        with archive.open(group.zip_member) as source_handle:
            with temporary.open("wb") as destination_handle:
                shutil.copyfileobj(source_handle, destination_handle, length=1024 * 1024)
    os.replace(temporary, destination)
    return destination


def parse_utc(values: pd.Series) -> pd.Series:
    # Logger ISO timestamps may mix whole-second and fractional-second rows.
    # format="mixed" prevents pandas from inferring one strict format from the
    # first row and silently discarding the other valid timestamp form.
    return pd.to_datetime(values, utc=True, errors="coerce", format="mixed")


def scan_group_time_range(csv_path: Path, chunksize: int = 250_000) -> tuple[pd.Timestamp, pd.Timestamp]:
    earliest: pd.Timestamp | None = None
    latest: pd.Timestamp | None = None
    for chunk in pd.read_csv(
        csv_path,
        usecols=["timestamp_utc"],
        dtype={"timestamp_utc": "string"},
        chunksize=chunksize,
    ):
        timestamps = parse_utc(chunk["timestamp_utc"]).dropna()
        if timestamps.empty:
            continue
        chunk_min = timestamps.min()
        chunk_max = timestamps.max()
        earliest = chunk_min if earliest is None else min(earliest, chunk_min)
        latest = chunk_max if latest is None else max(latest, chunk_max)
    if earliest is None or latest is None:
        raise ValueError(f"No valid timestamps found in {csv_path.name}")
    return earliest, latest


def scan_catalog_time_range(
    catalog: SourceCatalog,
    cache_root: Path | None = None,
) -> tuple[pd.Timestamp, pd.Timestamp]:
    ranges = [
        scan_group_time_range(materialize_group(catalog, group, cache_root))
        for group in catalog.groups
    ]
    return min(item[0] for item in ranges), max(item[1] for item in ranges)


def coerce_plot_value(series: pd.Series) -> pd.Series:
    if pd.api.types.is_bool_dtype(series):
        return series.astype("Int8")
    if pd.api.types.is_numeric_dtype(series):
        return series
    normalized = series.astype("string").str.strip().str.lower()
    boolean_map = normalized.map({"true": 1.0, "false": 0.0})
    numeric = pd.to_numeric(series, errors="coerce")
    return numeric.where(numeric.notna(), boolean_map)


def read_time_window(
    csv_path: Path,
    tags: Iterable[str],
    start_utc: pd.Timestamp,
    end_utc: pd.Timestamp,
    chunksize: int = 200_000,
) -> pd.DataFrame:
    selected_tags = list(dict.fromkeys(tags))
    usecols = ["timestamp_utc", *selected_tags]
    frames: list[pd.DataFrame] = []
    for chunk in pd.read_csv(csv_path, usecols=usecols, chunksize=chunksize, low_memory=False):
        timestamps = parse_utc(chunk["timestamp_utc"])
        mask = timestamps.between(start_utc, end_utc, inclusive="both")
        if not mask.any():
            continue
        filtered = chunk.loc[mask].copy()
        filtered["timestamp_utc"] = timestamps.loc[mask]
        for tag in selected_tags:
            filtered[tag] = coerce_plot_value(filtered[tag])
        frames.append(filtered)
    if not frames:
        return pd.DataFrame(columns=usecols)
    return pd.concat(frames, ignore_index=True)


def minmax_decimate(
    timestamps: pd.Series,
    values: pd.Series,
    max_points: int,
) -> tuple[pd.Series, pd.Series]:
    frame = pd.DataFrame({"x": timestamps, "y": values}).dropna()
    count = len(frame)
    if count <= max_points or max_points < 4:
        return frame["x"], frame["y"]

    bucket_count = max(1, (max_points - 2) // 2)
    edges = np.linspace(0, count, bucket_count + 1, dtype=int)
    positions: set[int] = {0, count - 1}
    y = frame["y"].to_numpy()
    for start, stop in zip(edges[:-1], edges[1:]):
        if stop <= start:
            continue
        segment = y[start:stop]
        positions.add(start + int(np.nanargmin(segment)))
        positions.add(start + int(np.nanargmax(segment)))
    ordered = sorted(positions)
    reduced = frame.iloc[ordered]
    return reduced["x"], reduced["y"]


def local_selection_to_utc(
    date_value,
    time_value,
    timezone_name: str,
) -> pd.Timestamp:
    combined = pd.Timestamp.combine(date_value, time_value)
    return combined.tz_localize(
        timezone_name,
        ambiguous="raise",
        nonexistent="shift_forward",
    ).tz_convert("UTC")


def build_filtered_zip(
    data_by_group: dict[str, pd.DataFrame],
    start_utc: pd.Timestamp,
    end_utc: pd.Timestamp,
) -> bytes:
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for group_name, frame in data_by_group.items():
            safe = re.sub(r"[^A-Za-z0-9_-]+", "_", group_name).strip("_") or "group"
            archive.writestr(f"{safe}.csv", frame.to_csv(index=False))
        archive.writestr(
            "WINDOW_INFO.txt",
            "TwistingLogger Viewer filtered export\n"
            f"Start UTC: {start_utc.isoformat()}\n"
            f"End UTC: {end_utc.isoformat()}\n",
        )
    return output.getvalue()
