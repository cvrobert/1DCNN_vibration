"""V1-style independent workspaces with optional comparison."""
import argparse
import json
import subprocess
import sys
from datetime import date, time
from pathlib import Path
import pandas as pd
import streamlit as st
from viewer_core import catalog_source, materialize_group, scan_catalog_time_range, read_time_window, build_filtered_zip
from comparison import defaults, timestamp
from workspace_charts import figure_for, comparison_panels, export_html

@st.cache_data(show_spinner=False)
def inspect_source(source, stamp):
    cat = catalog_source(source)
    return cat, scan_catalog_time_range(cat)

@st.cache_data(show_spinner=False,max_entries=32)
def load_window(path, stamp, tags, start, end):
    return read_time_window(Path(path),tags,pd.Timestamp(start),pd.Timestamp(end)).sort_values("timestamp_utc").reset_index(drop=True)

def signature(source):
    p=Path(source.strip().strip('"')).expanduser()
    return tuple((str(f),f.stat().st_size,f.stat().st_mtime_ns) for f in sorted(p.glob("*.csv"))) if p.is_dir() else (p.stat().st_size,p.stat().st_mtime_ns)

def init(key,value):
    if key not in st.session_state: st.session_state[key]=value

def text(label,key,value="",**kw):
    init(key,value)
    return st.text_input(label,key=key,**kw)

def workspace(pid):
    st.header("Event "+pid)
    c1,c2,c3=st.columns([6,1,1])
    with c1: source=text("ZIP, CSV, or CSV folder",pid+"_source")
    if c2.button("Browse",key=pid+"_browse"):
        try:
            r=subprocess.run([sys.executable,str(Path(__file__).with_name("pick_file.py"))],capture_output=True,text=True,check=True)
            if r.stdout.strip():
                st.session_state.pending_source=(pid,r.stdout.strip()); st.rerun()
        except (OSError,subprocess.CalledProcessError):
            st.error("File picker unavailable. Paste the file path.")
    if c3.button("Reload",key=pid+"_reload"):
        st.cache_data.clear(); st.session_state.pop(pid+"_result",None); st.rerun()
    if not source:
        st.info("Choose a logger ZIP or CSV to find this event.")
        return
    zone="America/New_York" if st.session_state.zone=="Eastern local time" else "UTC"
    try:
        cat,(first,last)=inspect_source(source,signature(source))
    except Exception as exc:
        st.error(str(exc)); return
    identity=cat.source_path+"|"+zone
    if st.session_state.get(pid+"_identity")!=identity:
        for key in list(st.session_state):
            if key.startswith(pid+"_") and (key.endswith(("_date","_time")) or "_tags_" in key or key==pid+"_result"):
                del st.session_state[key]
        st.session_state[pid+"_identity"]=identity
    st.success(f"{Path(cat.source_path).name} — {first.tz_convert(zone):%Y-%m-%d %H:%M:%S} through {last.tz_convert(zone):%Y-%m-%d %H:%M:%S}")
    st.subheader("1 Select the event window")
    lo=max(first,last-pd.Timedelta(minutes=10)).tz_convert(zone); hi=last.tz_convert(zone)
    for key,value in [("start_date",lo.date()),("start_time",lo.time().replace(microsecond=0)),("end_date",hi.date()),("end_time",hi.time().replace(microsecond=0))]:
        init(pid+"_"+key,value)
    cols=st.columns(4)
    sd=cols[0].date_input("Start date",key=pid+"_start_date")
    ss=cols[1].time_input("Start time",key=pid+"_start_time",step=1)
    ed=cols[2].date_input("End date",key=pid+"_end_date")
    es=cols[3].time_input("End time",key=pid+"_end_time",step=1)
    try:
        start=timestamp(f"{sd} {ss}",zone)
        # Match v1: include every sample in the entered end second.
        end=timestamp(f"{ed} {es}",zone)+pd.Timedelta(seconds=1)-pd.Timedelta(microseconds=1)
        if end<=start: raise ValueError("End must be later than start.")
    except Exception as exc:
        st.error(str(exc)); return
    st.caption("As in v1, the entire end second is included. Narrow these fields and replot when you find the event you want to compare.")
    st.subheader("2 Select tags")
    selected=[]
    tabs=st.tabs([g.display_name for g in cat.groups])
    for tab,g in zip(tabs,cat.groups):
        with tab:
            st.caption(f"{len(g.tag_columns)} available tags from {g.filename}")
            key=pid+"_tags_"+g.group_id
            init(key,[])
            st.session_state[key]=[t for t in st.session_state[key] if t in g.tag_columns]
            tags=st.multiselect("Tags to trend",list(g.tag_columns),key=key,placeholder="Search or select one or more tags")
            selected.extend((g,t) for t in tags)
    st.subheader("3 Build the trend")
    cols=st.columns([2,2,1])
    mode=cols[0].selectbox("Display mode",["Stacked historian tracks","Overlay all tags"],key=pid+"_plotmode")
    init(pid+"_points",25000)
    points=cols[1].select_slider("Maximum points per trace",[5000,10000,25000,50000,100000],key=pid+"_points")
    marker=cols[2].checkbox("Add event-time marker",key=pid+"_marker")
    event=None
    if marker:
        cols=st.columns(2)
        init(pid+"_event_date",sd); init(pid+"_event_time",ss)
        event_date=cols[0].date_input("Event date",key=pid+"_event_date")
        event_time=cols[1].time_input("Event time",step=1,key=pid+"_event_time")
        event=timestamp(f"{event_date} {event_time}",zone)
        st.caption("Choose the instant the event begins. This marker also becomes zero if you later choose Align event markers.")
    meta=[]
    with st.expander("Optional: names, units, and vertical scales"):
        st.caption("Leave this closed to use the viewer normally. Labels do not convert values. Blank units mean unverified.")
        title=text("Chart title",pid+"_title","Event "+pid)
        for g,tag in selected:
            name,unit=defaults(tag); prefix=pid+"_meta_"+tag
            st.caption(tag)
            a,b,c,d=st.columns([3,1,1,1])
            with a: alias=text("Display name",prefix+"_name",name)
            with b: units=text("Units",prefix+"_unit",unit)
            with c: low=text("Y min",prefix+"_min")
            with d: high=text("Y max",prefix+"_max")
            try:
                bounds=[float(v) if v.strip() else None for v in (low,high)]
                if (bounds[0] is None)!=(bounds[1] is None): raise ValueError("Enter both Y limits or leave both blank.")
                if bounds[0] is not None and (not all(__import__("math").isfinite(v) for v in bounds) or bounds[0]>=bounds[1]):
                    raise ValueError("Y minimum must be below maximum, with finite values.")
            except ValueError as exc:
                st.error(f"{tag}: {exc}"); return
            meta.append(dict(group=g,tag=tag,name=alias or tag,unit=units,match=tag,min=bounds[0],max=bounds[1]))
        st.caption("In overlay mode all traces share one Y axis, as in v1. If setting limits, use the same limits for every selected trace. Use stacked tracks for separate units/scales.")
    with st.expander("Optional: timestamped comments"):
        st.caption(f"Add a row with date and time in {zone}, e.g. 2026-10-01 19:09:38.700. Observation = what you see; Assumption = your explanation.")
        init(pid+"_notes",[]); init(pid+"_note_seed",st.session_state[pid+"_notes"])
        edited=st.data_editor(pd.DataFrame(st.session_state[pid+"_note_seed"],columns=["Timestamp","Kind","Comment"]),
            num_rows="dynamic",hide_index=True,key=pid+"_editor",
            column_config={"Kind":st.column_config.SelectboxColumn(options=["Observation","Assumption"])},width="stretch")
        st.session_state[pid+"_notes"]=json.loads(edited.to_json(orient="records"))
    if st.button("Plot selected tags",key=pid+"_plot",type="primary",width="stretch"):
        try:
            if not 1<=len(meta)<=24: raise ValueError("Select between 1 and 24 tags.")
            notes=[dict(time=timestamp(n["Timestamp"],zone),kind=n.get("Kind") or "Observation",text=n["Comment"]) for n in st.session_state[pid+"_notes"] if n.get("Comment")]
            frames={}
            with st.spinner("Reading the selected time window…"):
                for g in cat.groups:
                    tags=tuple(s["tag"] for s in meta if s["group"]==g)
                    if not tags: continue
                    path=materialize_group(cat,g)
                    frames[g.filename]=load_window(str(path),signature(str(path)),tags,start.isoformat(),end.isoformat())
                signals=[]
                for s in meta:
                    f=frames[s["group"].filename]
                    if f.empty or not f[s["tag"]].notna().any(): st.warning("No numeric samples: "+s["tag"])
                    signals.append({k:v for k,v in s.items() if k!="group"}|{"t":f.timestamp_utc,"y":f[s["tag"]]})
                panel=dict(id=pid,title=title,source=cat.source_path,start=start,end=end,event=event,notes=notes,
                           signals=signals,frames=frames,plotmode=mode,points=points,zone=zone)
                fig=figure_for(panel,"Actual time")
                st.session_state[pid+"_result"]=(panel,fig)
        except Exception as exc: st.error(str(exc))
    result=st.session_state.get(pid+"_result")
    if result:
        panel,fig=result
        st.caption("Click a legend entry to hide/show a trace; double-click to isolate it. Add/remove tags above and replot to change the selection.")
        st.plotly_chart(fig,width="stretch",key=pid+"_chart",config={"scrollZoom":True})
        for i,n in enumerate(panel["notes"],1): st.write(f'{pid}{i} · {n["time"].tz_convert(panel["zone"])} · {n["kind"]}: {n["text"]}')
        a,b=st.columns(2)
        a.download_button("Download filtered CSVs",build_filtered_zip(panel["frames"],panel["start"],panel["end"]),
            f"TwistingLogger-{pid}-window.zip","application/zip",key=pid+"_csv")
        b.download_button("Download interactive chart",export_html([panel],[fig],"TwistingLogger Event "+pid),
            f"TwistingLogger-{pid}-trend.html","text/html",key=pid+"_html")

def compare_workspace():
    st.header("Compare the events")
    results=[st.session_state.get(p+"_result") for p in ("A","B")]
    if not all(results):
        st.info("Plot an event in both Event A and Event B, then return here. Each event keeps its own tags and overlay/stacked setting.")
        return
    panels=[r[0] for r in results]
    axis="Actual time"; equal=False; match=False
    with st.expander("Optional: compare timing and scales"):
        st.markdown("**Actual time (default):** keep each event's original timestamps and zoom each graph independently. Start here to find and compare events.")
        st.markdown("**Seconds from window start:** each selected window begins at 0. A rise at 5 seconds means five seconds after that window's start. Useful when both windows start at a comparable point.")
        st.markdown("**Align event markers:** set an event-time marker in each workspace and replot. Both markers become 0. A point at −3 happened three seconds before its event; +5 is five seconds after. The two events can be on completely different days.")
        choice=st.radio("Comparison time axis",["Actual time","Seconds from window start","Align event markers"],key="compare_axis")
        axis={"Actual time":"Actual time","Seconds from window start":"Elapsed seconds","Align event markers":"Aligned event"}[choice]
        equal=st.checkbox("Use the same displayed time span",key="compare_equal")
        st.caption("Gives both plots the same seconds per horizontal width. An 18-second window will not be squeezed to look like a 15-second window. Zoom remains independent.")
        match=st.checkbox("Match vertical scales for identical PLC tags and units",key="compare_match")
        st.caption("For different payoff tags, set the same manual Y limits in both workspaces. Overlay traces share one Y axis.")
    if axis=="Aligned event" and any(p["event"] is None for p in panels):
        st.warning("Enable Add event-time marker in BOTH workspaces, choose each event time, and click Plot selected tags.")
        return
    prepared=comparison_panels(panels,match)
    figs=[figure_for(p,axis) for p in prepared]
    if equal:
        if axis=="Actual time":
            duration=max((p["end"]-p["start"]).total_seconds() for p in panels)
            for p,f in zip(panels,figs):
                start=p["start"].tz_convert(p["zone"]).tz_localize(None)
                f.update_xaxes(range=[start,start+pd.Timedelta(seconds=duration)])
        else:
            ranges=[f.layout.xaxis.range for f in figs]
            common=[min(r[0] for r in ranges),max(r[1] for r in ranges)]
            for f in figs: f.update_xaxes(range=common)
    for f in figs: f.update_layout(uirevision=str(f.layout.uirevision)+str(equal)+str(match))
    height=max(f.layout.height for f in figs)
    for f in figs: f.update_layout(height=height)
    st.caption("These are the last plotted windows from A and B. To preserve a tighter view for export, enter its start/end times in that workspace and replot; temporary zoom is not saved.")
    for col,p,f in zip(st.columns(2),panels,figs):
        with col:
            st.subheader(p["title"])
            st.caption(f'{p["start"].tz_convert(p["zone"])} → {p["end"].tz_convert(p["zone"])} · {(p["end"]-p["start"]).total_seconds():.1f} s')
            st.plotly_chart(f,width="stretch",key=p["id"]+"_comparechart",config={"scrollZoom":True})
    st.download_button("Download side-by-side interactive comparison",export_html(panels,figs,"TwistingLogger comparison"),
        "TwistingLogger-comparison.html","text/html")

def main():
    st.set_page_config(page_title="TwistingLogger Viewer",page_icon="📈",layout="wide")
    parser=argparse.ArgumentParser(add_help=False); parser.add_argument("--source",default="")
    args,_=parser.parse_known_args()
    init("A_source",args.source)
    if "pending_source" in st.session_state:
        p,s=st.session_state.pop("pending_source"); st.session_state[p+"_source"]=s
    if "pending_settings" in st.session_state:
        settings=st.session_state.pop("pending_settings")
        for k in list(st.session_state):
            if k.startswith(("A_","B_")): del st.session_state[k]
        for k,v in settings.items():
            if k.endswith("_date"): v=date.fromisoformat(v)
            elif k.endswith("_time"): v=time.fromisoformat(v)
            st.session_state[k]=v
    # Keep pane B settings/results when it is temporarily disabled.
    for k in list(st.session_state):
        if k.startswith(("A_","B_")) and not k.endswith(("_browse","_reload","_plot","_csv","_html","_editor")):
            st.session_state[k]=st.session_state[k]
    st.title("TwistingLogger Data Viewer")
    st.caption("Find an event. Open a second event when needed. Compare the plots side by side.")
    with st.sidebar:
        st.radio("Time display",["Eastern local time","UTC"],key="zone")
        second=st.checkbox("Open a second event",key="second")
        with st.expander("How to use this viewer"):
            st.write("1. In Event A, pick a file, choose the time window and tags, then plot.")
            st.write("2. Suspect a similar event? Enable Open a second event. Use Event B in exactly the same way.")
            st.write("3. Open Compare to view both generated plots side by side.")
            st.write("4. Use the optional timing controls only if you want to align the events by seconds.")
        with st.expander("Save / restore settings"):
            st.caption("Saves selections and notes, not CSV data. Plot again after restoring.")
            upload=st.file_uploader("Settings JSON",type=["json"])
            if st.button("Restore settings",disabled=upload is None):
                try:
                    obj=json.loads(upload.getvalue())
                    if obj.get("version")!="2.1": raise ValueError("Use a settings file saved by this revised viewer (2.1).")
                    allowed=lambda k:k.startswith(("A_","B_")) or k in ("zone","second")
                    if any(not allowed(k) for k in obj["settings"]): raise ValueError("Invalid settings.")
                    st.session_state.pending_settings=obj["settings"]; st.rerun()
                except Exception as exc: st.error(str(exc))
    if second:
        a,b,c=st.tabs(["Event A","Event B","Compare side by side"])
        with a: workspace("A")
        with b: workspace("B")
        with c: compare_workspace()
    else: workspace("A")
    settings={k:v for k,v in st.session_state.items() if (k.startswith(("A_","B_")) or k in ("zone","second")) and not k.endswith(("_result","_note_seed","_editor","_browse","_reload","_plot","_csv","_html","_chart","_comparechart"))}
    st.sidebar.download_button("Save settings",json.dumps({"version":"2.1","settings":settings},default=str,indent=2),
                               "TwistingLogger-settings.json","application/json")

if __name__=="__main__": main()
